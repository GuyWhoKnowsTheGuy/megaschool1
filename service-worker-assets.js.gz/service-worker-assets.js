self.assetsManifest = {
  "version": "gqdZp/1w",
  "assets": [
    {
      "hash": "sha256-qJAuuKtXjsOCdGWVdhXSxJjtr26OIrMo88bEuQiSAyw=",
      "url": "MegaSchool1.styles.css"
    },
    {
      "hash": "sha256-CzOMFx1QJiQ2qwbg9cmQ2X4RRqnNAtwbMXJ6WE2L6js=",
      "url": "_content/Append.Blazor.WebShare/scripts.js"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-dbrztyw7cpD/dvGeaqylyRiNofbn9I08NpD/6iCdbjA=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-gCxH2RI5xXVkxLFgcHgDuyoXu7IWZwdvZ5USM+27dIk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-eTpvwvDNavTSzL9mvsyAolbszT4oDL+nWD2dv0NSeUM=",
      "url": "_framework/Append.Blazor.WebShare.3trn12rddt.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-D+dfp6xcbDQeM8YkMnhT4SB0NpR70u2eqX216CNZKNs=",
      "url": "_framework/Common.Logging.Core.bxmwr8lhlv.wasm"
    },
    {
      "hash": "sha256-4AVhWz22l1X8Pl+vQZMfhD+iMZzHdeyyWpx3yGcXtXY=",
      "url": "_framework/Common.Logging.k361pnvvgn.wasm"
    },
    {
      "hash": "sha256-l9KFA/UP3DtkGRSqTCkMEAlFE2gCUIBx9z2DznR7gco=",
      "url": "_framework/Flow.Model.ztmoxaaeqp.wasm"
    },
    {
      "hash": "sha256-6ZpWcxIGy9qNdp2qRiMGp9g5U8GYBK5lUfl2aKel3UU=",
      "url": "_framework/Flow.UI.3p1204ilvp.wasm"
    },
    {
      "hash": "sha256-UzXm5ONFC2YfuSahJleOJiIJNURatHcRQIkXq2hoPew=",
      "url": "_framework/FluentValidation.b28mz0qrx7.wasm"
    },
    {
      "hash": "sha256-OQ80Wj7z0wXMnIcGzHx3LYw83DnlvOk5OOiOYLILi3E=",
      "url": "_framework/Foundation.Model.7cxsp0evie.wasm"
    },
    {
      "hash": "sha256-Nk+g1VGWKLMZWI/8LCNswAvx8uO+UvC0YlBomU1+mvo=",
      "url": "_framework/Foundation.UI.uil1469d4p.wasm"
    },
    {
      "hash": "sha256-dBm5UHP8hg3pLku0if0ZJcCu16124P6GQPD92njA/wY=",
      "url": "_framework/LaunchDarkly.EventSource.ck3ehzcsxc.wasm"
    },
    {
      "hash": "sha256-jaAxYE6PA1dz1Fwhgnk8Av9DWAJcMf/5g/mKFg/Skhw=",
      "url": "_framework/MegaSchool1.Model.hbvk15rdcq.wasm"
    },
    {
      "hash": "sha256-PhnFDNmhWiFtaa0ZdREyDORxx2BIa3WIadH0EiJgdIw=",
      "url": "_framework/MegaSchool1.ViewModel.6uw85jve2u.wasm"
    },
    {
      "hash": "sha256-A2GPZ5N3wRLP53do6pExHTMDUlVGES4ql1xUdTxVjfc=",
      "url": "_framework/MegaSchool1.xjftvnr72g.wasm"
    },
    {
      "hash": "sha256-PgUSLwkXhYeM6KBrsYKYSg16Y49gSyUsfIEKzsNxukk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.2c9ug4twva.wasm"
    },
    {
      "hash": "sha256-DVZrH77PLH9WO0h7d7L8HYN7WHr+ATadt8TYZlaIG5c=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.9hefvo4t5y.wasm"
    },
    {
      "hash": "sha256-my08vp0O7vOk7Ur4492zQcUGURiEteKwkI5WWNF4GU8=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.dea7y0kcfc.wasm"
    },
    {
      "hash": "sha256-/eCH3kY5SJZAL2HDKflfoFZ9tNaiTqU1GBaWE9aJ+lg=",
      "url": "_framework/Microsoft.AspNetCore.Components.t41denlr6s.wasm"
    },
    {
      "hash": "sha256-7wgz1ZHwXmXV8y00xn+jT4BGeuCQQbVYGQl+PNvBfnQ=",
      "url": "_framework/Microsoft.AspNetCore.Http.Abstractions.5jy9omvvsv.wasm"
    },
    {
      "hash": "sha256-bzIPAVp+XhD63CRn9cVTB4tJRU+oDEAuwFYoHytMhUk=",
      "url": "_framework/Microsoft.AspNetCore.Http.Features.pqxjsc5k5q.wasm"
    },
    {
      "hash": "sha256-CNGtY2Zlow4ZwwKlyWeyosbzAaSllziAZuYdTuTHIRM=",
      "url": "_framework/Microsoft.Bcl.TimeProvider.0mrxvq2io8.wasm"
    },
    {
      "hash": "sha256-H3y4cPAzdpJW+OUTZLP3QAtpbJFXOQZeClI9PQ7go/s=",
      "url": "_framework/Microsoft.CSharp.33boq5mt72.wasm"
    },
    {
      "hash": "sha256-gQdAN++CR5LVV5E9bWmj4vuZCOWUGBslOt66BUGruKg=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.r1gte5clvs.wasm"
    },
    {
      "hash": "sha256-gXq/QRInHtk6XEuEoAdzEV3P9y1Pn7lQBRLoF4j0sts=",
      "url": "_framework/Microsoft.Extensions.Caching.Memory.5nonu4r2go.wasm"
    },
    {
      "hash": "sha256-/SGyLUFiyUTWxqPGADV0yJX+oU/l8ZOvZn8DqGWh8mM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.7rbuvuxuio.wasm"
    },
    {
      "hash": "sha256-zajGEzocWqbFGAF+xMOEhfTmH7Am40gp9lMSX7NINQM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.ri1ybk6omf.wasm"
    },
    {
      "hash": "sha256-FQjLsQaz4KTpgQKQkcTn5A5IuUgcYT6MpYuBsN/vjX0=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.7d9a22amlg.wasm"
    },
    {
      "hash": "sha256-p3JFQYfez0aTSF8Zh74Ub+6Er1eFMUm3N5dq+bDUxgo=",
      "url": "_framework/Microsoft.Extensions.Configuration.h20gx6h6gv.wasm"
    },
    {
      "hash": "sha256-k/dqpBzJwThiib1oehV10+FkYSekMVOWk6x0yRivCwM=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.jwcd50dqbs.wasm"
    },
    {
      "hash": "sha256-MOVlPkeO9+8Nu3CBHZqiF9YgpspbjBuCIS4K9LqliPs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.clr2lmubvg.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-4MI79GMFiaG5hzrS/SaTeZX14LPrLumed/JeW2WEnhk=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.47iwdj4yh1.wasm"
    },
    {
      "hash": "sha256-Hrpb5t7ltIT73TGewsLBDLnrM4p/f62Ooi5q1ve2e88=",
      "url": "_framework/Microsoft.Extensions.Logging.a6gs5sbhqh.wasm"
    },
    {
      "hash": "sha256-j6OzRkwAr6dRtI5CnnoLZ8YvU/+xUW3BkehrQWeZzCA=",
      "url": "_framework/Microsoft.Extensions.Options.7exurhso5d.wasm"
    },
    {
      "hash": "sha256-zYiLJslw31vyJEuD8qX8SdiGUtVOzcHbTStXHf5qF2M=",
      "url": "_framework/Microsoft.Extensions.Primitives.fh816wprwr.wasm"
    },
    {
      "hash": "sha256-dGs2F5baTHgaBzR9oxqbLpHOrWgsOUBw7wRzmP/Nlys=",
      "url": "_framework/Microsoft.FeatureManagement.ksvasw12p2.wasm"
    },
    {
      "hash": "sha256-zG8NjHhe1UnU743ayejqVCJKZDKIiXVfF5ynItRTmVY=",
      "url": "_framework/Microsoft.JSInterop.0pbwxz6otz.wasm"
    },
    {
      "hash": "sha256-WuuQXW1+AnPHafZKt7ukqmwRDrGYbEV2LhxNuPl+ybo=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.y1ydbrr1bj.wasm"
    },
    {
      "hash": "sha256-M+eCqke0mGXBInAWVV/TBkspIUoUwnwu/1yGbI1NK88=",
      "url": "_framework/MudBlazor.lyzbqdq1a8.wasm"
    },
    {
      "hash": "sha256-ywAFDtoXferEICrM3akT+z9meobGUQFPhz2X53jBT90=",
      "url": "_framework/NSec.Cryptography.97ryhkcw5y.wasm"
    },
    {
      "hash": "sha256-+ivIDUFHJl+LmeKj7ueRPfnWM/wp2dMygtiBlp6Cqmw=",
      "url": "_framework/Nett.emyfn4350c.wasm"
    },
    {
      "hash": "sha256-erKuIr8Gjq+X/Ji4X+pGauW71/eyGT7GHVu8k+7ie8I=",
      "url": "_framework/Newtonsoft.Json.y96379yjhz.wasm"
    },
    {
      "hash": "sha256-akqbZuRazMph7GZNcPHLIOp1mgnkjdaWZMM9Up4LPfE=",
      "url": "_framework/OneOf.yq61etxwqn.wasm"
    },
    {
      "hash": "sha256-ayRMl7l1GF4h65kNE0bKJ4lrGPZxmR+OkvPUFrQ11oU=",
      "url": "_framework/QRCoder.jqr4n2c9hc.wasm"
    },
    {
      "hash": "sha256-ZwToh0+onnsuEEi4ISoq7tGM9S9l8NmpDtywTW7VASI=",
      "url": "_framework/Riok.Mapperly.Abstractions.v2oa0z4fia.wasm"
    },
    {
      "hash": "sha256-4eyCDrmeln8TfYIa6F9oAyuyPqJi7Y5/CaXDOfYve6A=",
      "url": "_framework/Serilog.Sinks.Async.5f8lfszthz.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-IU1wbWWmevTzax9faR7cBTh3+/SHme1dNs0/OXItpXc=",
      "url": "_framework/Serilog.Sinks.Console.rtr49hgfiq.wasm"
    },
    {
      "hash": "sha256-AOLPsUlcm6GyVW4GsJ6IBJ6Ztz0VuRKlTrhFfUwqGN0=",
      "url": "_framework/Serilog.gky8dcecvc.wasm"
    },
    {
      "hash": "sha256-N5r7VlbZEHk1UImo/6FHTRjYh+0/iAFlXCyJG4Y+ic8=",
      "url": "_framework/Stellar.jdhxc6e6oo.wasm"
    },
    {
      "hash": "sha256-VTz/QqS8vAGkdU0cmIwSPpklrMdnRPbpLm/JSenJWwg=",
      "url": "_framework/StellarDotnetSdk.Xdr.3u7w8fba1m.wasm"
    },
    {
      "hash": "sha256-vGp4lUxm+wTcGD7jHcsgMEpeLxDAADKzqd7PYhlnxlo=",
      "url": "_framework/StellarDotnetSdk.c66wahwm8u.wasm"
    },
    {
      "hash": "sha256-3W2F4oZYjNXMLUSS/qWzw302peNkw6/LvEGkYWSwtxo=",
      "url": "_framework/System.Collections.Concurrent.fpp8ewttbj.wasm"
    },
    {
      "hash": "sha256-0g1XSabJ1fYT/lNer69qulbf6UZpd7UNcmcUNNgy6Y0=",
      "url": "_framework/System.Collections.Immutable.yw34tp2b06.wasm"
    },
    {
      "hash": "sha256-D2OUy2zIidGps1MzQ1lwcbXTy1/dtddLwOWJmLqDgaA=",
      "url": "_framework/System.Collections.NonGeneric.xkwg0hnpg7.wasm"
    },
    {
      "hash": "sha256-XdZ5ywIZmOQxOx02Jgw1tqA33EVQMHJAnFFaoDgLVV8=",
      "url": "_framework/System.Collections.Specialized.ptri9cqyqc.wasm"
    },
    {
      "hash": "sha256-8nWOyFc4H8z5tKhJ9VAmeZ1WOEIpa53cP8xgO5WQ9kY=",
      "url": "_framework/System.Collections.ewwmacg12s.wasm"
    },
    {
      "hash": "sha256-FDws1uq5a27/JDbrX2GP2LZncptyajjHenWKN26zmF8=",
      "url": "_framework/System.ComponentModel.Annotations.kuufas8bl5.wasm"
    },
    {
      "hash": "sha256-fFhVdogL++OqUS21j1wr9wv2VBDam+GTVvRQGUwEOq4=",
      "url": "_framework/System.ComponentModel.Primitives.0droz1avdc.wasm"
    },
    {
      "hash": "sha256-3OYg9NTQJggZE/y0dMbEEE+ToxDtq1o+kWuvMb3S9fo=",
      "url": "_framework/System.ComponentModel.TypeConverter.8d8ywubuce.wasm"
    },
    {
      "hash": "sha256-y7Uqcg7+R+c3wLwPT6xsZPEQgM3h2npB2twrQNngYQE=",
      "url": "_framework/System.ComponentModel.vnfim00jfn.wasm"
    },
    {
      "hash": "sha256-Eo5jZOa1faeki/RLR9FY2dpQC5SpyOXmtcpl3N6/MYU=",
      "url": "_framework/System.Console.2ri8p6tceu.wasm"
    },
    {
      "hash": "sha256-8t6sH8G6KJHC9HGybItbq1ZqsimlMmYV6eCIr00/caw=",
      "url": "_framework/System.Data.Common.al9mncyo8a.wasm"
    },
    {
      "hash": "sha256-AuD3agLI/V7LlKohbpvAEy1GC6beX+r+xfUvnqsfgxw=",
      "url": "_framework/System.Diagnostics.Debug.2ztpodxtei.wasm"
    },
    {
      "hash": "sha256-q9rHbgJyFZe0WJ4QPrEu61u+8rRS5k69QiLwRhOACKI=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.tadcr3ng1z.wasm"
    },
    {
      "hash": "sha256-Hs0ga5nNEEtMnm7F3Ct0ToVHssvHBpv1uS3dvr8Okpk=",
      "url": "_framework/System.Diagnostics.Tools.qt7ypeo5u1.wasm"
    },
    {
      "hash": "sha256-c2cd0S4PitmOTdF3JSEI2smiieJ2BI6fM+LJF3B1fF0=",
      "url": "_framework/System.Diagnostics.TraceSource.dkrcaybne1.wasm"
    },
    {
      "hash": "sha256-+/slk+p05YLL9PWifhOLNTMobKyXuetk5l8CZa05kmg=",
      "url": "_framework/System.Drawing.Primitives.tiarihajjv.wasm"
    },
    {
      "hash": "sha256-UgmupMAr6ZNEzs9lDBX+BpCRqNkmfFv1kxoruuR2UWs=",
      "url": "_framework/System.Drawing.e1q21ukgul.wasm"
    },
    {
      "hash": "sha256-TF2oXMceHFt13miMj0ElToPq1oRoN8lRMSOk4lwlj68=",
      "url": "_framework/System.Globalization.0n9qq873i8.wasm"
    },
    {
      "hash": "sha256-OrN4QGx2qmHwgMUfPbbbt0vuz1psC+4V+PvPTwlfRbM=",
      "url": "_framework/System.IO.Compression.2hixx0zyqd.wasm"
    },
    {
      "hash": "sha256-d4Fv2UP7j+pqOrhljw06Xjdf1UB0VVgcWQAZYM+e2Ak=",
      "url": "_framework/System.IO.Pipelines.3p3f5vckx6.wasm"
    },
    {
      "hash": "sha256-5w87UGCav1AGK4HaWlF8D6fYRKq2ZNpYfw6d2snUcFk=",
      "url": "_framework/System.IO.rf3im6s3ur.wasm"
    },
    {
      "hash": "sha256-PWUZfHPylzxfWNLAod9NO+PGJwqpaE7/EBaxuBFCEB8=",
      "url": "_framework/System.Linq.5a1biq5db8.wasm"
    },
    {
      "hash": "sha256-ZnRCSvLEJLES9LhoGU6zN//E1EyLZoXmTXyzsri/YsM=",
      "url": "_framework/System.Linq.Expressions.a72t8vynb9.wasm"
    },
    {
      "hash": "sha256-Y0S5uSEugmaUcciYZEALnOX7IDfLDYnLRvQI4QHrxYo=",
      "url": "_framework/System.Memory.176h2stehs.wasm"
    },
    {
      "hash": "sha256-qoxaFjzErtoV13PxbzADKk1faamWMGpWCSxtFtdtvDE=",
      "url": "_framework/System.Net.Http.2mlpn372p3.wasm"
    },
    {
      "hash": "sha256-jPDvy8ME69U23ag9J10brIysnKw5XxKqe4bPaZRV6wU=",
      "url": "_framework/System.Net.Http.Json.kadxb1a832.wasm"
    },
    {
      "hash": "sha256-tPaJk1IBtvZcUnTDatPculgt1Q8iRefimU54UMdKDM8=",
      "url": "_framework/System.Net.Primitives.wxjzvubd06.wasm"
    },
    {
      "hash": "sha256-0E+bWFzmUrpgmdBdfqc/Se17wxDjTLP87+qrFgUsmGA=",
      "url": "_framework/System.Net.WebSockets.g43043l6zk.wasm"
    },
    {
      "hash": "sha256-lLKcbEO7MOWXYo0Le+8uhaq26uoxB2y03Cvp9ghYyfY=",
      "url": "_framework/System.ObjectModel.4ak779olmw.wasm"
    },
    {
      "hash": "sha256-c3DwuCAYVEwXf0zHgcEK6Xfb10QnmspoJibG4n5l2Co=",
      "url": "_framework/System.Private.CoreLib.nb91fzntba.wasm"
    },
    {
      "hash": "sha256-kFqHiloSx6X5kBfMgwm8bcaRLi94UNC2pHlUmY/qzFQ=",
      "url": "_framework/System.Private.Uri.oav4q5iunh.wasm"
    },
    {
      "hash": "sha256-ZFdJMxBIpH6x3MCPzaSfRKZ6CK+ZjJOpeuKMoVlnZx8=",
      "url": "_framework/System.Private.Xml.852btnp9yu.wasm"
    },
    {
      "hash": "sha256-UFoQ5wx2f20PjUBgPW18nFQAGS4mDYoM7We5p7kYzes=",
      "url": "_framework/System.Private.Xml.Linq.c5h2rfww1w.wasm"
    },
    {
      "hash": "sha256-9juWgVeE4WL5xW9Oov2g94SuYXZ0dNc9tG6p0uE2mBw=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.iqh9y49eex.wasm"
    },
    {
      "hash": "sha256-a2oU5jVqtlkQGS3dzmhRAb7M8kHc2kUr3QxcIAPsZbM=",
      "url": "_framework/System.Reflection.Emit.Lightweight.3aggk0288c.wasm"
    },
    {
      "hash": "sha256-O2SuWJE82piThXOT7R5dW0RqYI+g5sXZbkYd2uKLQMo=",
      "url": "_framework/System.Reflection.Extensions.pvlwti2e2z.wasm"
    },
    {
      "hash": "sha256-aZf/s0XDzDDIAzR9I79KoiNOGNIhHBlc3lc/c8p9SBI=",
      "url": "_framework/System.Reflection.Primitives.bfvqrjaup1.wasm"
    },
    {
      "hash": "sha256-xMgryd3E4cgoT3KVSo6xgkpb0C7XkI0QPq5PAZegVRk=",
      "url": "_framework/System.Reflection.TypeExtensions.syynocf8go.wasm"
    },
    {
      "hash": "sha256-maCMBRpGpCC2Am0BQ/r2rOaxqPyIcoKh/F1bPonkFv0=",
      "url": "_framework/System.Reflection.non2fjapki.wasm"
    },
    {
      "hash": "sha256-xNmqrC4KKGtrWrqql18OvVtctKmJJ46gqBfjbIT622M=",
      "url": "_framework/System.Resources.ResourceManager.09cvebjmdl.wasm"
    },
    {
      "hash": "sha256-jdYSd3CpD1dsvy4LpTySKX6DPbsTCDUZErJr6e1klBY=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.5ed34vlnox.wasm"
    },
    {
      "hash": "sha256-R/FvsVuwdWivtWufywnDmEggxCYK7f4uEFjV0UyyUDg=",
      "url": "_framework/System.Runtime.Extensions.d771kwycbt.wasm"
    },
    {
      "hash": "sha256-92zUoi9qwW2rZalWHIYTUNdUv+uUJLg6ZLS4Aj0eqHk=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.5pcrya9j00.wasm"
    },
    {
      "hash": "sha256-HOy0ydxlYQ3cWTHl/BZPWDcSzEFqnf7A+ksFXraxjjw=",
      "url": "_framework/System.Runtime.InteropServices.gh70atpihb.wasm"
    },
    {
      "hash": "sha256-DkAmr76ZVYaa6v21/HMFo5eeY276zSplnsQImEYXf8I=",
      "url": "_framework/System.Runtime.Numerics.qyxo2jp0m7.wasm"
    },
    {
      "hash": "sha256-aNjixtWJqXd37FOW0pqAyciK2tcIsZ6ogO19uSSiGVg=",
      "url": "_framework/System.Runtime.Serialization.Formatters.g2xoz2l2qq.wasm"
    },
    {
      "hash": "sha256-wL0VtCmxuZJzPdRMVOdvtaPmCoIuLUKXBh1Snq1G8Iw=",
      "url": "_framework/System.Runtime.Serialization.Primitives.4bjsxjkd3k.wasm"
    },
    {
      "hash": "sha256-OoaBLwP1hW8AVyPmaaTMAC5XV5kIKiK4MlSjIuaLSkE=",
      "url": "_framework/System.Runtime.enb5ku76ny.wasm"
    },
    {
      "hash": "sha256-4swdn6yx2/9vPURHb/mEw1ZhAS79dJIhz3AteXaB0bU=",
      "url": "_framework/System.Security.Claims.amgfnlyvku.wasm"
    },
    {
      "hash": "sha256-Om7+LegMOetyvu//Wb7rgomf4maudfUUb6lHC63FoP0=",
      "url": "_framework/System.Security.Cryptography.Algorithms.yu2f6rqkqb.wasm"
    },
    {
      "hash": "sha256-x4e7/Mde/KAAvwD3lRkBK7X4Jd65R9U076nSz6+KspY=",
      "url": "_framework/System.Security.Cryptography.Primitives.bbzwh3rrps.wasm"
    },
    {
      "hash": "sha256-Km3jqqgUEtwi2bkl4gg08f5VzvPRCJ44VZov7vU5VtU=",
      "url": "_framework/System.Security.Cryptography.ie2o326rti.wasm"
    },
    {
      "hash": "sha256-qM+26aUKc04D6MtfbQvNKIomZjsGTcJkzadxM1pw5z8=",
      "url": "_framework/System.Text.Encoding.CodePages.0iys2o9kja.wasm"
    },
    {
      "hash": "sha256-w5BwYak22XKVBVhcVTdvJwLUzGTrnRdR7HuXyamu40Q=",
      "url": "_framework/System.Text.Encoding.Extensions.pdxtt9y857.wasm"
    },
    {
      "hash": "sha256-q8haDIhZETgA8+SU8mpRvzERHkgChJQQ8dvI3ABunaM=",
      "url": "_framework/System.Text.Encoding.fnylqvb1j0.wasm"
    },
    {
      "hash": "sha256-ay+zxFVYRC1+v3UVJnchPQwdy3XX0klafSrO+o20EV4=",
      "url": "_framework/System.Text.Encodings.Web.nd8cez8nv8.wasm"
    },
    {
      "hash": "sha256-V1P7wNDwzzFzpteouchFlWARMM6xkR7TDHCJfZ3ifL8=",
      "url": "_framework/System.Text.Json.vapl00yjhj.wasm"
    },
    {
      "hash": "sha256-D728CC74Figv9O4uB9HqMWA2lfDpNihGBbdPwEj0wZY=",
      "url": "_framework/System.Text.RegularExpressions.zvhqs98kbf.wasm"
    },
    {
      "hash": "sha256-KRBqxgU9Zh2j0cHE1zIDpLlm7TKMP9QacmuY6myYt84=",
      "url": "_framework/System.Threading.3twfkmfokt.wasm"
    },
    {
      "hash": "sha256-D5nwLaX1ip1FBNf7r6CgrKx2wGZf9NLKJhq2Yr8nNv8=",
      "url": "_framework/System.Threading.Tasks.rx5k623gut.wasm"
    },
    {
      "hash": "sha256-rwLO2lr05V7r3zznNDGPFTH+f+kWhDJxo9zOHkVnNik=",
      "url": "_framework/System.Web.HttpUtility.5zumbb07jv.wasm"
    },
    {
      "hash": "sha256-B3Sn5WuDQKyX1cBKZwM/t4NNOIT2E8PtPWVPp/EINqE=",
      "url": "_framework/System.Xml.Linq.9s8atxe8u2.wasm"
    },
    {
      "hash": "sha256-L2KexQlAVkenXMtnqg4740hZNvARG9X+IbvYUELwDB4=",
      "url": "_framework/System.Xml.ReaderWriter.pyrxayosfq.wasm"
    },
    {
      "hash": "sha256-rKq/6Mx7Dw2agooBDDhs63QcDk1ouXFcNIVNKVTULbI=",
      "url": "_framework/System.Xml.XDocument.wxd346dfec.wasm"
    },
    {
      "hash": "sha256-ViNRvhyxlTugIlqJHamw/HwbXlg/YWcrANmxuTM0tfg=",
      "url": "_framework/System.ezrw3d5kw2.wasm"
    },
    {
      "hash": "sha256-PxBQUtV7HW4AVxrjPhV5zpEV+LTsFd90t3iDHolxOfE=",
      "url": "_framework/Tommy.z379sas3l7.wasm"
    },
    {
      "hash": "sha256-6mjXsRUWnN/JhZInfdIIt2MNpV0xK7jHZmYpq8ruD30=",
      "url": "_framework/USA.Model.yhtnyoekpe.wasm"
    },
    {
      "hash": "sha256-nNPyM7TP7Sp4N054o563oU6FZnHcAw8jJU3H+H0sJ0I=",
      "url": "_framework/ValueOf.ccmezia1vt.wasm"
    },
    {
      "hash": "sha256-B6MgK5GiN6XyQxbB1WLV5kiZjtlDXPso8S0p5QUpCds=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-0C5th70x3cgwI6otbYfnZFNKiDFUEWeeGoJEdszlFRc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-W1YtjZ8N6UXfN/cErYXXI4kKSYV3lfmqbx13QFVbUDs=",
      "url": "_framework/dotnet.native.lwtthfaiz0.js"
    },
    {
      "hash": "sha256-ibzA6OgmyjMEmx+xza4LDZLVFYge55jO85joD+2eSwE=",
      "url": "_framework/dotnet.native.psock4haa9.wasm"
    },
    {
      "hash": "sha256-kTZbe5ESp04VMT22TnjRmFj88VbtEcohZfCm4og/IDw=",
      "url": "_framework/dotnet.runtime.5nhp1wfg9b.js"
    },
    {
      "hash": "sha256-Kn+8j510dQQ7rCE6F347fJpZAM2x+uiNlRwyiSmicSI=",
      "url": "_framework/dotnetstandard-bip32.qwdn989y8v.wasm"
    },
    {
      "hash": "sha256-j6wIkVxwXBJ3QLeksRyb1pJbcfEF1waXK3cbImnAl3Q=",
      "url": "_framework/dotnetstandard-bip39.vke3c9voq8.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-gd23KsmejCxB1eV/4ne8EZ5125Z6Ltkt/lixBC0ioTg=",
      "url": "_framework/netstandard.ddm5p5fsxb.wasm"
    },
    {
      "hash": "sha256-g/eiXhoFUT5ehpgmRPDMxWi9ULkF+Hzfio9ujTW/A3I=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-0iwIe+QAchK1Dbl8OAkO4rjwtbGDv5umPvatKQZGaVw=",
      "url": "docs/MWR-First-Round-Draft-Choice-English.pdf"
    },
    {
      "hash": "sha256-boY1bNun2P8DGhdXupoEuINNrFst0azy0Hd/pyUupCs=",
      "url": "docs/WealthWorksheet-Answers-v1.pdf"
    },
    {
      "hash": "sha256-Rxwu4GY7uhtw2E3QkPacuCi5VoVMimW56oarTIyiHgY=",
      "url": "docs/WealthWorksheet-Answers-v2.pdf"
    },
    {
      "hash": "sha256-mvwx1aCn+FuanBm/2Xe7f9kdLT5pB80vaV7csWhZv/U=",
      "url": "docs/WealthWorksheet-Answers-v3.pdf"
    },
    {
      "hash": "sha256-rYxEF4lV8W4KwQamII7LnX5sW8mNRo65Ljj6MQX8+QM=",
      "url": "docs/WealthWorksheet-Blank-v1.pdf"
    },
    {
      "hash": "sha256-Ugg1CVsxoQsM/WY5VWTPrPImwa+qsYq6mPL7IiSWHyY=",
      "url": "docs/WealthWorksheet-Blank-v2.pdf"
    },
    {
      "hash": "sha256-XmaYYGkkA6bJ/t0boZXQE+eH7ODG+2PYinPzK2kzusE=",
      "url": "docs/WealthWorksheet-Blank-v3.pdf"
    },
    {
      "hash": "sha256-cUWbdSoEv55gd6reBjEVorYi9tqC/NV2HV6xW4GfMVI=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-3Bn8a0+Z6aQ0C3iezz+NhW5WoBi3WAedn3HESu9SWmI=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-Sx13Amo/vs8TXYuIiGKhNJ1YOaGBzMG+HKaFbvQ6cKU=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-0EmI2DzdKKXB6UXy5Gq8s5GmQBdX2m1sKLAy24H/ih8=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_ENG.png"
    },
    {
      "hash": "sha256-epuvvqUkzf8j3FdkSX06OLRLotnxR1Pn41e8/nzi8HI=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_SPANISH.png"
    },
    {
      "hash": "sha256-2GaLGuhFCj/nV8xt3jTthp1o6hh60P/aNus5QQ5eRVg=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-ENG.png"
    },
    {
      "hash": "sha256-O31j5nWkea4Njs0tyHl/u90xobm2ie/Mr6ZoTT11uH0=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-SPANISH.png"
    },
    {
      "hash": "sha256-9penkBKfaAtQ6BcxPuu7gJSj5fyBVltlH2EPf4ohsbE=",
      "url": "images/72-hour-money-challenge.png"
    },
    {
      "hash": "sha256-dkWIZ8TeixFQnRqM+eWjOtXcZ4yXjTkyvlLfQlH0V74=",
      "url": "images/72hour-money-challenge-logo.png"
    },
    {
      "hash": "sha256-YPT2wkgMebWcXFKa+RH+bVg2S/ouYliMHTthIwOCx8I=",
      "url": "images/WealthWorksheet-202406.jpeg"
    },
    {
      "hash": "sha256-x/KjPrxSXn9qLoJTZKDdm8FPJNRQ5cge45ZoYPE0Bt4=",
      "url": "images/WealthWorksheet-Blank-v1.png"
    },
    {
      "hash": "sha256-aJc0GeZ+QyjMhs/oI5fp345z9klW7x0E6c1U+JYCCB4=",
      "url": "images/app-logo.png"
    },
    {
      "hash": "sha256-5y96EQXaqvkWqZhMLIKp1ETH3G+cUnYMN/q+D1LOD5U=",
      "url": "images/app-screenshot.jpeg"
    },
    {
      "hash": "sha256-2LHqb5ZGgFxpM5wEObzowveNpXw+a+ilaNBvefadJFA=",
      "url": "images/apple-store-logo.png"
    },
    {
      "hash": "sha256-d+haM7zmj1SK8ShTtlNReuAVVQRjL+GwpIk1Xs5t6T4=",
      "url": "images/bitcoin.png"
    },
    {
      "hash": "sha256-BIjUdqe6Pd1bpC7vw+7hDp0atyGdr9GxUsQJBoJx2EQ=",
      "url": "images/events/72day-blitz.jpg"
    },
    {
      "hash": "sha256-XnXrqTwRAmZX3ftdeYVLxQP+phWWHB8PkST74+jCYBs=",
      "url": "images/events/fridays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-durHWyGA/ZOHAHBxpNnaNiLcRGwQ80emEgIpx00WUYA=",
      "url": "images/events/megaschool-officehours.jpg"
    },
    {
      "hash": "sha256-IBM9p32DWT+bJMFE9VrGxsB4yOs+e2BFxbi2WHGqGec=",
      "url": "images/events/mondays-kingdombuilders-overview.jpeg"
    },
    {
      "hash": "sha256-+wj2nf1yWGIoA1rxQ9TO/ybqkOZKAJfnaut+qjH3b9k=",
      "url": "images/events/mondays-megaschool-bitcoin.jpg"
    },
    {
      "hash": "sha256-tH0Uy+FPtHqJtCHBiPP3gtPW06uERgfjNkUOy0nB87s=",
      "url": "images/events/mondays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-8jEuqbQVZBP96DyiL3zI+wtSyNdUn5u6WsWfXIBcmWs=",
      "url": "images/events/saturdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-+Xv2jWM+E8Sxc4EczNKAuEr9FKjmOpSUbg4LIg0LWh0=",
      "url": "images/events/saturdays-creditteam-readingclub.jpeg"
    },
    {
      "hash": "sha256-X0AhZbwv+14vuNO0AqDUFKRYCMTd2ZLA81kRaghW4QE=",
      "url": "images/events/saturdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-VHOQUj47T8XHNPWNdPyFMAcYO+WEGzQw3MxZ9Q5DM8g=",
      "url": "images/events/thursdays-corporate-training.jpeg"
    },
    {
      "hash": "sha256-I0A4MxG8FZX7weKGstIivDrLR7/fy0mypSeF+eIy5hY=",
      "url": "images/events/thursdays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-141HA0WKoh9MbO/9Rd+T+amz+dNai67KCERdkAioQOI=",
      "url": "images/events/tuesdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-Dvw+y+Aa8ZxIdpZgDkHfJgSCY+B9kSNtLXFH57uW6cs=",
      "url": "images/events/tuesdays-edm-sizzlecall.jpeg"
    },
    {
      "hash": "sha256-4MbH5AJ+zmI5rO5H7WH2E1lev2agCDo4s6f6cR1E2YE=",
      "url": "images/events/tuesdays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-nTMdPi6+geczXpLMA7LpsOm3K98aKbq6jQnUZu6Qbck=",
      "url": "images/events/tuesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-hZtojdaZEibd+x79MR5jRBDr2OmZNdAJHeRsEC/nj0s=",
      "url": "images/events/wednesdays-creditteam-noon_overview.jpeg"
    },
    {
      "hash": "sha256-6/HA01PFP4SDPeGcszKA0L/o2vSQDcXowv4gkqGBtpM=",
      "url": "images/events/wednesdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-GiIvAfyCmwkwOGgNOfNir5/R6r0tLWIlg8GlYD3u450=",
      "url": "images/events/wednesdays-edm-overview.jpeg"
    },
    {
      "hash": "sha256-U6xu7LRjVWO2sh9tsfZ7Wx11vp6GFp6yAleDXo9Baw0=",
      "url": "images/events/wednesdays-edm-training.jpg"
    },
    {
      "hash": "sha256-TJaXAdRACicRBPR49m0mrUY/nTYd5UZ+nH7ictcegqc=",
      "url": "images/events/wednesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-WfWmNx8ugrVJt8Hio8mInauBeubXz3MNU+wBO1HlhNk=",
      "url": "images/faithandfinance.jpg"
    },
    {
      "hash": "sha256-wm6Fc6KewsfvAxFUAH9Gfl54bRLK50JtpGkRRw/5XRU=",
      "url": "images/givbux-logo.png"
    },
    {
      "hash": "sha256-QCS5jSwSmQddgvloSz38p2b6gcW2IeBNZ6C/Sf7JIKE=",
      "url": "images/givbux.jpeg"
    },
    {
      "hash": "sha256-HGpfynKCRnDS/GXuvdXetRI3BuViqf5Pl3kWKo1D0uM=",
      "url": "images/google-store-logo.png"
    },
    {
      "hash": "sha256-0259fqSmtuwgBDyrjOq712+2mCWikluPGqsB3Msfbc8=",
      "url": "images/keys-to-home-ownership-banner.jpg"
    },
    {
      "hash": "sha256-Qznvfa8S28xPiRLum+paxAd/Q/xKgrVsxpe/+VTAApY=",
      "url": "images/mwr-banner.png"
    },
    {
      "hash": "sha256-398mb2+jZWyLUeJTRCc7EZVWnJMfQIGY1J3s6Z37h5E=",
      "url": "images/mwr-givbux-logo.png"
    },
    {
      "hash": "sha256-uWb3M+RKY9JEAAgaEhCUoEW8JQWeEBLW22LdJ4O0v/0=",
      "url": "images/mwr-healthshare.png"
    },
    {
      "hash": "sha256-Uyrk2Rn4TCV5YDgdsoJtyvurtxMHgqD+s6qR0CjpzVw=",
      "url": "images/mwr-logo-transparent-221x221.png"
    },
    {
      "hash": "sha256-NlYP609WoZo06NouFRFzFdQY+fH/5EcpBkjWrP3KpRA=",
      "url": "images/mwr-membership-logo.jpg"
    },
    {
      "hash": "sha256-u2LuEEAV/k6NEIA7jLbCqrEzyV0IoHMEIgF0ImsQoKg=",
      "url": "images/mwr-precious-metals.jpg"
    },
    {
      "hash": "sha256-hXeCeiWwbi+JSpfjfkrrAc7plipQKl97raN+PnBhvyQ=",
      "url": "images/next-level-strategies-logo.png"
    },
    {
      "hash": "sha256-G6O/0wfsoPFqWRsdY7QYuDVu+LEca98xXZTF2QaIwU4=",
      "url": "images/student-loan-debt-relief-tile.png"
    },
    {
      "hash": "sha256-4dLv3/Bgj1U90lWJ4WzyRf/+UpWmyuxeI5IL1wUZfLY=",
      "url": "images/words/72hour-response.jpeg"
    },
    {
      "hash": "sha256-KFV0G6KHAWfA6+8567BYhpvz1r+YccrETCb55o6qIhc=",
      "url": "images/words/72hour-share.jpeg"
    },
    {
      "hash": "sha256-cDeEIUrwWMlQUd1Ob3hQ+GLdlDkroj/DpIsC2WjE3GI=",
      "url": "images/words/72hour-success-story.jpeg"
    },
    {
      "hash": "sha256-mTGsRaDSfHWKufwB/OCEqg8x+8Gl80ha6PKO0vfcfzY=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ck2YK4oJkShd1p5P86axqOSMs6L+Be8AM0Y34BKqDVQ=",
      "url": "manifest.webmanifest"
    }
  ]
};
