self.assetsManifest = {
  "version": "8VUSN8/k",
  "assets": [
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-qJAuuKtXjsOCdGWVdhXSxJjtr26OIrMo88bEuQiSAyw=",
      "url": "MegaSchool1.styles.css"
    },
    {
      "hash": "sha256-CzOMFx1QJiQ2qwbg9cmQ2X4RRqnNAtwbMXJ6WE2L6js=",
      "url": "_content/Append.Blazor.WebShare/scripts.js"
    },
    {
      "hash": "sha256-ZzHmYioOIMEX9F8thiw1Sc+cGGFHLtMWI4q4uvO13CQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-eTpvwvDNavTSzL9mvsyAolbszT4oDL+nWD2dv0NSeUM=",
      "url": "_framework/Append.Blazor.WebShare.3trn12rddt.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-D+dfp6xcbDQeM8YkMnhT4SB0NpR70u2eqX216CNZKNs=",
      "url": "_framework/Common.Logging.Core.bxmwr8lhlv.wasm"
    },
    {
      "hash": "sha256-4AVhWz22l1X8Pl+vQZMfhD+iMZzHdeyyWpx3yGcXtXY=",
      "url": "_framework/Common.Logging.k361pnvvgn.wasm"
    },
    {
      "hash": "sha256-inYpOT3QdRYtXk2r5touWG1ode9+CIIZucz0tT9Pc0k=",
      "url": "_framework/Flow.Model.6552gktdz6.wasm"
    },
    {
      "hash": "sha256-ltj2DettcGZ4uJd0Nxitl7xgy+ZzzNEW8zGFIIfZpo0=",
      "url": "_framework/Flow.UI.yxlihez7uo.wasm"
    },
    {
      "hash": "sha256-1vkL1fNCyvLkWYtavCvKdUZS0BPY392ec7LutoPTps4=",
      "url": "_framework/FluentValidation.yuptatg8bv.wasm"
    },
    {
      "hash": "sha256-f01LWuijW3QHJCdBTz2s29K6t94BdlDploILhpJ2MFA=",
      "url": "_framework/Foundation.Model.fgzo4gwn3z.wasm"
    },
    {
      "hash": "sha256-E/28Aans5hFb8veTUQDkc572YKII09dfCbmAMZyGaH0=",
      "url": "_framework/Foundation.UI.v58bf4ww8a.wasm"
    },
    {
      "hash": "sha256-dBm5UHP8hg3pLku0if0ZJcCu16124P6GQPD92njA/wY=",
      "url": "_framework/LaunchDarkly.EventSource.ck3ehzcsxc.wasm"
    },
    {
      "hash": "sha256-n4bb06NWhW5C/aW5xe0vuKiY7gF7pFNI89fplPRISHA=",
      "url": "_framework/MegaSchool1.Model.33r292u3bx.wasm"
    },
    {
      "hash": "sha256-AF8qGrAAy7/VtNw7SR89qMMn5QXOmE11VTNj1zaQUGk=",
      "url": "_framework/MegaSchool1.ViewModel.00wgfnz9ls.wasm"
    },
    {
      "hash": "sha256-iJr0ufShuDJU/CytBClxkRDuaTw8TamBtyuwbXZ9vWQ=",
      "url": "_framework/MegaSchool1.wevybzjdid.wasm"
    },
    {
      "hash": "sha256-1ux8bhoYLro3/4y+1aY+iz+5/ycUj0ktnXGVytv54/c=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.ajau46cpsr.wasm"
    },
    {
      "hash": "sha256-ffSYDqOZVxzYrZf18i5SYksHU2hCk6YtBHyPs8Gp6RA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.vpa9p9bx40.wasm"
    },
    {
      "hash": "sha256-QKQkFRs4G1I9R1DMT9J0XMbCFxkBLC7Kmzd08TD1k4w=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.gkumsdvyty.wasm"
    },
    {
      "hash": "sha256-/XHZYGYPM1g7SVthaIe7zKfYI4nSan7XvNaU8/t1PWY=",
      "url": "_framework/Microsoft.AspNetCore.Components.d8hvx2gcw9.wasm"
    },
    {
      "hash": "sha256-yg81LpbZyuwcyyrkZTM3aTKMChytWdVOICSE9Ci0KW4=",
      "url": "_framework/Microsoft.AspNetCore.Http.Abstractions.iek203tevq.wasm"
    },
    {
      "hash": "sha256-bzIPAVp+XhD63CRn9cVTB4tJRU+oDEAuwFYoHytMhUk=",
      "url": "_framework/Microsoft.AspNetCore.Http.Features.pqxjsc5k5q.wasm"
    },
    {
      "hash": "sha256-wsc6TgWp+jOLGZ5tZlTM4BI3EdpWcYC9OYiZy4moQQo=",
      "url": "_framework/Microsoft.Bcl.TimeProvider.adm4e0udq5.wasm"
    },
    {
      "hash": "sha256-+tZeguskqI70KhaZQ/vTikvzxdaVaZyXbU905Fi3Z+w=",
      "url": "_framework/Microsoft.CSharp.6cta6swb74.wasm"
    },
    {
      "hash": "sha256-iirdN/Oqa6ha91+hkr7hvxeSi70U3czyQp3eARHgWEE=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.yiahbwv2be.wasm"
    },
    {
      "hash": "sha256-uPPr8ttoZySI0ykmqc8H1Sb2xjlsdYWuXY8gL3Yeh5k=",
      "url": "_framework/Microsoft.Extensions.Caching.Memory.w2ew568mja.wasm"
    },
    {
      "hash": "sha256-o0sc9OmlBUXwZyR5P2rtQ8O39z0YROLWihOQCG0HjZY=",
      "url": "_framework/Microsoft.Extensions.Configuration.91rmmz09rw.wasm"
    },
    {
      "hash": "sha256-rDPUuOfLDr3Pg845SZ9iM9C2IMQyHFgwQMckOqSx80k=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.8nhwb4n7e1.wasm"
    },
    {
      "hash": "sha256-o3xCpw09eAt/DIJcDuqY1zKwoGsocATyybL8H4yNIWY=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.306x0cbmgj.wasm"
    },
    {
      "hash": "sha256-I9RchUtUIR389BC9FoYb+kicxmt1RhJha7WRlbfEbBQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.dsinhvif0g.wasm"
    },
    {
      "hash": "sha256-o3DZ22g4zto3RmLtosapeKSFHJzL3VXoNJfcMmtGWGk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3snpc8ocur.wasm"
    },
    {
      "hash": "sha256-fF4cMzGvKHpUMqcJGQYpw7HZovcKYAlpTIf9UfRJrvw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.81p3hzej4b.wasm"
    },
    {
      "hash": "sha256-PkwLOyrHX2POJ7In/xwUvSjwfdKGqLQI6MU2nA8GVKw=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ae89paw0py.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-G43VRzpxOv/jn70mQKYGerJHRm5N1H05lfKyZCwczLM=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.hlif3p02c4.wasm"
    },
    {
      "hash": "sha256-VIEAytytBetEANY8vPuotzoi9AxQrqTfh3312KNQ4sQ=",
      "url": "_framework/Microsoft.Extensions.Logging.cq6tacco1g.wasm"
    },
    {
      "hash": "sha256-hnny8dNDfJgEp2x8R5JSUNSlKzSwv/h+sdHJyUCyHBU=",
      "url": "_framework/Microsoft.Extensions.Options.i5851wiypt.wasm"
    },
    {
      "hash": "sha256-xztr+8oQ6GdWkjHp9xMvQtuG9RYcMv0+Ous2M0xAXt0=",
      "url": "_framework/Microsoft.Extensions.Primitives.jx57i8n5yc.wasm"
    },
    {
      "hash": "sha256-cwIV6cgn06BArLFl2PfLREMxRWH2iEw1GkvZ/MsWeWI=",
      "url": "_framework/Microsoft.Extensions.Validation.vpl6b9qgbk.wasm"
    },
    {
      "hash": "sha256-MuT4g8rhFsAhdyp+THUNj9jtXj9Sz1eWsqBJsTBjCfw=",
      "url": "_framework/Microsoft.FeatureManagement.epe3va9svn.wasm"
    },
    {
      "hash": "sha256-FTVJx7gilBV/VWu+ibz7K8ueo7JUXPGj94aH0rf2FXQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.58jjh3bwur.wasm"
    },
    {
      "hash": "sha256-GbldsCBFoJXkRh0+gGqjalUfWE2no5fCn6sMCti6Azs=",
      "url": "_framework/Microsoft.JSInterop.rrshbo5gxz.wasm"
    },
    {
      "hash": "sha256-4YObi2yJbE77y6upRKi1elwGx48JYZSq6i/FFQquycY=",
      "url": "_framework/MudBlazor.v8qlgtmopb.wasm"
    },
    {
      "hash": "sha256-xEImZbLKcmBj78QeTJyvAiRLxzN6tO/4NERRBTzhua4=",
      "url": "_framework/NSec.Cryptography.40wv7imlqf.wasm"
    },
    {
      "hash": "sha256-+ivIDUFHJl+LmeKj7ueRPfnWM/wp2dMygtiBlp6Cqmw=",
      "url": "_framework/Nett.emyfn4350c.wasm"
    },
    {
      "hash": "sha256-erKuIr8Gjq+X/Ji4X+pGauW71/eyGT7GHVu8k+7ie8I=",
      "url": "_framework/Newtonsoft.Json.y96379yjhz.wasm"
    },
    {
      "hash": "sha256-akqbZuRazMph7GZNcPHLIOp1mgnkjdaWZMM9Up4LPfE=",
      "url": "_framework/OneOf.yq61etxwqn.wasm"
    },
    {
      "hash": "sha256-CTD9k02/4xTjReCj3MIpszrl/5WTNJ9feeOgqH5FzGY=",
      "url": "_framework/QRCoder.bv5xgxkrgl.wasm"
    },
    {
      "hash": "sha256-9TSNYolMpvLzFQ5BzzwBORl9nUGCN7kifZvzQZqGQbI=",
      "url": "_framework/Riok.Mapperly.Abstractions.bgo5wowxjs.wasm"
    },
    {
      "hash": "sha256-4eyCDrmeln8TfYIa6F9oAyuyPqJi7Y5/CaXDOfYve6A=",
      "url": "_framework/Serilog.Sinks.Async.5f8lfszthz.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-qQMQoLrp9l242W6yL7TUuGDDYZJ0LuJ1cyZrhIJPl0Y=",
      "url": "_framework/Serilog.Sinks.Console.jps0r0fyh5.wasm"
    },
    {
      "hash": "sha256-/mscr6gZntlb77C+b6BQXmc8p3g9sS2pJcVaKVRFtL8=",
      "url": "_framework/Serilog.q18h9woyzd.wasm"
    },
    {
      "hash": "sha256-4OlGR6iOblzynWZJyGahwnbIfW4TTAV3X/eIS6V+bGI=",
      "url": "_framework/Stellar.8e2okc7d9r.wasm"
    },
    {
      "hash": "sha256-sEUXCuxx4gdFaSiMEOyL1N0kpoMfj+5P7r/JmuTbn58=",
      "url": "_framework/StellarDotnetSdk.Xdr.8a87kv7h4a.wasm"
    },
    {
      "hash": "sha256-fn63Qzxz/z1I53xaAoS4OxRHB+k7o079p9ljyATQkv4=",
      "url": "_framework/StellarDotnetSdk.uwu4xy0y0y.wasm"
    },
    {
      "hash": "sha256-1J0CcTqX67NIb0OivgMKOcAkT3lZQC0zcBEoX/QtdTM=",
      "url": "_framework/System.Collections.Concurrent.cqm3cv65x0.wasm"
    },
    {
      "hash": "sha256-kGTCs8BFUMstLkIdAN2UFKyJWbcnX0FMsTNbbGKtxLA=",
      "url": "_framework/System.Collections.Immutable.c9orddvdvj.wasm"
    },
    {
      "hash": "sha256-H9qdlspaSYmVlmclMJS8i51A9Wpm/cBLRvNTFMKs2NA=",
      "url": "_framework/System.Collections.NonGeneric.l717of356z.wasm"
    },
    {
      "hash": "sha256-nhoEkPnqOYRKTbnPFCsabVT8rFinrMw5217AIPEwvQ4=",
      "url": "_framework/System.Collections.Specialized.mednf2ckot.wasm"
    },
    {
      "hash": "sha256-ZoUo3pmxFABIDqqh4ReA9DKkj+9/mbvecfSdA3hMEqI=",
      "url": "_framework/System.Collections.avs97hwten.wasm"
    },
    {
      "hash": "sha256-4QOAu11NRNr25Rje8+dq8X2cN47C7jVOp2tal/LtqPM=",
      "url": "_framework/System.ComponentModel.Annotations.vgka6k6a96.wasm"
    },
    {
      "hash": "sha256-ka/G47tB/gABsiJKBMf5gGkO1TGNYmTvIcaUkOYWLdU=",
      "url": "_framework/System.ComponentModel.Primitives.pec711vdpy.wasm"
    },
    {
      "hash": "sha256-3o5Hh63/nZchabK+KQpg2viBSqVvvgy1OSIB0yTsigo=",
      "url": "_framework/System.ComponentModel.TypeConverter.mqux5suaj0.wasm"
    },
    {
      "hash": "sha256-qSIvXmjb1k8oJp8lneUYBn/plfz0AFfrOFyq0UFlcWo=",
      "url": "_framework/System.ComponentModel.dr1z72czq3.wasm"
    },
    {
      "hash": "sha256-J/JGIuLLUWvpuU5KqobiZoUCSzkMgaR6L575IQ7DutE=",
      "url": "_framework/System.Console.hq6nk6aylu.wasm"
    },
    {
      "hash": "sha256-Z1UPXedS3/k2N9EQtazEo1Z8DFqrMyyDnhYdrS8McVA=",
      "url": "_framework/System.Data.Common.jlm46hqnyn.wasm"
    },
    {
      "hash": "sha256-dABMNL//o0eFWD8x1xmXoW8pb2hyAMBtE4fFGsapDYw=",
      "url": "_framework/System.Diagnostics.Debug.0b8ajxufxz.wasm"
    },
    {
      "hash": "sha256-FhBs+GA3atsIRTcBMbI7qck4U+dN84OUHdogYz5g//4=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.qbfyec9eug.wasm"
    },
    {
      "hash": "sha256-Z81LzpsTCHyNXqYVD5oRwDaLzC+s4CkIRgFwEjaJZaU=",
      "url": "_framework/System.Diagnostics.Tools.9su7fba6xb.wasm"
    },
    {
      "hash": "sha256-4ZrwY+Y0drjGlCcsNm497FLmsXe1zk+4cbIxkgrvekw=",
      "url": "_framework/System.Diagnostics.TraceSource.v8e4w1c7l4.wasm"
    },
    {
      "hash": "sha256-2xC8tkLnkQb/29KNq52qcIBxFli3R2JXJzJWVxQdz54=",
      "url": "_framework/System.Drawing.1d9fudivlw.wasm"
    },
    {
      "hash": "sha256-0lv1TCAixtJMB87fCnO/pTG7ZUCdDtTl1bJtLhYeQlQ=",
      "url": "_framework/System.Drawing.Common.qmubc02tyn.wasm"
    },
    {
      "hash": "sha256-W8qW4PaEOJDYVwCZ7rCeoJovlzPipO6FG50Pw4tnGeQ=",
      "url": "_framework/System.Drawing.Primitives.deiyk0hwc7.wasm"
    },
    {
      "hash": "sha256-hHFpvRnrz0KVDXuB3CucF6BhGGx8k4AwCVXbPFubPIU=",
      "url": "_framework/System.Globalization.4ahc8d1dax.wasm"
    },
    {
      "hash": "sha256-14zocchC2gJIe5ZZQDNIKjkZhiIKOzF9tz7hGF6v7X4=",
      "url": "_framework/System.IO.Compression.vecsrxkkz9.wasm"
    },
    {
      "hash": "sha256-U40nDmWhvki2ysl5ZN4nXTJ/25f2Owz3e9BIBOqLS1Y=",
      "url": "_framework/System.IO.Pipelines.5ujx8ulk75.wasm"
    },
    {
      "hash": "sha256-HTuzQW1nK14zRKwNg4p/c5YvVm6voj/Gky/P/F/v8gE=",
      "url": "_framework/System.IO.x3xqhklxht.wasm"
    },
    {
      "hash": "sha256-Z3ttJcz/R2WA6ESPXEiBCNF12kVMRTMbUUn7SqUKPZA=",
      "url": "_framework/System.Linq.Expressions.pspcj9o9tr.wasm"
    },
    {
      "hash": "sha256-W6BNDopu+bNgh+iH9NHAKLFN0wl6f/rxP99TfwlTaig=",
      "url": "_framework/System.Linq.vn08324uyf.wasm"
    },
    {
      "hash": "sha256-7aobGmrwvfmltEI/eLrNwTa+Pp2ISi8vaqYi9gC3ldk=",
      "url": "_framework/System.Memory.nnw3522kpe.wasm"
    },
    {
      "hash": "sha256-g16FQm7vqNBAJF/L1MTt+B/PmQN2PAInD/coqV6ahg4=",
      "url": "_framework/System.Net.Http.Json.77k1a2vnob.wasm"
    },
    {
      "hash": "sha256-i5UiZG7JNfFSSGrm6Q3ifL6a1EUERsV2Ib76T9f1zck=",
      "url": "_framework/System.Net.Http.b0ooaj1qtu.wasm"
    },
    {
      "hash": "sha256-osu9SqyiYXmMjyY/fvUJPr2ZoRtLJfgagCFjeUWR2LY=",
      "url": "_framework/System.Net.Primitives.yn0can6d9y.wasm"
    },
    {
      "hash": "sha256-ARFVCa+fLohks8B+WYpfP95EKmLDn++6bEC0wr1pcJw=",
      "url": "_framework/System.Net.WebSockets.57clw4vl5x.wasm"
    },
    {
      "hash": "sha256-DK+pdbp3eSc0ONlBL7BnUdL0zUjrAUfE6diTn+QhncQ=",
      "url": "_framework/System.ObjectModel.03yebkh1y8.wasm"
    },
    {
      "hash": "sha256-Oesgugj2zDBc7OX+RCzrobj48PNuynH8Ljx5C502H8E=",
      "url": "_framework/System.Private.CoreLib.p8k79wua2n.wasm"
    },
    {
      "hash": "sha256-3LvCw4xncHFdrK6YwNy48/k42V3gP2uNxzJgMbN+dCA=",
      "url": "_framework/System.Private.Uri.4mgzpxy2ly.wasm"
    },
    {
      "hash": "sha256-ei5AUSuRSSp/0CNT+5jwtQ/sqOKr/vMKUhaZKOTWpS4=",
      "url": "_framework/System.Private.Xml.2a9esjcuuw.wasm"
    },
    {
      "hash": "sha256-8Ty7SKS6Tb2daV6sg4yS51bWAAEhWR4FjTMMjCm7mic=",
      "url": "_framework/System.Private.Xml.Linq.r5ozqx6meo.wasm"
    },
    {
      "hash": "sha256-dmE3a5Ppz31gfYhuK9da4oHrWUzzf5U46S76YBKUNIg=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.6858d2qugz.wasm"
    },
    {
      "hash": "sha256-mGz/jwqHMDHZcdVBhiX5IMfxFa8EqqBtF+VBjZ2Uhuk=",
      "url": "_framework/System.Reflection.Emit.Lightweight.osm4zxycqq.wasm"
    },
    {
      "hash": "sha256-xBCI8wS1AZiyLrx6D35VbB+CjycdEKz1x/z36iCqtYg=",
      "url": "_framework/System.Reflection.Extensions.gzwt7vylak.wasm"
    },
    {
      "hash": "sha256-0as3GpS5RofTsrGMXBcS34uPilKSzARn71mLryBe+bo=",
      "url": "_framework/System.Reflection.Primitives.fwq0oxl9pf.wasm"
    },
    {
      "hash": "sha256-MZCRIxKzlBP9FSASgkPoVrvA624BkgFApt1qsx/Uqx4=",
      "url": "_framework/System.Reflection.TypeExtensions.jbbqciq8b9.wasm"
    },
    {
      "hash": "sha256-U4io31f5v5B6fGc76TUBrpVPCQ0oVbkyFxnpL/2WIhE=",
      "url": "_framework/System.Reflection.nfycr5isoc.wasm"
    },
    {
      "hash": "sha256-u/eNPIAYP6d5Z0tdPMdQclF7QOrW5fpieOMlruwaLfs=",
      "url": "_framework/System.Resources.ResourceManager.7lgjtosj5c.wasm"
    },
    {
      "hash": "sha256-4KoDHhVVwSPKEGYTl/UuM/4sqCm1ls5is17+QM6gQsE=",
      "url": "_framework/System.Runtime.4jjxcagyxc.wasm"
    },
    {
      "hash": "sha256-lrjRtgrnaCrMrmvsWY2+bcPiFR0EngQ7sLFI1O/6RuE=",
      "url": "_framework/System.Runtime.Extensions.q0hx7j6yef.wasm"
    },
    {
      "hash": "sha256-jj+hXeHxXtNJ/yFTBFkWF83+YlrVlIlndehUiym2PoQ=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.yzg2xf6fe9.wasm"
    },
    {
      "hash": "sha256-CvVF45oD6xxmgaKuoAln4vqxbPAsjbSMXtfitwyVKRY=",
      "url": "_framework/System.Runtime.InteropServices.erflqqzeho.wasm"
    },
    {
      "hash": "sha256-X7jOH/ihkgitmIbv5fBmNppoD9ag6pUkqauoJqECvgo=",
      "url": "_framework/System.Runtime.Numerics.lb8m4s8ywd.wasm"
    },
    {
      "hash": "sha256-rU8ZorfDfZEQvTAQbwvZETPGjnV5rkKeBT2+l89bFUc=",
      "url": "_framework/System.Runtime.Serialization.Formatters.52eqitmxnn.wasm"
    },
    {
      "hash": "sha256-voxOgOiKM6JOUjCOj+4sgJpYV5rEJRVakQVb0I88Vyo=",
      "url": "_framework/System.Runtime.Serialization.Primitives.ivpz33h5d5.wasm"
    },
    {
      "hash": "sha256-Cxz1FYIcdYbj0ddjuJp6LthIDCtpHqOyuKczO1OPQ0I=",
      "url": "_framework/System.Security.Claims.hpuy017w6c.wasm"
    },
    {
      "hash": "sha256-hKMNJ/YWhot8vEcs7PY/9CGeBAlMrLi3+N7OLdQP3U0=",
      "url": "_framework/System.Security.Cryptography.syubmvk1s4.wasm"
    },
    {
      "hash": "sha256-EqhdmjskdXq4NFLcRAoPFWph6dq+13oNbXJuaowAv54=",
      "url": "_framework/System.Text.Encoding.Extensions.marjb3nkfl.wasm"
    },
    {
      "hash": "sha256-2AJx7UJbSdhxIIxVUwo/KsaEso8ASMyskwQoafu4C0s=",
      "url": "_framework/System.Text.Encoding.kx6b7p229q.wasm"
    },
    {
      "hash": "sha256-p0I/gu1hfXiqySJ0vHMhSHtvZJzEZT0WOYNWq4peun0=",
      "url": "_framework/System.Text.Encodings.Web.5h7q1pbb0u.wasm"
    },
    {
      "hash": "sha256-XIIX/xvjYrV7teVKOJXIvVJWax4CmH4jwVQOyme+H38=",
      "url": "_framework/System.Text.Json.gfbywxdois.wasm"
    },
    {
      "hash": "sha256-3u1QcLx2Eo0qWXs7gNqenu7627BRAENciUKiOEageAs=",
      "url": "_framework/System.Text.RegularExpressions.u0w74vfozo.wasm"
    },
    {
      "hash": "sha256-mpiG+bQzlM0ouyTFmhZ30nixG4S69v/HCdmYp778Z70=",
      "url": "_framework/System.Threading.Tasks.q4f0wj0g09.wasm"
    },
    {
      "hash": "sha256-Rzr3hUNRgvkL4MnG9Lmx7QadniwZlb8lzsD6h4nGGKo=",
      "url": "_framework/System.Threading.rrmk6lxpyq.wasm"
    },
    {
      "hash": "sha256-s+S9NmMw1qRTcIFgnmH6VnPmnXyRv+aYrlpK+bmrmK8=",
      "url": "_framework/System.Web.HttpUtility.7f9wd4bua1.wasm"
    },
    {
      "hash": "sha256-x8MB2DkAOXhOCsJ/AzpobuVUqt727s2bp6fDdDQ1d8A=",
      "url": "_framework/System.Xml.Linq.bno46imr5t.wasm"
    },
    {
      "hash": "sha256-nU8UM6Qot475zFyIGBYW5CBAeALuyZ1u+LBgp1+PzC8=",
      "url": "_framework/System.Xml.ReaderWriter.bip1pw44g0.wasm"
    },
    {
      "hash": "sha256-x+Be558FFtu3CEezZ5CBQOiBDTFlTvOeF0TCOMYR1zs=",
      "url": "_framework/System.Xml.XDocument.9wrwyiyftk.wasm"
    },
    {
      "hash": "sha256-d1dcH2nxptL8QLqZqtRI5G+lrjrbUKrUOnC/yloVB98=",
      "url": "_framework/System.l9jolnojrw.wasm"
    },
    {
      "hash": "sha256-PxBQUtV7HW4AVxrjPhV5zpEV+LTsFd90t3iDHolxOfE=",
      "url": "_framework/Tommy.z379sas3l7.wasm"
    },
    {
      "hash": "sha256-L4dW3CE3WZuDb7SMHfeekPWt8ONC309xQ5Jkf9BOPcg=",
      "url": "_framework/USA.Model.d51cwai1l0.wasm"
    },
    {
      "hash": "sha256-nNPyM7TP7Sp4N054o563oU6FZnHcAw8jJU3H+H0sJ0I=",
      "url": "_framework/ValueOf.ccmezia1vt.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-ATJeRc9Tb7Fr4SBjWgWzVz2GBlg8zmb4xG2FFWL82LQ=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-GtKGBjR0oNHH8N8wrYDGHHr0dSYxzdT3MlPD86y1s3A=",
      "url": "_framework/dotnet.native.2xc6rn7urr.js"
    },
    {
      "hash": "sha256-6kGBJ0lqq7LpmsCYlzbxoitwgO/r+6Mj6FP1IsgYIvA=",
      "url": "_framework/dotnet.native.uapwaby06n.wasm"
    },
    {
      "hash": "sha256-2lZh9yO0fnzm3Xt7yV+Kox3DH3nK7L8hDhm84VT1xco=",
      "url": "_framework/dotnet.runtime.2tx45g8lli.js"
    },
    {
      "hash": "sha256-Kn+8j510dQQ7rCE6F347fJpZAM2x+uiNlRwyiSmicSI=",
      "url": "_framework/dotnetstandard-bip32.qwdn989y8v.wasm"
    },
    {
      "hash": "sha256-j6wIkVxwXBJ3QLeksRyb1pJbcfEF1waXK3cbImnAl3Q=",
      "url": "_framework/dotnetstandard-bip39.vke3c9voq8.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-79vMOXUn+9s3md6DJKEq3mwLD+puvILzzhjEHHeMbno=",
      "url": "_framework/netstandard.bpihzcvvvx.wasm"
    },
    {
      "hash": "sha256-uYIIIrK+dFCcqi/0TgNZ4xW7uofGcer8ZVzf9NdxuOQ=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-0iwIe+QAchK1Dbl8OAkO4rjwtbGDv5umPvatKQZGaVw=",
      "url": "docs/MWR-First-Round-Draft-Choice-English.pdf"
    },
    {
      "hash": "sha256-boY1bNun2P8DGhdXupoEuINNrFst0azy0Hd/pyUupCs=",
      "url": "docs/WealthWorksheet-Answers-v1.pdf"
    },
    {
      "hash": "sha256-Rxwu4GY7uhtw2E3QkPacuCi5VoVMimW56oarTIyiHgY=",
      "url": "docs/WealthWorksheet-Answers-v2.pdf"
    },
    {
      "hash": "sha256-mvwx1aCn+FuanBm/2Xe7f9kdLT5pB80vaV7csWhZv/U=",
      "url": "docs/WealthWorksheet-Answers-v3.pdf"
    },
    {
      "hash": "sha256-rYxEF4lV8W4KwQamII7LnX5sW8mNRo65Ljj6MQX8+QM=",
      "url": "docs/WealthWorksheet-Blank-v1.pdf"
    },
    {
      "hash": "sha256-Ugg1CVsxoQsM/WY5VWTPrPImwa+qsYq6mPL7IiSWHyY=",
      "url": "docs/WealthWorksheet-Blank-v2.pdf"
    },
    {
      "hash": "sha256-XmaYYGkkA6bJ/t0boZXQE+eH7ODG+2PYinPzK2kzusE=",
      "url": "docs/WealthWorksheet-Blank-v3.pdf"
    },
    {
      "hash": "sha256-popaLln2zKQ/l924OcSkESlwM3jS90DiTMXekYOiqMI=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-wZr73HvKWRIbBCkD4NkhEuaxiBKhP+xRcpRSuOzopa0=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-TPplinUrtMzreyyaN5F6MKIl1R3MKpTHPyUxj25NjHs=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-0EmI2DzdKKXB6UXy5Gq8s5GmQBdX2m1sKLAy24H/ih8=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_ENG.png"
    },
    {
      "hash": "sha256-epuvvqUkzf8j3FdkSX06OLRLotnxR1Pn41e8/nzi8HI=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_SPANISH.png"
    },
    {
      "hash": "sha256-2GaLGuhFCj/nV8xt3jTthp1o6hh60P/aNus5QQ5eRVg=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-ENG.png"
    },
    {
      "hash": "sha256-O31j5nWkea4Njs0tyHl/u90xobm2ie/Mr6ZoTT11uH0=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-SPANISH.png"
    },
    {
      "hash": "sha256-9penkBKfaAtQ6BcxPuu7gJSj5fyBVltlH2EPf4ohsbE=",
      "url": "images/72-hour-money-challenge.png"
    },
    {
      "hash": "sha256-dkWIZ8TeixFQnRqM+eWjOtXcZ4yXjTkyvlLfQlH0V74=",
      "url": "images/72hour-money-challenge-logo.png"
    },
    {
      "hash": "sha256-YPT2wkgMebWcXFKa+RH+bVg2S/ouYliMHTthIwOCx8I=",
      "url": "images/WealthWorksheet-202406.jpeg"
    },
    {
      "hash": "sha256-x/KjPrxSXn9qLoJTZKDdm8FPJNRQ5cge45ZoYPE0Bt4=",
      "url": "images/WealthWorksheet-Blank-v1.png"
    },
    {
      "hash": "sha256-aJc0GeZ+QyjMhs/oI5fp345z9klW7x0E6c1U+JYCCB4=",
      "url": "images/app-logo.png"
    },
    {
      "hash": "sha256-5y96EQXaqvkWqZhMLIKp1ETH3G+cUnYMN/q+D1LOD5U=",
      "url": "images/app-screenshot.jpeg"
    },
    {
      "hash": "sha256-2LHqb5ZGgFxpM5wEObzowveNpXw+a+ilaNBvefadJFA=",
      "url": "images/apple-store-logo.png"
    },
    {
      "hash": "sha256-d+haM7zmj1SK8ShTtlNReuAVVQRjL+GwpIk1Xs5t6T4=",
      "url": "images/bitcoin.png"
    },
    {
      "hash": "sha256-BIjUdqe6Pd1bpC7vw+7hDp0atyGdr9GxUsQJBoJx2EQ=",
      "url": "images/events/72day-blitz.jpg"
    },
    {
      "hash": "sha256-XnXrqTwRAmZX3ftdeYVLxQP+phWWHB8PkST74+jCYBs=",
      "url": "images/events/fridays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-durHWyGA/ZOHAHBxpNnaNiLcRGwQ80emEgIpx00WUYA=",
      "url": "images/events/megaschool-officehours.jpg"
    },
    {
      "hash": "sha256-IBM9p32DWT+bJMFE9VrGxsB4yOs+e2BFxbi2WHGqGec=",
      "url": "images/events/mondays-kingdombuilders-overview.jpeg"
    },
    {
      "hash": "sha256-+wj2nf1yWGIoA1rxQ9TO/ybqkOZKAJfnaut+qjH3b9k=",
      "url": "images/events/mondays-megaschool-bitcoin.jpg"
    },
    {
      "hash": "sha256-tH0Uy+FPtHqJtCHBiPP3gtPW06uERgfjNkUOy0nB87s=",
      "url": "images/events/mondays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-8jEuqbQVZBP96DyiL3zI+wtSyNdUn5u6WsWfXIBcmWs=",
      "url": "images/events/saturdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-+Xv2jWM+E8Sxc4EczNKAuEr9FKjmOpSUbg4LIg0LWh0=",
      "url": "images/events/saturdays-creditteam-readingclub.jpeg"
    },
    {
      "hash": "sha256-X0AhZbwv+14vuNO0AqDUFKRYCMTd2ZLA81kRaghW4QE=",
      "url": "images/events/saturdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-VHOQUj47T8XHNPWNdPyFMAcYO+WEGzQw3MxZ9Q5DM8g=",
      "url": "images/events/thursdays-corporate-training.jpeg"
    },
    {
      "hash": "sha256-I0A4MxG8FZX7weKGstIivDrLR7/fy0mypSeF+eIy5hY=",
      "url": "images/events/thursdays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-141HA0WKoh9MbO/9Rd+T+amz+dNai67KCERdkAioQOI=",
      "url": "images/events/tuesdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-Dvw+y+Aa8ZxIdpZgDkHfJgSCY+B9kSNtLXFH57uW6cs=",
      "url": "images/events/tuesdays-edm-sizzlecall.jpeg"
    },
    {
      "hash": "sha256-4MbH5AJ+zmI5rO5H7WH2E1lev2agCDo4s6f6cR1E2YE=",
      "url": "images/events/tuesdays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-nTMdPi6+geczXpLMA7LpsOm3K98aKbq6jQnUZu6Qbck=",
      "url": "images/events/tuesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-hZtojdaZEibd+x79MR5jRBDr2OmZNdAJHeRsEC/nj0s=",
      "url": "images/events/wednesdays-creditteam-noon_overview.jpeg"
    },
    {
      "hash": "sha256-6/HA01PFP4SDPeGcszKA0L/o2vSQDcXowv4gkqGBtpM=",
      "url": "images/events/wednesdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-GiIvAfyCmwkwOGgNOfNir5/R6r0tLWIlg8GlYD3u450=",
      "url": "images/events/wednesdays-edm-overview.jpeg"
    },
    {
      "hash": "sha256-U6xu7LRjVWO2sh9tsfZ7Wx11vp6GFp6yAleDXo9Baw0=",
      "url": "images/events/wednesdays-edm-training.jpg"
    },
    {
      "hash": "sha256-TJaXAdRACicRBPR49m0mrUY/nTYd5UZ+nH7ictcegqc=",
      "url": "images/events/wednesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-WfWmNx8ugrVJt8Hio8mInauBeubXz3MNU+wBO1HlhNk=",
      "url": "images/faithandfinance.jpg"
    },
    {
      "hash": "sha256-wm6Fc6KewsfvAxFUAH9Gfl54bRLK50JtpGkRRw/5XRU=",
      "url": "images/givbux-logo.png"
    },
    {
      "hash": "sha256-QCS5jSwSmQddgvloSz38p2b6gcW2IeBNZ6C/Sf7JIKE=",
      "url": "images/givbux.jpeg"
    },
    {
      "hash": "sha256-HGpfynKCRnDS/GXuvdXetRI3BuViqf5Pl3kWKo1D0uM=",
      "url": "images/google-store-logo.png"
    },
    {
      "hash": "sha256-0259fqSmtuwgBDyrjOq712+2mCWikluPGqsB3Msfbc8=",
      "url": "images/keys-to-home-ownership-banner.jpg"
    },
    {
      "hash": "sha256-Qznvfa8S28xPiRLum+paxAd/Q/xKgrVsxpe/+VTAApY=",
      "url": "images/mwr-banner.png"
    },
    {
      "hash": "sha256-398mb2+jZWyLUeJTRCc7EZVWnJMfQIGY1J3s6Z37h5E=",
      "url": "images/mwr-givbux-logo.png"
    },
    {
      "hash": "sha256-uWb3M+RKY9JEAAgaEhCUoEW8JQWeEBLW22LdJ4O0v/0=",
      "url": "images/mwr-healthshare.png"
    },
    {
      "hash": "sha256-Uyrk2Rn4TCV5YDgdsoJtyvurtxMHgqD+s6qR0CjpzVw=",
      "url": "images/mwr-logo-transparent-221x221.png"
    },
    {
      "hash": "sha256-NlYP609WoZo06NouFRFzFdQY+fH/5EcpBkjWrP3KpRA=",
      "url": "images/mwr-membership-logo.jpg"
    },
    {
      "hash": "sha256-u2LuEEAV/k6NEIA7jLbCqrEzyV0IoHMEIgF0ImsQoKg=",
      "url": "images/mwr-precious-metals.jpg"
    },
    {
      "hash": "sha256-hXeCeiWwbi+JSpfjfkrrAc7plipQKl97raN+PnBhvyQ=",
      "url": "images/next-level-strategies-logo.png"
    },
    {
      "hash": "sha256-G6O/0wfsoPFqWRsdY7QYuDVu+LEca98xXZTF2QaIwU4=",
      "url": "images/student-loan-debt-relief-tile.png"
    },
    {
      "hash": "sha256-4dLv3/Bgj1U90lWJ4WzyRf/+UpWmyuxeI5IL1wUZfLY=",
      "url": "images/words/72hour-response.jpeg"
    },
    {
      "hash": "sha256-KFV0G6KHAWfA6+8567BYhpvz1r+YccrETCb55o6qIhc=",
      "url": "images/words/72hour-share.jpeg"
    },
    {
      "hash": "sha256-cDeEIUrwWMlQUd1Ob3hQ+GLdlDkroj/DpIsC2WjE3GI=",
      "url": "images/words/72hour-success-story.jpeg"
    },
    {
      "hash": "sha256-04Fl0x1rA9CPcboPDn2DZQhG71NLFfghaFtYTueB+Q4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ck2YK4oJkShd1p5P86axqOSMs6L+Be8AM0Y34BKqDVQ=",
      "url": "manifest.webmanifest"
    }
  ]
};
