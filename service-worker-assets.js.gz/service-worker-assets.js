self.assetsManifest = {
  "version": "uGXH1ycb",
  "assets": [
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-qJAuuKtXjsOCdGWVdhXSxJjtr26OIrMo88bEuQiSAyw=",
      "url": "MegaSchool1.styles.css"
    },
    {
      "hash": "sha256-CzOMFx1QJiQ2qwbg9cmQ2X4RRqnNAtwbMXJ6WE2L6js=",
      "url": "_content/Append.Blazor.WebShare/scripts.js"
    },
    {
      "hash": "sha256-ZzHmYioOIMEX9F8thiw1Sc+cGGFHLtMWI4q4uvO13CQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-eTpvwvDNavTSzL9mvsyAolbszT4oDL+nWD2dv0NSeUM=",
      "url": "_framework/Append.Blazor.WebShare.3trn12rddt.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-D+dfp6xcbDQeM8YkMnhT4SB0NpR70u2eqX216CNZKNs=",
      "url": "_framework/Common.Logging.Core.bxmwr8lhlv.wasm"
    },
    {
      "hash": "sha256-4AVhWz22l1X8Pl+vQZMfhD+iMZzHdeyyWpx3yGcXtXY=",
      "url": "_framework/Common.Logging.k361pnvvgn.wasm"
    },
    {
      "hash": "sha256-bQhmZmVl5aeYEwg+06OGiZKQK9ATxqnS+0kWv9jRVDI=",
      "url": "_framework/Flow.Model.v9jsn85jdj.wasm"
    },
    {
      "hash": "sha256-iI+p02/j3ek1zNN7UaqtWVu4EVu47IPd2KaAZp5k22Y=",
      "url": "_framework/Flow.UI.gmeem6iutt.wasm"
    },
    {
      "hash": "sha256-1vkL1fNCyvLkWYtavCvKdUZS0BPY392ec7LutoPTps4=",
      "url": "_framework/FluentValidation.yuptatg8bv.wasm"
    },
    {
      "hash": "sha256-F/YYMJJFfhWjkmN1iNTZjAsJM+5atXQtTtFOaP3OScM=",
      "url": "_framework/Foundation.Model.5lnasqf11n.wasm"
    },
    {
      "hash": "sha256-k2Jh4st8E2P3LBnobB/52IJc+h2pX5oklAGVqrjCjXA=",
      "url": "_framework/Foundation.UI.pl2djr1oyu.wasm"
    },
    {
      "hash": "sha256-dBm5UHP8hg3pLku0if0ZJcCu16124P6GQPD92njA/wY=",
      "url": "_framework/LaunchDarkly.EventSource.ck3ehzcsxc.wasm"
    },
    {
      "hash": "sha256-QCWbKhZneiyOgPOgfPiIE0cpB8ZAsz+1yF5DlGQwL7s=",
      "url": "_framework/MegaSchool1.86ijo8s4ot.wasm"
    },
    {
      "hash": "sha256-Qfsgae6ha/oTHnTc4SPaSiRYndNPCYiq19LRxSW7rsI=",
      "url": "_framework/MegaSchool1.Model.18utto6vtt.wasm"
    },
    {
      "hash": "sha256-wt0RfwSmIYgDIAzNg+Gpt7RVC08tGlinZDLSEYMuxdg=",
      "url": "_framework/MegaSchool1.ViewModel.mrivd8e5f4.wasm"
    },
    {
      "hash": "sha256-1ux8bhoYLro3/4y+1aY+iz+5/ycUj0ktnXGVytv54/c=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.ajau46cpsr.wasm"
    },
    {
      "hash": "sha256-ffSYDqOZVxzYrZf18i5SYksHU2hCk6YtBHyPs8Gp6RA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.vpa9p9bx40.wasm"
    },
    {
      "hash": "sha256-QKQkFRs4G1I9R1DMT9J0XMbCFxkBLC7Kmzd08TD1k4w=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.gkumsdvyty.wasm"
    },
    {
      "hash": "sha256-/XHZYGYPM1g7SVthaIe7zKfYI4nSan7XvNaU8/t1PWY=",
      "url": "_framework/Microsoft.AspNetCore.Components.d8hvx2gcw9.wasm"
    },
    {
      "hash": "sha256-yg81LpbZyuwcyyrkZTM3aTKMChytWdVOICSE9Ci0KW4=",
      "url": "_framework/Microsoft.AspNetCore.Http.Abstractions.iek203tevq.wasm"
    },
    {
      "hash": "sha256-bzIPAVp+XhD63CRn9cVTB4tJRU+oDEAuwFYoHytMhUk=",
      "url": "_framework/Microsoft.AspNetCore.Http.Features.pqxjsc5k5q.wasm"
    },
    {
      "hash": "sha256-wsc6TgWp+jOLGZ5tZlTM4BI3EdpWcYC9OYiZy4moQQo=",
      "url": "_framework/Microsoft.Bcl.TimeProvider.adm4e0udq5.wasm"
    },
    {
      "hash": "sha256-uTWnW+IznZM0LihHqUnws6t9BX4wkuS+HMTWIZae6Xo=",
      "url": "_framework/Microsoft.CSharp.dz4yo8jaui.wasm"
    },
    {
      "hash": "sha256-iirdN/Oqa6ha91+hkr7hvxeSi70U3czyQp3eARHgWEE=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.yiahbwv2be.wasm"
    },
    {
      "hash": "sha256-uPPr8ttoZySI0ykmqc8H1Sb2xjlsdYWuXY8gL3Yeh5k=",
      "url": "_framework/Microsoft.Extensions.Caching.Memory.w2ew568mja.wasm"
    },
    {
      "hash": "sha256-o0sc9OmlBUXwZyR5P2rtQ8O39z0YROLWihOQCG0HjZY=",
      "url": "_framework/Microsoft.Extensions.Configuration.91rmmz09rw.wasm"
    },
    {
      "hash": "sha256-rDPUuOfLDr3Pg845SZ9iM9C2IMQyHFgwQMckOqSx80k=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.8nhwb4n7e1.wasm"
    },
    {
      "hash": "sha256-o3xCpw09eAt/DIJcDuqY1zKwoGsocATyybL8H4yNIWY=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.306x0cbmgj.wasm"
    },
    {
      "hash": "sha256-I9RchUtUIR389BC9FoYb+kicxmt1RhJha7WRlbfEbBQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.dsinhvif0g.wasm"
    },
    {
      "hash": "sha256-o3DZ22g4zto3RmLtosapeKSFHJzL3VXoNJfcMmtGWGk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3snpc8ocur.wasm"
    },
    {
      "hash": "sha256-fF4cMzGvKHpUMqcJGQYpw7HZovcKYAlpTIf9UfRJrvw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.81p3hzej4b.wasm"
    },
    {
      "hash": "sha256-PkwLOyrHX2POJ7In/xwUvSjwfdKGqLQI6MU2nA8GVKw=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ae89paw0py.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-G43VRzpxOv/jn70mQKYGerJHRm5N1H05lfKyZCwczLM=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.hlif3p02c4.wasm"
    },
    {
      "hash": "sha256-VIEAytytBetEANY8vPuotzoi9AxQrqTfh3312KNQ4sQ=",
      "url": "_framework/Microsoft.Extensions.Logging.cq6tacco1g.wasm"
    },
    {
      "hash": "sha256-hnny8dNDfJgEp2x8R5JSUNSlKzSwv/h+sdHJyUCyHBU=",
      "url": "_framework/Microsoft.Extensions.Options.i5851wiypt.wasm"
    },
    {
      "hash": "sha256-xztr+8oQ6GdWkjHp9xMvQtuG9RYcMv0+Ous2M0xAXt0=",
      "url": "_framework/Microsoft.Extensions.Primitives.jx57i8n5yc.wasm"
    },
    {
      "hash": "sha256-cwIV6cgn06BArLFl2PfLREMxRWH2iEw1GkvZ/MsWeWI=",
      "url": "_framework/Microsoft.Extensions.Validation.vpl6b9qgbk.wasm"
    },
    {
      "hash": "sha256-MuT4g8rhFsAhdyp+THUNj9jtXj9Sz1eWsqBJsTBjCfw=",
      "url": "_framework/Microsoft.FeatureManagement.epe3va9svn.wasm"
    },
    {
      "hash": "sha256-FTVJx7gilBV/VWu+ibz7K8ueo7JUXPGj94aH0rf2FXQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.58jjh3bwur.wasm"
    },
    {
      "hash": "sha256-GbldsCBFoJXkRh0+gGqjalUfWE2no5fCn6sMCti6Azs=",
      "url": "_framework/Microsoft.JSInterop.rrshbo5gxz.wasm"
    },
    {
      "hash": "sha256-4YObi2yJbE77y6upRKi1elwGx48JYZSq6i/FFQquycY=",
      "url": "_framework/MudBlazor.v8qlgtmopb.wasm"
    },
    {
      "hash": "sha256-xEImZbLKcmBj78QeTJyvAiRLxzN6tO/4NERRBTzhua4=",
      "url": "_framework/NSec.Cryptography.40wv7imlqf.wasm"
    },
    {
      "hash": "sha256-+ivIDUFHJl+LmeKj7ueRPfnWM/wp2dMygtiBlp6Cqmw=",
      "url": "_framework/Nett.emyfn4350c.wasm"
    },
    {
      "hash": "sha256-erKuIr8Gjq+X/Ji4X+pGauW71/eyGT7GHVu8k+7ie8I=",
      "url": "_framework/Newtonsoft.Json.y96379yjhz.wasm"
    },
    {
      "hash": "sha256-akqbZuRazMph7GZNcPHLIOp1mgnkjdaWZMM9Up4LPfE=",
      "url": "_framework/OneOf.yq61etxwqn.wasm"
    },
    {
      "hash": "sha256-CTD9k02/4xTjReCj3MIpszrl/5WTNJ9feeOgqH5FzGY=",
      "url": "_framework/QRCoder.bv5xgxkrgl.wasm"
    },
    {
      "hash": "sha256-9TSNYolMpvLzFQ5BzzwBORl9nUGCN7kifZvzQZqGQbI=",
      "url": "_framework/Riok.Mapperly.Abstractions.bgo5wowxjs.wasm"
    },
    {
      "hash": "sha256-4eyCDrmeln8TfYIa6F9oAyuyPqJi7Y5/CaXDOfYve6A=",
      "url": "_framework/Serilog.Sinks.Async.5f8lfszthz.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-qQMQoLrp9l242W6yL7TUuGDDYZJ0LuJ1cyZrhIJPl0Y=",
      "url": "_framework/Serilog.Sinks.Console.jps0r0fyh5.wasm"
    },
    {
      "hash": "sha256-/mscr6gZntlb77C+b6BQXmc8p3g9sS2pJcVaKVRFtL8=",
      "url": "_framework/Serilog.q18h9woyzd.wasm"
    },
    {
      "hash": "sha256-qwZ1KWhOYAz/qU554zF3cFobe6YCXdnPYWnZZt6w7LE=",
      "url": "_framework/Stellar.xhl6rzuo0h.wasm"
    },
    {
      "hash": "sha256-sEUXCuxx4gdFaSiMEOyL1N0kpoMfj+5P7r/JmuTbn58=",
      "url": "_framework/StellarDotnetSdk.Xdr.8a87kv7h4a.wasm"
    },
    {
      "hash": "sha256-fn63Qzxz/z1I53xaAoS4OxRHB+k7o079p9ljyATQkv4=",
      "url": "_framework/StellarDotnetSdk.uwu4xy0y0y.wasm"
    },
    {
      "hash": "sha256-l/RHuyhY2ZZppaQdDzedA7dnHNLOxXM+nkXUwXaUWdo=",
      "url": "_framework/System.Collections.Concurrent.zdmlkbjbkx.wasm"
    },
    {
      "hash": "sha256-PvAYfRltyPpklmxA60nBXJjdqWMj/Iyfx5p8xktqBRM=",
      "url": "_framework/System.Collections.Immutable.a1hsrwzobj.wasm"
    },
    {
      "hash": "sha256-XlL7rF5lwK8DmL2j2rqdNuTDpQut6BmRny+dv2KL1Kw=",
      "url": "_framework/System.Collections.NonGeneric.ivvcq3e87z.wasm"
    },
    {
      "hash": "sha256-uYfujqU2nMX05VKWYNKWim9MYSCmHw7cVqWcfgGibLI=",
      "url": "_framework/System.Collections.Specialized.f6ylcjy0c2.wasm"
    },
    {
      "hash": "sha256-w5mQegWEEoVJtkopkZBUH5bV2kSTBTviTMsEUzDo5fI=",
      "url": "_framework/System.Collections.r2y99zjhy3.wasm"
    },
    {
      "hash": "sha256-5QA7+HkNwa6PHdzov3+8HYI+1xfkhcyzMm30jPvgeXE=",
      "url": "_framework/System.ComponentModel.36gpd97ysv.wasm"
    },
    {
      "hash": "sha256-acJcFgaz0yxYsBTWw/4LymherRfVxXHjwIdCKZXkM1I=",
      "url": "_framework/System.ComponentModel.Annotations.tnhs2miclr.wasm"
    },
    {
      "hash": "sha256-uL4N2pflJxzr1ON1vXjr8vqWX0qEsddfCrIWottEwNY=",
      "url": "_framework/System.ComponentModel.Primitives.sz0tb7vxs9.wasm"
    },
    {
      "hash": "sha256-06zwVJNku+rqmj05ew8SSn9PQi1vpLprC+rZyWKuQiU=",
      "url": "_framework/System.ComponentModel.TypeConverter.lmg0bhruec.wasm"
    },
    {
      "hash": "sha256-1wcX3zujTnT7GrlbjjeSc/IUWVX3ALNhcBX3XPPha0c=",
      "url": "_framework/System.Console.9wqgckr0ap.wasm"
    },
    {
      "hash": "sha256-7M/K0pRSG3rS/Clo4Jolb0efOTvfrVuplRBo2R7uRn0=",
      "url": "_framework/System.Data.Common.cyksncbgmd.wasm"
    },
    {
      "hash": "sha256-XSwOZ4nbSWYudhFuhO1YNlKcu2Z8qZvPO5SOv+tm8m8=",
      "url": "_framework/System.Diagnostics.Debug.xztqi43ktv.wasm"
    },
    {
      "hash": "sha256-/lp6kkdod8lBLMxtqoDUu8BUUWaPOPH0anMc7i6h/T8=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.q5r6w3g2wx.wasm"
    },
    {
      "hash": "sha256-+3F8OahXEOVy6owrdWdSMgNG+EDI3j6K4+/GSraFuVs=",
      "url": "_framework/System.Diagnostics.Tools.vfswyuo8vx.wasm"
    },
    {
      "hash": "sha256-dt1JHigDqhoXj+HhwgRYjygFs6D7mS8g/aBKgyjyS0k=",
      "url": "_framework/System.Diagnostics.TraceSource.q3nyw5yz1h.wasm"
    },
    {
      "hash": "sha256-+P6iv9BqBaSzIMcl/QoNjmkXV39NyvncqPXZ1Ss7398=",
      "url": "_framework/System.Drawing.8wgi7x9zvd.wasm"
    },
    {
      "hash": "sha256-0lv1TCAixtJMB87fCnO/pTG7ZUCdDtTl1bJtLhYeQlQ=",
      "url": "_framework/System.Drawing.Common.qmubc02tyn.wasm"
    },
    {
      "hash": "sha256-cPeRfqoksAc1oSiR+HzIO4+IxKV/w64OqZrqsqScqBo=",
      "url": "_framework/System.Drawing.Primitives.4ft2yh3696.wasm"
    },
    {
      "hash": "sha256-md1D4eSK+LDTiAbk5LRbp2Mxcol08qneG9wGVK5Vr7M=",
      "url": "_framework/System.Globalization.bvgw5o8w1p.wasm"
    },
    {
      "hash": "sha256-Sr1dhL4LlErbzKaA7alTb3VRJveQocyHyxfez5wk9qM=",
      "url": "_framework/System.IO.Compression.2lkiyaor5l.wasm"
    },
    {
      "hash": "sha256-5NlyiKMjQMJVLZ+E92VHzP4NXkvjJnT4LTZkWqm0KJc=",
      "url": "_framework/System.IO.Pipelines.orwcdf2bqi.wasm"
    },
    {
      "hash": "sha256-pRKv6dfDFSS6FpNmjnqQzj+AjVgXDsh64jTR94qWArk=",
      "url": "_framework/System.IO.nhynfw37e3.wasm"
    },
    {
      "hash": "sha256-p2T1f6lg/nD+fr07tp/uJ9zJ4fttwO0jzxHV+bMNhg0=",
      "url": "_framework/System.Linq.Expressions.1ixr5p5p5u.wasm"
    },
    {
      "hash": "sha256-K47KSg61Oto6CxbR1D8N2LklwYd44NwXWWIy75nrXX0=",
      "url": "_framework/System.Linq.fnuw3exd3l.wasm"
    },
    {
      "hash": "sha256-5O+BMV7Dq7UwcEjeDwhegcCUUgKRB7H5gLR9z9DQFuk=",
      "url": "_framework/System.Memory.w59il31nc6.wasm"
    },
    {
      "hash": "sha256-k223H/0uJfyp7lpUrk3LYFMzI/QtSSXLktjx0+xcWLY=",
      "url": "_framework/System.Net.Http.Json.pxfn6r9pfh.wasm"
    },
    {
      "hash": "sha256-/k12zd/UT2kmtX/PO9sTCMP6m0eJ+u8cc1PTtqgOi4E=",
      "url": "_framework/System.Net.Http.irmvxi88oc.wasm"
    },
    {
      "hash": "sha256-UahqkcMOXEJoNKjaPNT48Ok/gqauicExaW89OlPteGU=",
      "url": "_framework/System.Net.Primitives.tlg9wfjwmd.wasm"
    },
    {
      "hash": "sha256-c//5CcChHpXU/XnifDGd+NVkm5vQ+0Fk2BEObcT/ojA=",
      "url": "_framework/System.Net.WebSockets.lu0tjhgio7.wasm"
    },
    {
      "hash": "sha256-j/orGPp1WbDW9TRouvgYdbl3ncK+dWY428tyqKP02e0=",
      "url": "_framework/System.ObjectModel.ln6z1u24vr.wasm"
    },
    {
      "hash": "sha256-mFQAqYZ9S2pW7JT3Y0F7rhzDIgCGM7cA1R7zw6kOM0I=",
      "url": "_framework/System.Private.CoreLib.srrkrsasif.wasm"
    },
    {
      "hash": "sha256-H1IwSdrCEksREHZXwErxWqjaVwMdaUyMvA3WXC1KjEE=",
      "url": "_framework/System.Private.Uri.fk8res3sk7.wasm"
    },
    {
      "hash": "sha256-uxqFezximY/7QqBiz05os7l68GU473yQhP1x4lJ9GjY=",
      "url": "_framework/System.Private.Xml.Linq.9r7wqr5ket.wasm"
    },
    {
      "hash": "sha256-ovY8V8k8nur+NE3HZonRNvEUtv+4jZangwEDrdZPmuI=",
      "url": "_framework/System.Private.Xml.usxt1mg8ns.wasm"
    },
    {
      "hash": "sha256-tO1LTneKAuG7tc+NDEEKWFH9Pg0k62QSKGvF3e8kgrA=",
      "url": "_framework/System.Reflection.89w4ylwbn9.wasm"
    },
    {
      "hash": "sha256-ZZ8Yl+tzEDXUuAnCPVKMYQ3olBU48bipKbHLrw78TnI=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.ffvu6crlqb.wasm"
    },
    {
      "hash": "sha256-MnoV33rJKyM4ob2m+B4jDhQln2wUkc36gzI6zNKR+ps=",
      "url": "_framework/System.Reflection.Emit.Lightweight.u1f06yqgqz.wasm"
    },
    {
      "hash": "sha256-3xqz//2IyNPr4uaDIFWQTmFjQxaKFcRYDgwP/wx8KDY=",
      "url": "_framework/System.Reflection.Extensions.tltding4n8.wasm"
    },
    {
      "hash": "sha256-d3K/0sOH7IpBeQB9qj98KMmsPZy9QPcDIJxaT7Gw7LE=",
      "url": "_framework/System.Reflection.Primitives.nsfubnmzhb.wasm"
    },
    {
      "hash": "sha256-kNnJ+RHEozfNEMX+lEeYLoQ/qqsKs5X0IksUjDwwlO8=",
      "url": "_framework/System.Reflection.TypeExtensions.oyxa8955na.wasm"
    },
    {
      "hash": "sha256-rzsjU0SdLdtN57+SnhMz6W9X65XZlvePQlqX5BVqKCg=",
      "url": "_framework/System.Resources.ResourceManager.fc7yyo2wuo.wasm"
    },
    {
      "hash": "sha256-oNOqwHgsL3/CA1KsKlausLnUUGQajTSHzgs/AlEK3uI=",
      "url": "_framework/System.Runtime.8qfvfnyuij.wasm"
    },
    {
      "hash": "sha256-MwMeaKpEzHst1sHpmTQHWVFtrggSDUtWNhGUElv+Etw=",
      "url": "_framework/System.Runtime.Extensions.fdlc8xm6we.wasm"
    },
    {
      "hash": "sha256-WAM5OMcJO64InQovrLZ46el9w7eLyMLnICLGedHyr8Q=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ktbegkrd8y.wasm"
    },
    {
      "hash": "sha256-r8Ztf9k3pidO52kSEG4MfbYntS0Ya7SRK5VLtqp4OwI=",
      "url": "_framework/System.Runtime.InteropServices.r1vi55krpt.wasm"
    },
    {
      "hash": "sha256-GwaMeV+F5iwXZWAFtwQAOMX1TjJWmAFTLLHF1/6hLN8=",
      "url": "_framework/System.Runtime.Numerics.fjyd2hvcwv.wasm"
    },
    {
      "hash": "sha256-+YaMGRdd7ZmWXFWXUbs7wAb9AErwWb+DXX3IATt3hHU=",
      "url": "_framework/System.Runtime.Serialization.Formatters.f6ygocimgm.wasm"
    },
    {
      "hash": "sha256-jPfC1q8DbgFXTIquSgGCsJ+Al3bChS9lXjm8hJAICJU=",
      "url": "_framework/System.Runtime.Serialization.Primitives.467lwwghw2.wasm"
    },
    {
      "hash": "sha256-kOuejKC5I+0pwiY5sIjOVBsZu7H2ph9+jzms53XYTwQ=",
      "url": "_framework/System.Security.Claims.0cu0q6u9kn.wasm"
    },
    {
      "hash": "sha256-pngPXztuidO3+fqWlGjQdo1w8RIRzDEn2e+HFgLxQZ4=",
      "url": "_framework/System.Security.Cryptography.ii0jmyqv0d.wasm"
    },
    {
      "hash": "sha256-MFV1rWqnq/S/AtEdCoyvydacYIxU2Sajb1ETJ+dT8Bk=",
      "url": "_framework/System.Text.Encoding.Extensions.gwksaqyl68.wasm"
    },
    {
      "hash": "sha256-o63gpTsRvuxG9UkyNwfbxJduFqLhZSoQptAl9CMTqTc=",
      "url": "_framework/System.Text.Encoding.vxaho1m9n4.wasm"
    },
    {
      "hash": "sha256-SjSXjB+ypX/cHtZAKKaQQwNop8x2URA+CydzqPhhArs=",
      "url": "_framework/System.Text.Encodings.Web.6ki720vlaa.wasm"
    },
    {
      "hash": "sha256-twoGEhXkbn7PwkG5Jm6f7GpZAGzFWaBw2XBps4xzQic=",
      "url": "_framework/System.Text.Json.p4ez38ke2a.wasm"
    },
    {
      "hash": "sha256-Zj6Ki5nG81eZTZJ0un0pxm5z9Cl8YDgBFredx4YeTkM=",
      "url": "_framework/System.Text.RegularExpressions.yalvo3gl4q.wasm"
    },
    {
      "hash": "sha256-eMonUhW1IdCiSLJ/YEDOub6+agzHH09uMU3OnGlNYaU=",
      "url": "_framework/System.Threading.Tasks.cfixa8namn.wasm"
    },
    {
      "hash": "sha256-/eoeqi8pIdj6qpku1wAfSipmpEIApfz/Pdm7/JlvGSw=",
      "url": "_framework/System.Threading.zkdp4s1yjq.wasm"
    },
    {
      "hash": "sha256-4QbhU0+9gvIeGm4N1ZCIf4ZT/xTTrB5gPML7X67VPjw=",
      "url": "_framework/System.Web.HttpUtility.lrg4dv5e48.wasm"
    },
    {
      "hash": "sha256-sndSZhomaMgZJSV8YYnGu9JTyssQJWIyipDAPAgJbwQ=",
      "url": "_framework/System.Xml.Linq.ysq4rzz6yg.wasm"
    },
    {
      "hash": "sha256-pkepRWKXWuxVlCYbRa7kuXBhefDpCQNzuk8yaZAmeBg=",
      "url": "_framework/System.Xml.ReaderWriter.azvzbgdjdb.wasm"
    },
    {
      "hash": "sha256-oKCFPxbJmB4N740vSfh6aSW9DwD8E+iInzbreWfFrs8=",
      "url": "_framework/System.Xml.XDocument.gw18htm123.wasm"
    },
    {
      "hash": "sha256-JRSnUKU4RCZCvwQXVaK87jabHPSnQK1daxG24xvCico=",
      "url": "_framework/System.deed694j9w.wasm"
    },
    {
      "hash": "sha256-PxBQUtV7HW4AVxrjPhV5zpEV+LTsFd90t3iDHolxOfE=",
      "url": "_framework/Tommy.z379sas3l7.wasm"
    },
    {
      "hash": "sha256-qn1WWBR2cGej7YhatZX6ARAsCZD95BQuX7tYq5/bk/w=",
      "url": "_framework/USA.Model.ua9h1u2lnl.wasm"
    },
    {
      "hash": "sha256-nNPyM7TP7Sp4N054o563oU6FZnHcAw8jJU3H+H0sJ0I=",
      "url": "_framework/ValueOf.ccmezia1vt.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-sq79hYIBeRToZZ1Ee5iz9IwUF2jPcmv7dQtLnGO1Bu0=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-JxFUgLurxxSF0g68VKS0L/dGNiBybkAZnUdlx2hPrm8=",
      "url": "_framework/dotnet.native.1y1k06luyd.wasm"
    },
    {
      "hash": "sha256-Ng1YRUXAPEMVgMKHUzUR3RKlznVh6JAPyT/XIWibp50=",
      "url": "_framework/dotnet.native.6cc34y250c.js"
    },
    {
      "hash": "sha256-ArknccFM1sHNVcih0x1h52AG+abNCoQjl6BlVrv3ePw=",
      "url": "_framework/dotnet.runtime.q5rqv3xrhm.js"
    },
    {
      "hash": "sha256-Kn+8j510dQQ7rCE6F347fJpZAM2x+uiNlRwyiSmicSI=",
      "url": "_framework/dotnetstandard-bip32.qwdn989y8v.wasm"
    },
    {
      "hash": "sha256-j6wIkVxwXBJ3QLeksRyb1pJbcfEF1waXK3cbImnAl3Q=",
      "url": "_framework/dotnetstandard-bip39.vke3c9voq8.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-GUwjYsl7dJ4g0OYQ+3okOZT1Q/h3vRyvBg/TO/Nxm7I=",
      "url": "_framework/netstandard.x66jemw30e.wasm"
    },
    {
      "hash": "sha256-96BPyRCjNzMEUfQKYiOwZjnA1FzWp9acz24DPvBm8/E=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-0iwIe+QAchK1Dbl8OAkO4rjwtbGDv5umPvatKQZGaVw=",
      "url": "docs/MWR-First-Round-Draft-Choice-English.pdf"
    },
    {
      "hash": "sha256-boY1bNun2P8DGhdXupoEuINNrFst0azy0Hd/pyUupCs=",
      "url": "docs/WealthWorksheet-Answers-v1.pdf"
    },
    {
      "hash": "sha256-Rxwu4GY7uhtw2E3QkPacuCi5VoVMimW56oarTIyiHgY=",
      "url": "docs/WealthWorksheet-Answers-v2.pdf"
    },
    {
      "hash": "sha256-mvwx1aCn+FuanBm/2Xe7f9kdLT5pB80vaV7csWhZv/U=",
      "url": "docs/WealthWorksheet-Answers-v3.pdf"
    },
    {
      "hash": "sha256-rYxEF4lV8W4KwQamII7LnX5sW8mNRo65Ljj6MQX8+QM=",
      "url": "docs/WealthWorksheet-Blank-v1.pdf"
    },
    {
      "hash": "sha256-Ugg1CVsxoQsM/WY5VWTPrPImwa+qsYq6mPL7IiSWHyY=",
      "url": "docs/WealthWorksheet-Blank-v2.pdf"
    },
    {
      "hash": "sha256-XmaYYGkkA6bJ/t0boZXQE+eH7ODG+2PYinPzK2kzusE=",
      "url": "docs/WealthWorksheet-Blank-v3.pdf"
    },
    {
      "hash": "sha256-popaLln2zKQ/l924OcSkESlwM3jS90DiTMXekYOiqMI=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-wZr73HvKWRIbBCkD4NkhEuaxiBKhP+xRcpRSuOzopa0=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-TPplinUrtMzreyyaN5F6MKIl1R3MKpTHPyUxj25NjHs=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-0EmI2DzdKKXB6UXy5Gq8s5GmQBdX2m1sKLAy24H/ih8=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_ENG.png"
    },
    {
      "hash": "sha256-epuvvqUkzf8j3FdkSX06OLRLotnxR1Pn41e8/nzi8HI=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_SPANISH.png"
    },
    {
      "hash": "sha256-2GaLGuhFCj/nV8xt3jTthp1o6hh60P/aNus5QQ5eRVg=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-ENG.png"
    },
    {
      "hash": "sha256-O31j5nWkea4Njs0tyHl/u90xobm2ie/Mr6ZoTT11uH0=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-SPANISH.png"
    },
    {
      "hash": "sha256-9penkBKfaAtQ6BcxPuu7gJSj5fyBVltlH2EPf4ohsbE=",
      "url": "images/72-hour-money-challenge.png"
    },
    {
      "hash": "sha256-dkWIZ8TeixFQnRqM+eWjOtXcZ4yXjTkyvlLfQlH0V74=",
      "url": "images/72hour-money-challenge-logo.png"
    },
    {
      "hash": "sha256-YPT2wkgMebWcXFKa+RH+bVg2S/ouYliMHTthIwOCx8I=",
      "url": "images/WealthWorksheet-202406.jpeg"
    },
    {
      "hash": "sha256-x/KjPrxSXn9qLoJTZKDdm8FPJNRQ5cge45ZoYPE0Bt4=",
      "url": "images/WealthWorksheet-Blank-v1.png"
    },
    {
      "hash": "sha256-aJc0GeZ+QyjMhs/oI5fp345z9klW7x0E6c1U+JYCCB4=",
      "url": "images/app-logo.png"
    },
    {
      "hash": "sha256-5y96EQXaqvkWqZhMLIKp1ETH3G+cUnYMN/q+D1LOD5U=",
      "url": "images/app-screenshot.jpeg"
    },
    {
      "hash": "sha256-2LHqb5ZGgFxpM5wEObzowveNpXw+a+ilaNBvefadJFA=",
      "url": "images/apple-store-logo.png"
    },
    {
      "hash": "sha256-d+haM7zmj1SK8ShTtlNReuAVVQRjL+GwpIk1Xs5t6T4=",
      "url": "images/bitcoin.png"
    },
    {
      "hash": "sha256-BIjUdqe6Pd1bpC7vw+7hDp0atyGdr9GxUsQJBoJx2EQ=",
      "url": "images/events/72day-blitz.jpg"
    },
    {
      "hash": "sha256-XnXrqTwRAmZX3ftdeYVLxQP+phWWHB8PkST74+jCYBs=",
      "url": "images/events/fridays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-durHWyGA/ZOHAHBxpNnaNiLcRGwQ80emEgIpx00WUYA=",
      "url": "images/events/megaschool-officehours.jpg"
    },
    {
      "hash": "sha256-IBM9p32DWT+bJMFE9VrGxsB4yOs+e2BFxbi2WHGqGec=",
      "url": "images/events/mondays-kingdombuilders-overview.jpeg"
    },
    {
      "hash": "sha256-+wj2nf1yWGIoA1rxQ9TO/ybqkOZKAJfnaut+qjH3b9k=",
      "url": "images/events/mondays-megaschool-bitcoin.jpg"
    },
    {
      "hash": "sha256-tH0Uy+FPtHqJtCHBiPP3gtPW06uERgfjNkUOy0nB87s=",
      "url": "images/events/mondays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-8jEuqbQVZBP96DyiL3zI+wtSyNdUn5u6WsWfXIBcmWs=",
      "url": "images/events/saturdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-+Xv2jWM+E8Sxc4EczNKAuEr9FKjmOpSUbg4LIg0LWh0=",
      "url": "images/events/saturdays-creditteam-readingclub.jpeg"
    },
    {
      "hash": "sha256-X0AhZbwv+14vuNO0AqDUFKRYCMTd2ZLA81kRaghW4QE=",
      "url": "images/events/saturdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-VHOQUj47T8XHNPWNdPyFMAcYO+WEGzQw3MxZ9Q5DM8g=",
      "url": "images/events/thursdays-corporate-training.jpeg"
    },
    {
      "hash": "sha256-I0A4MxG8FZX7weKGstIivDrLR7/fy0mypSeF+eIy5hY=",
      "url": "images/events/thursdays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-141HA0WKoh9MbO/9Rd+T+amz+dNai67KCERdkAioQOI=",
      "url": "images/events/tuesdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-Dvw+y+Aa8ZxIdpZgDkHfJgSCY+B9kSNtLXFH57uW6cs=",
      "url": "images/events/tuesdays-edm-sizzlecall.jpeg"
    },
    {
      "hash": "sha256-4MbH5AJ+zmI5rO5H7WH2E1lev2agCDo4s6f6cR1E2YE=",
      "url": "images/events/tuesdays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-nTMdPi6+geczXpLMA7LpsOm3K98aKbq6jQnUZu6Qbck=",
      "url": "images/events/tuesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-hZtojdaZEibd+x79MR5jRBDr2OmZNdAJHeRsEC/nj0s=",
      "url": "images/events/wednesdays-creditteam-noon_overview.jpeg"
    },
    {
      "hash": "sha256-6/HA01PFP4SDPeGcszKA0L/o2vSQDcXowv4gkqGBtpM=",
      "url": "images/events/wednesdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-GiIvAfyCmwkwOGgNOfNir5/R6r0tLWIlg8GlYD3u450=",
      "url": "images/events/wednesdays-edm-overview.jpeg"
    },
    {
      "hash": "sha256-U6xu7LRjVWO2sh9tsfZ7Wx11vp6GFp6yAleDXo9Baw0=",
      "url": "images/events/wednesdays-edm-training.jpg"
    },
    {
      "hash": "sha256-TJaXAdRACicRBPR49m0mrUY/nTYd5UZ+nH7ictcegqc=",
      "url": "images/events/wednesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-WfWmNx8ugrVJt8Hio8mInauBeubXz3MNU+wBO1HlhNk=",
      "url": "images/faithandfinance.jpg"
    },
    {
      "hash": "sha256-wm6Fc6KewsfvAxFUAH9Gfl54bRLK50JtpGkRRw/5XRU=",
      "url": "images/givbux-logo.png"
    },
    {
      "hash": "sha256-QCS5jSwSmQddgvloSz38p2b6gcW2IeBNZ6C/Sf7JIKE=",
      "url": "images/givbux.jpeg"
    },
    {
      "hash": "sha256-HGpfynKCRnDS/GXuvdXetRI3BuViqf5Pl3kWKo1D0uM=",
      "url": "images/google-store-logo.png"
    },
    {
      "hash": "sha256-0259fqSmtuwgBDyrjOq712+2mCWikluPGqsB3Msfbc8=",
      "url": "images/keys-to-home-ownership-banner.jpg"
    },
    {
      "hash": "sha256-Qznvfa8S28xPiRLum+paxAd/Q/xKgrVsxpe/+VTAApY=",
      "url": "images/mwr-banner.png"
    },
    {
      "hash": "sha256-398mb2+jZWyLUeJTRCc7EZVWnJMfQIGY1J3s6Z37h5E=",
      "url": "images/mwr-givbux-logo.png"
    },
    {
      "hash": "sha256-uWb3M+RKY9JEAAgaEhCUoEW8JQWeEBLW22LdJ4O0v/0=",
      "url": "images/mwr-healthshare.png"
    },
    {
      "hash": "sha256-Uyrk2Rn4TCV5YDgdsoJtyvurtxMHgqD+s6qR0CjpzVw=",
      "url": "images/mwr-logo-transparent-221x221.png"
    },
    {
      "hash": "sha256-NlYP609WoZo06NouFRFzFdQY+fH/5EcpBkjWrP3KpRA=",
      "url": "images/mwr-membership-logo.jpg"
    },
    {
      "hash": "sha256-u2LuEEAV/k6NEIA7jLbCqrEzyV0IoHMEIgF0ImsQoKg=",
      "url": "images/mwr-precious-metals.jpg"
    },
    {
      "hash": "sha256-hXeCeiWwbi+JSpfjfkrrAc7plipQKl97raN+PnBhvyQ=",
      "url": "images/next-level-strategies-logo.png"
    },
    {
      "hash": "sha256-G6O/0wfsoPFqWRsdY7QYuDVu+LEca98xXZTF2QaIwU4=",
      "url": "images/student-loan-debt-relief-tile.png"
    },
    {
      "hash": "sha256-4dLv3/Bgj1U90lWJ4WzyRf/+UpWmyuxeI5IL1wUZfLY=",
      "url": "images/words/72hour-response.jpeg"
    },
    {
      "hash": "sha256-KFV0G6KHAWfA6+8567BYhpvz1r+YccrETCb55o6qIhc=",
      "url": "images/words/72hour-share.jpeg"
    },
    {
      "hash": "sha256-cDeEIUrwWMlQUd1Ob3hQ+GLdlDkroj/DpIsC2WjE3GI=",
      "url": "images/words/72hour-success-story.jpeg"
    },
    {
      "hash": "sha256-04Fl0x1rA9CPcboPDn2DZQhG71NLFfghaFtYTueB+Q4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ck2YK4oJkShd1p5P86axqOSMs6L+Be8AM0Y34BKqDVQ=",
      "url": "manifest.webmanifest"
    }
  ]
};
