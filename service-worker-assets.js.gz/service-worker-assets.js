self.assetsManifest = {
  "version": "D7JM5c9o",
  "assets": [
    {
      "hash": "sha256-qJAuuKtXjsOCdGWVdhXSxJjtr26OIrMo88bEuQiSAyw=",
      "url": "MegaSchool1.styles.css"
    },
    {
      "hash": "sha256-CzOMFx1QJiQ2qwbg9cmQ2X4RRqnNAtwbMXJ6WE2L6js=",
      "url": "_content/Append.Blazor.WebShare/scripts.js"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-3FM/mjas9rQiq2CY+FQPy1Pe1iCLSx/qZltQxK4dcuQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-Qf9/gSPxTxchB08Wi5WXxjPqw2IQvnyVUW27s7cwoUo=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-eTpvwvDNavTSzL9mvsyAolbszT4oDL+nWD2dv0NSeUM=",
      "url": "_framework/Append.Blazor.WebShare.3trn12rddt.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-D+dfp6xcbDQeM8YkMnhT4SB0NpR70u2eqX216CNZKNs=",
      "url": "_framework/Common.Logging.Core.bxmwr8lhlv.wasm"
    },
    {
      "hash": "sha256-4AVhWz22l1X8Pl+vQZMfhD+iMZzHdeyyWpx3yGcXtXY=",
      "url": "_framework/Common.Logging.k361pnvvgn.wasm"
    },
    {
      "hash": "sha256-2175LB/iwYIBH806gXAphk5mIs50XaAeresgdNkwSLI=",
      "url": "_framework/Flow.Model.b0tcpudqef.wasm"
    },
    {
      "hash": "sha256-uqWZA/aCLSkErnSHjUvRWNckIlxHP8dlwHsjqSHW2F0=",
      "url": "_framework/Flow.UI.a8tz39kp24.wasm"
    },
    {
      "hash": "sha256-UzXm5ONFC2YfuSahJleOJiIJNURatHcRQIkXq2hoPew=",
      "url": "_framework/FluentValidation.b28mz0qrx7.wasm"
    },
    {
      "hash": "sha256-a9i0u3QfSI9hsLOAXu0bVB8ykxHBxUbsLDk8RCH1Etc=",
      "url": "_framework/Foundation.Model.3m9fiyeoao.wasm"
    },
    {
      "hash": "sha256-1IAFKQqDSv3E+rnGYIeLNSa+CcZpv3TxZNpv0vJHHow=",
      "url": "_framework/Foundation.UI.gzvx7ad7pd.wasm"
    },
    {
      "hash": "sha256-dBm5UHP8hg3pLku0if0ZJcCu16124P6GQPD92njA/wY=",
      "url": "_framework/LaunchDarkly.EventSource.ck3ehzcsxc.wasm"
    },
    {
      "hash": "sha256-HcKurrsT8XXOEfuX38ydDKr2JaYydrS6a3L/kubSBfI=",
      "url": "_framework/MegaSchool1.Model.j0ppjgkqu0.wasm"
    },
    {
      "hash": "sha256-2DpMBzWLUaELUGiUA9evIGe6qJufgjCCWxVn2KfXC5c=",
      "url": "_framework/MegaSchool1.ViewModel.4h7o3jv83n.wasm"
    },
    {
      "hash": "sha256-BJO836kByiULY/cbRe8UtLbqmMQey/IGG5+9/gBtits=",
      "url": "_framework/MegaSchool1.sawinyizy1.wasm"
    },
    {
      "hash": "sha256-yGtRyWog8EOfGIdvWv1mCpd20igD3vfthkBk1hpBneA=",
      "url": "_framework/Microsoft.AspNetCore.Components.8cwmf2t78u.wasm"
    },
    {
      "hash": "sha256-wLAnSToKhAdANlddmxpIga58uZjR9Bhci0yJmMDbeVI=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.sdhnt3x3c2.wasm"
    },
    {
      "hash": "sha256-/WGA4gzsRBSgn4dSnr0hs25Nnmbud2BYWkVrYvolM1E=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.v1o5lcbgkx.wasm"
    },
    {
      "hash": "sha256-Btr36zSIY2SFZYBoBQtL+5GODbcBEJ2FJ1FTEB7t+DA=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.enjawhubve.wasm"
    },
    {
      "hash": "sha256-7wgz1ZHwXmXV8y00xn+jT4BGeuCQQbVYGQl+PNvBfnQ=",
      "url": "_framework/Microsoft.AspNetCore.Http.Abstractions.5jy9omvvsv.wasm"
    },
    {
      "hash": "sha256-bzIPAVp+XhD63CRn9cVTB4tJRU+oDEAuwFYoHytMhUk=",
      "url": "_framework/Microsoft.AspNetCore.Http.Features.pqxjsc5k5q.wasm"
    },
    {
      "hash": "sha256-CNGtY2Zlow4ZwwKlyWeyosbzAaSllziAZuYdTuTHIRM=",
      "url": "_framework/Microsoft.Bcl.TimeProvider.0mrxvq2io8.wasm"
    },
    {
      "hash": "sha256-JC2YvZnT2aU8ngUCJNpLh8elPjkgy5h1CgCTa3rGnek=",
      "url": "_framework/Microsoft.CSharp.48o26oud82.wasm"
    },
    {
      "hash": "sha256-IbyZLQO5kYUfGJm8A19uSKZz7y90mhIivEfB/wBtPZM=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.pe5rw2s9bj.wasm"
    },
    {
      "hash": "sha256-GoQgc9M/wkr8ecOlhwPADpDnv49RWOaImwiAdtxA3kI=",
      "url": "_framework/Microsoft.Extensions.Caching.Memory.64h9p1av56.wasm"
    },
    {
      "hash": "sha256-TF+jlVOgkdy9RHm+5PWNbpWdAzQSekwnCQymVv/q/04=",
      "url": "_framework/Microsoft.Extensions.Configuration.8baqur0fk0.wasm"
    },
    {
      "hash": "sha256-X0O7bavFYyB+/qgYsHVl87CVfkNPqg5mI1AQSiylkQ4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.3bptiz6kdg.wasm"
    },
    {
      "hash": "sha256-pDTl0fevy0i6hlfWPKhPeAcEOtGIXkx4yhbQIxDOiPM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.c0lsqeepwk.wasm"
    },
    {
      "hash": "sha256-kKMubKJ3c2lATxpoAuoDqMjzQ+a0M6Ym35pK74cMK2o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.0cm6d8ej68.wasm"
    },
    {
      "hash": "sha256-vdglnaA9bW0xPKndVDK+NIEH2UslqNUiYsodedIgwEs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.dc4riqdziq.wasm"
    },
    {
      "hash": "sha256-Sgs1bgmGaF2mv6rWcaihc+x48ZQQAidfzYwZvYX5WJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.uum8fsrbn4.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-G0i+/sxAp0r8CJyWyjHHbO6LMaHyzGsXAYxbRuV8cxw=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.ti0lisgez8.wasm"
    },
    {
      "hash": "sha256-2+VnYOEguGBb4cgKgX0k5UQofj3j/uCA1Lu6r9a8a1k=",
      "url": "_framework/Microsoft.Extensions.Logging.f7t4lpceon.wasm"
    },
    {
      "hash": "sha256-iCJ7MgEDmi8gJJ4kr+vCM0UW+W51Th0XAwRG1vPU9Ak=",
      "url": "_framework/Microsoft.Extensions.Options.sv9qmqvsmm.wasm"
    },
    {
      "hash": "sha256-ErEKVPpEL4W3RxzbY5qyj0gep+KplVtlJH1JL6NMXeA=",
      "url": "_framework/Microsoft.Extensions.Primitives.6u3ifz5xik.wasm"
    },
    {
      "hash": "sha256-pUQ1TKpjn//YXHff9NljvsJweYnPAhH9SAWbffUL0ts=",
      "url": "_framework/Microsoft.FeatureManagement.3afc3cpfvm.wasm"
    },
    {
      "hash": "sha256-J+EIgpKic+b31zC+zbI+Yb0thttj3hcXdmi7RDSLThc=",
      "url": "_framework/Microsoft.JSInterop.1mohczt7ym.wasm"
    },
    {
      "hash": "sha256-mpyjzA6YBuV9Qx5BUC8YbXP9YjZlM+k7YTVawzXJFgk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.imfqvv3x5h.wasm"
    },
    {
      "hash": "sha256-yGAlg7BqteCk6uozLs6K6wRGjq5HbJXE/xjX4FOPCoc=",
      "url": "_framework/MudBlazor.0e0xj77126.wasm"
    },
    {
      "hash": "sha256-xEImZbLKcmBj78QeTJyvAiRLxzN6tO/4NERRBTzhua4=",
      "url": "_framework/NSec.Cryptography.40wv7imlqf.wasm"
    },
    {
      "hash": "sha256-+ivIDUFHJl+LmeKj7ueRPfnWM/wp2dMygtiBlp6Cqmw=",
      "url": "_framework/Nett.emyfn4350c.wasm"
    },
    {
      "hash": "sha256-erKuIr8Gjq+X/Ji4X+pGauW71/eyGT7GHVu8k+7ie8I=",
      "url": "_framework/Newtonsoft.Json.y96379yjhz.wasm"
    },
    {
      "hash": "sha256-akqbZuRazMph7GZNcPHLIOp1mgnkjdaWZMM9Up4LPfE=",
      "url": "_framework/OneOf.yq61etxwqn.wasm"
    },
    {
      "hash": "sha256-ayRMl7l1GF4h65kNE0bKJ4lrGPZxmR+OkvPUFrQ11oU=",
      "url": "_framework/QRCoder.jqr4n2c9hc.wasm"
    },
    {
      "hash": "sha256-ZwToh0+onnsuEEi4ISoq7tGM9S9l8NmpDtywTW7VASI=",
      "url": "_framework/Riok.Mapperly.Abstractions.v2oa0z4fia.wasm"
    },
    {
      "hash": "sha256-4eyCDrmeln8TfYIa6F9oAyuyPqJi7Y5/CaXDOfYve6A=",
      "url": "_framework/Serilog.Sinks.Async.5f8lfszthz.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-IU1wbWWmevTzax9faR7cBTh3+/SHme1dNs0/OXItpXc=",
      "url": "_framework/Serilog.Sinks.Console.rtr49hgfiq.wasm"
    },
    {
      "hash": "sha256-AOLPsUlcm6GyVW4GsJ6IBJ6Ztz0VuRKlTrhFfUwqGN0=",
      "url": "_framework/Serilog.gky8dcecvc.wasm"
    },
    {
      "hash": "sha256-j0Wk/ky2IB8w9EW/0tAuOS527cMsM5g4iHi8UqQwnLY=",
      "url": "_framework/Stellar.3jql85d3s6.wasm"
    },
    {
      "hash": "sha256-sEUXCuxx4gdFaSiMEOyL1N0kpoMfj+5P7r/JmuTbn58=",
      "url": "_framework/StellarDotnetSdk.Xdr.8a87kv7h4a.wasm"
    },
    {
      "hash": "sha256-fn63Qzxz/z1I53xaAoS4OxRHB+k7o079p9ljyATQkv4=",
      "url": "_framework/StellarDotnetSdk.uwu4xy0y0y.wasm"
    },
    {
      "hash": "sha256-jLaqA8UaPUHpJof4+q9/IimXjCO84vWME52hywJluPI=",
      "url": "_framework/System.Collections.485o55cga7.wasm"
    },
    {
      "hash": "sha256-ZmQMGXTrPpISFuq46cvfja3x3WtYF+fJJFmfz8VLpRA=",
      "url": "_framework/System.Collections.Concurrent.idcjvcvy1b.wasm"
    },
    {
      "hash": "sha256-aibLl7RFhQKdkRr4Ec2yjF/10PSLXJt50zxQXEbGl4E=",
      "url": "_framework/System.Collections.Immutable.umy92ou5gw.wasm"
    },
    {
      "hash": "sha256-b2TyqDsXxxpFLaYtkipr6sWzDXMIiawHLOJJXsY3PLU=",
      "url": "_framework/System.Collections.NonGeneric.jf0hkh1nym.wasm"
    },
    {
      "hash": "sha256-WstPUIcTN10zMi7Vth/IbTUjsPkL9zbi8EDqqMkr61I=",
      "url": "_framework/System.Collections.Specialized.m1e90zr8c0.wasm"
    },
    {
      "hash": "sha256-ZfKAsOlMiuXcBMphhLMkHYyGlkEhJvBsGno4nYd7Gio=",
      "url": "_framework/System.ComponentModel.32hl4s9ve4.wasm"
    },
    {
      "hash": "sha256-vxJN+A1/g0pu8hqltL0NyqhId8uoBfeSNEkXL5tGKN4=",
      "url": "_framework/System.ComponentModel.Annotations.b97cr22c6f.wasm"
    },
    {
      "hash": "sha256-KKs9gXFoBdGxbGHS/yJDhPYM6rgMt4eJCSfGt4UkeTY=",
      "url": "_framework/System.ComponentModel.Primitives.o861rdj44a.wasm"
    },
    {
      "hash": "sha256-HCvBDi8nvxth3/zr/Bq6xs3kDlnvDka6JOUU4rW2cIY=",
      "url": "_framework/System.ComponentModel.TypeConverter.grkcfaqr9n.wasm"
    },
    {
      "hash": "sha256-Zq9KQLIWD6eOuVi/EkiNkdnwvHdkDkfvkwtXB0voKso=",
      "url": "_framework/System.Console.y6qw8749mx.wasm"
    },
    {
      "hash": "sha256-qfpx1DNW8SOBMQQ7z/GJ/SuUAgbAOBr8WvyUr3LpvR0=",
      "url": "_framework/System.Data.Common.noq92pphz3.wasm"
    },
    {
      "hash": "sha256-u2MfyJOO54wdIcIVHD8pMvh+cucIBVWm5blPZDeCVaY=",
      "url": "_framework/System.Diagnostics.Debug.32zt9t5apb.wasm"
    },
    {
      "hash": "sha256-OB7aF4WLNGFq1kPzqzNnOCBkJuspHNQoeDDaOGGixME=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.khco1e3gx2.wasm"
    },
    {
      "hash": "sha256-Mxcay359yKHjmDrCEN1QbTjrtEQ2sBkIJYNSiUI03N0=",
      "url": "_framework/System.Diagnostics.Tools.hfag0sq3es.wasm"
    },
    {
      "hash": "sha256-L9d9YxCR5hBBZWwQZ5KNvbMAatNNUoRV2lHRwznfYIY=",
      "url": "_framework/System.Diagnostics.TraceSource.j3frqyv50f.wasm"
    },
    {
      "hash": "sha256-6e2ujdPMMp58h2IlbEktlLb7GOCLH8hn76cRf8gTb7U=",
      "url": "_framework/System.Drawing.Primitives.he23j36al6.wasm"
    },
    {
      "hash": "sha256-KHLN20MI/Vq/1ojzfEzP/H3h5pIJ3xq0akplBTxnjOM=",
      "url": "_framework/System.Drawing.wqh0k022v2.wasm"
    },
    {
      "hash": "sha256-3Mkie25hK0ZkbI5xMcJBaFah3syzLuLTfmVNFtiOs9E=",
      "url": "_framework/System.Globalization.8pxloly6nw.wasm"
    },
    {
      "hash": "sha256-nPKM5FFtCPJezkGlTplyVrTVrywjjfpD2EwF+U3irN8=",
      "url": "_framework/System.IO.Compression.4u2597vlyq.wasm"
    },
    {
      "hash": "sha256-ltKNH6AL0soduarPfzy6T90WE3rPgr3GhVxWtFvIglk=",
      "url": "_framework/System.IO.Pipelines.mslxeuynkl.wasm"
    },
    {
      "hash": "sha256-eIcPMli6GKAUxm+Pc9gN16+rMOl/79oGWxVr1fPiCZ4=",
      "url": "_framework/System.IO.oooyi55gd2.wasm"
    },
    {
      "hash": "sha256-IjKtS0Dg6sf+DxAx5OjT6Iwe+4x3fDwqofbSRZVedUw=",
      "url": "_framework/System.Linq.Expressions.es2n8u6n0p.wasm"
    },
    {
      "hash": "sha256-VjiYAwzrLGzIzgSWUMo7QsHyuKjGJVmMcDtLw9btbzM=",
      "url": "_framework/System.Linq.enazfeg59u.wasm"
    },
    {
      "hash": "sha256-b83x92A5zVnJJJoHcRKU93Kxbw+Eooe7vNVWLzuiEWk=",
      "url": "_framework/System.Memory.1kwzzk13lk.wasm"
    },
    {
      "hash": "sha256-Y95pu4IuUYNX/7iPs+qqFw39o3ysk+X0xesRH95xjtI=",
      "url": "_framework/System.Net.Http.Json.njmt7crs0z.wasm"
    },
    {
      "hash": "sha256-hEd8tYg9x4DBlC7WUSWEF6B1/T7K/4RpoOD5BZ8Ld4k=",
      "url": "_framework/System.Net.Http.cwr1h908li.wasm"
    },
    {
      "hash": "sha256-9X5Wr6IELyvEHiBjVctR3z0q3JyW50oIb2YXKTAro/M=",
      "url": "_framework/System.Net.Primitives.fjpz1pfaka.wasm"
    },
    {
      "hash": "sha256-r6SAVtR5J2ofbJ2QDr43y5RuedszE2dzNr2hei69AwY=",
      "url": "_framework/System.Net.WebSockets.3nbjnrau48.wasm"
    },
    {
      "hash": "sha256-QuoVIa3GxzIX/c6bKnWBhsDKjw7mMBhQYMgpn5t+sQE=",
      "url": "_framework/System.ObjectModel.mf9mpmciqr.wasm"
    },
    {
      "hash": "sha256-SoutR3fHD+07jDkoX2z5+i+ZaRHNxTaLAiH5fc+bPwY=",
      "url": "_framework/System.Private.CoreLib.imedoyeps4.wasm"
    },
    {
      "hash": "sha256-q4/eK7p/uYX1x1vKz/D4HBOKVq3r3iu5zIO9lUGy5N8=",
      "url": "_framework/System.Private.Uri.dy0yrj5bnr.wasm"
    },
    {
      "hash": "sha256-Z16cc7p9mcYvEs4PTHZMSSnDvMPNZ1V8cB6Kanpc3DE=",
      "url": "_framework/System.Private.Xml.7cb0hpjdbf.wasm"
    },
    {
      "hash": "sha256-Npl+wJK+WN77TCaQ0+OHT1SGf5BOZwsjvcH8SCg4gPg=",
      "url": "_framework/System.Private.Xml.Linq.m93x4lqdft.wasm"
    },
    {
      "hash": "sha256-8F7IdGa6sYMyn6WYogDuSU8TtUDXCEmqUaS4NX0T7BA=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.o25lm35ljz.wasm"
    },
    {
      "hash": "sha256-kWPIXpc/z/MeojfI7PRyZf+zAXt+UXN9asNIlGFTzLY=",
      "url": "_framework/System.Reflection.Emit.Lightweight.57df34kbot.wasm"
    },
    {
      "hash": "sha256-XaF4+xShk+PN+XR3aM2YVtUIZBRFv8Fs1ygYUGzkYOk=",
      "url": "_framework/System.Reflection.Extensions.buy57us30o.wasm"
    },
    {
      "hash": "sha256-1PpEowNT285pH9QLabbBJhUwVk5N8pShAHK7R24yP/c=",
      "url": "_framework/System.Reflection.Primitives.s2j1s28uhr.wasm"
    },
    {
      "hash": "sha256-pxvk8gnrouWQfx7cEOnUgl8PNRwkrrZb6RrBfwBjtLc=",
      "url": "_framework/System.Reflection.TypeExtensions.p4r4y80wcu.wasm"
    },
    {
      "hash": "sha256-YHXpAU6ln0hMyJyjDMo01e+06j7m+lkfZIZh8QTw6ok=",
      "url": "_framework/System.Reflection.gsui1awc7x.wasm"
    },
    {
      "hash": "sha256-Dhce29Q2jSuDOwO2bEaeqgQfpgm+FcA2Kimzt8X8y9k=",
      "url": "_framework/System.Resources.ResourceManager.ywp7acztcd.wasm"
    },
    {
      "hash": "sha256-Ik/Mko9DkPmYDjY1ZmJF2NDm9wMq5D8WiykOrsAqtXk=",
      "url": "_framework/System.Runtime.Extensions.y7wz30w5oz.wasm"
    },
    {
      "hash": "sha256-5X6FWiZE4NSx4s9iNjfVim2lWQpcbVIsorx1vB6lyno=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.f7txb1es0b.wasm"
    },
    {
      "hash": "sha256-9lSJbrZYpsJKQDOxIR0EQntZZAJ+BkcPIkBRU4Ylmbw=",
      "url": "_framework/System.Runtime.InteropServices.it91p58oo3.wasm"
    },
    {
      "hash": "sha256-3G7Mkhisvgwy+kJP0/vXiY+ziwDu8giH/UyihuUROhk=",
      "url": "_framework/System.Runtime.Numerics.0jnbnvt4zn.wasm"
    },
    {
      "hash": "sha256-sAFIXqOPsmFtFsxiQYpoyFz5mi1HOyk56KIVHTS7BJc=",
      "url": "_framework/System.Runtime.Serialization.Formatters.gow1eafq9y.wasm"
    },
    {
      "hash": "sha256-OGmnFGsvRwUnliUmMSX+rr17CT5viNDfT/lH0G+Lb2k=",
      "url": "_framework/System.Runtime.Serialization.Primitives.wuqt0rr1y7.wasm"
    },
    {
      "hash": "sha256-I/Ca9NLNFDkPQTO2MYf36J/us3WIj6GpaQmKAwO2U3U=",
      "url": "_framework/System.Runtime.vlpqc0ue1u.wasm"
    },
    {
      "hash": "sha256-4UlkSZrlsVbyseMrjhb/kQEnQC4joM2xU9IyK9upepA=",
      "url": "_framework/System.Security.Claims.jvndwvoaot.wasm"
    },
    {
      "hash": "sha256-uWGs7AtSSenVM8U1mmYBgNQlyivgENEFDKfS/0KVzic=",
      "url": "_framework/System.Security.Cryptography.vevd6a1ao0.wasm"
    },
    {
      "hash": "sha256-PO9yGjbsUS4RrSWGvoNVfy+djMvaQjMpyDITBFN7VSw=",
      "url": "_framework/System.Text.Encoding.CodePages.ox4hod9fwi.wasm"
    },
    {
      "hash": "sha256-QoWqXVmScCWT+dUmfQa1rx2uqnm48MlT7/5rZ4e02a8=",
      "url": "_framework/System.Text.Encoding.Extensions.y7ufsa7vbl.wasm"
    },
    {
      "hash": "sha256-7jz96OFTWqvABru1dnpIR/crYX7TtUk1i4fbYxIiAmg=",
      "url": "_framework/System.Text.Encoding.e1q9fq8pmt.wasm"
    },
    {
      "hash": "sha256-BkAo1wUO1j2o4gAgHdIcf5krMaKLY2JTATftC8u/rHw=",
      "url": "_framework/System.Text.Encodings.Web.ujbee8yy9l.wasm"
    },
    {
      "hash": "sha256-hT272A1BQSKcOYY1CUYrstRFLE9sH0jAcN14nk7ohnM=",
      "url": "_framework/System.Text.Json.7tu6l7njqu.wasm"
    },
    {
      "hash": "sha256-81iO+r08OQp+bLXqlmm9cgKIMr2hCA/fRWaSCWGR4TI=",
      "url": "_framework/System.Text.RegularExpressions.77f00nxdbl.wasm"
    },
    {
      "hash": "sha256-MkNQ52HZnEWHDPw439pIzRlO9JfxVfSQSwhTg4WzBJs=",
      "url": "_framework/System.Threading.Tasks.ijlztyqbp6.wasm"
    },
    {
      "hash": "sha256-C/AUG9JZAC5iks6D3bDfW96IeOqOyh+0V7svrdir2HA=",
      "url": "_framework/System.Threading.ff2vmnk05t.wasm"
    },
    {
      "hash": "sha256-0edztHN+EdRvVM/xmBPj470AY4LU9oJJpa+cBXnRbd8=",
      "url": "_framework/System.Web.HttpUtility.h4z0mo47ct.wasm"
    },
    {
      "hash": "sha256-yo+J3RWIIHIiwAhqsR9JizNkH/+hd3auB44RBmvvLoI=",
      "url": "_framework/System.Xml.Linq.qsgzs1hc1j.wasm"
    },
    {
      "hash": "sha256-/knwe0vI8PIfJbzxp6Tj0C73ucDk45O6P9HRr2Nba7Q=",
      "url": "_framework/System.Xml.ReaderWriter.27sxhrkw43.wasm"
    },
    {
      "hash": "sha256-VjVnzRBuR6cIfnHACA0w5l6iptgK+U4GnNGXxIDaUPk=",
      "url": "_framework/System.Xml.XDocument.iltivglr0y.wasm"
    },
    {
      "hash": "sha256-hkGLo/MuT/FJ0Xf4XUL0D2VA4dZV532GHNB1JicxLko=",
      "url": "_framework/System.m0fu6d0eya.wasm"
    },
    {
      "hash": "sha256-PxBQUtV7HW4AVxrjPhV5zpEV+LTsFd90t3iDHolxOfE=",
      "url": "_framework/Tommy.z379sas3l7.wasm"
    },
    {
      "hash": "sha256-LZ4i5yAq0z1cY9Z//7owTgAwTFD6+as46JKi0Gl/d6M=",
      "url": "_framework/USA.Model.lu6yvelyub.wasm"
    },
    {
      "hash": "sha256-nNPyM7TP7Sp4N054o563oU6FZnHcAw8jJU3H+H0sJ0I=",
      "url": "_framework/ValueOf.ccmezia1vt.wasm"
    },
    {
      "hash": "sha256-GgqhS8kTALDE++1NDi9XNXxU8CbwpilbmyBKcB1S4u4=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-gD2XMSIt+vtDFirTg+LVASuuDVoOW3S7fY2a27Ou3Vs=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-0QEipUmNWsH6RER2j248Ucq2lDwScdaGbbJNwbuTDro=",
      "url": "_framework/dotnet.native.37zoqbdc6m.js"
    },
    {
      "hash": "sha256-lqOygATiXhHF6TYjk10ST16trrYZt4HSKHUHUUM9Yqg=",
      "url": "_framework/dotnet.native.eb5i9ioz2n.wasm"
    },
    {
      "hash": "sha256-oBRKHAqZUsvCRnCzkQfB7zc45cpKLNq2NKyrG10IKx8=",
      "url": "_framework/dotnet.runtime.st3wwc8rqy.js"
    },
    {
      "hash": "sha256-Kn+8j510dQQ7rCE6F347fJpZAM2x+uiNlRwyiSmicSI=",
      "url": "_framework/dotnetstandard-bip32.qwdn989y8v.wasm"
    },
    {
      "hash": "sha256-j6wIkVxwXBJ3QLeksRyb1pJbcfEF1waXK3cbImnAl3Q=",
      "url": "_framework/dotnetstandard-bip39.vke3c9voq8.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-wWJ6JEyHPdRB5aTODKEFtFaPq0Rn/CdNDdw+2VbllkM=",
      "url": "_framework/netstandard.ttpw4tcd2a.wasm"
    },
    {
      "hash": "sha256-UUML5ducMN2pwsVqVcSI96/Up1EZn7PCyh29I6KxArU=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-0iwIe+QAchK1Dbl8OAkO4rjwtbGDv5umPvatKQZGaVw=",
      "url": "docs/MWR-First-Round-Draft-Choice-English.pdf"
    },
    {
      "hash": "sha256-boY1bNun2P8DGhdXupoEuINNrFst0azy0Hd/pyUupCs=",
      "url": "docs/WealthWorksheet-Answers-v1.pdf"
    },
    {
      "hash": "sha256-Rxwu4GY7uhtw2E3QkPacuCi5VoVMimW56oarTIyiHgY=",
      "url": "docs/WealthWorksheet-Answers-v2.pdf"
    },
    {
      "hash": "sha256-mvwx1aCn+FuanBm/2Xe7f9kdLT5pB80vaV7csWhZv/U=",
      "url": "docs/WealthWorksheet-Answers-v3.pdf"
    },
    {
      "hash": "sha256-rYxEF4lV8W4KwQamII7LnX5sW8mNRo65Ljj6MQX8+QM=",
      "url": "docs/WealthWorksheet-Blank-v1.pdf"
    },
    {
      "hash": "sha256-Ugg1CVsxoQsM/WY5VWTPrPImwa+qsYq6mPL7IiSWHyY=",
      "url": "docs/WealthWorksheet-Blank-v2.pdf"
    },
    {
      "hash": "sha256-XmaYYGkkA6bJ/t0boZXQE+eH7ODG+2PYinPzK2kzusE=",
      "url": "docs/WealthWorksheet-Blank-v3.pdf"
    },
    {
      "hash": "sha256-popaLln2zKQ/l924OcSkESlwM3jS90DiTMXekYOiqMI=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-wZr73HvKWRIbBCkD4NkhEuaxiBKhP+xRcpRSuOzopa0=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-TPplinUrtMzreyyaN5F6MKIl1R3MKpTHPyUxj25NjHs=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-0EmI2DzdKKXB6UXy5Gq8s5GmQBdX2m1sKLAy24H/ih8=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_ENG.png"
    },
    {
      "hash": "sha256-epuvvqUkzf8j3FdkSX06OLRLotnxR1Pn41e8/nzi8HI=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_SPANISH.png"
    },
    {
      "hash": "sha256-2GaLGuhFCj/nV8xt3jTthp1o6hh60P/aNus5QQ5eRVg=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-ENG.png"
    },
    {
      "hash": "sha256-O31j5nWkea4Njs0tyHl/u90xobm2ie/Mr6ZoTT11uH0=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-SPANISH.png"
    },
    {
      "hash": "sha256-9penkBKfaAtQ6BcxPuu7gJSj5fyBVltlH2EPf4ohsbE=",
      "url": "images/72-hour-money-challenge.png"
    },
    {
      "hash": "sha256-dkWIZ8TeixFQnRqM+eWjOtXcZ4yXjTkyvlLfQlH0V74=",
      "url": "images/72hour-money-challenge-logo.png"
    },
    {
      "hash": "sha256-YPT2wkgMebWcXFKa+RH+bVg2S/ouYliMHTthIwOCx8I=",
      "url": "images/WealthWorksheet-202406.jpeg"
    },
    {
      "hash": "sha256-x/KjPrxSXn9qLoJTZKDdm8FPJNRQ5cge45ZoYPE0Bt4=",
      "url": "images/WealthWorksheet-Blank-v1.png"
    },
    {
      "hash": "sha256-aJc0GeZ+QyjMhs/oI5fp345z9klW7x0E6c1U+JYCCB4=",
      "url": "images/app-logo.png"
    },
    {
      "hash": "sha256-5y96EQXaqvkWqZhMLIKp1ETH3G+cUnYMN/q+D1LOD5U=",
      "url": "images/app-screenshot.jpeg"
    },
    {
      "hash": "sha256-2LHqb5ZGgFxpM5wEObzowveNpXw+a+ilaNBvefadJFA=",
      "url": "images/apple-store-logo.png"
    },
    {
      "hash": "sha256-d+haM7zmj1SK8ShTtlNReuAVVQRjL+GwpIk1Xs5t6T4=",
      "url": "images/bitcoin.png"
    },
    {
      "hash": "sha256-BIjUdqe6Pd1bpC7vw+7hDp0atyGdr9GxUsQJBoJx2EQ=",
      "url": "images/events/72day-blitz.jpg"
    },
    {
      "hash": "sha256-XnXrqTwRAmZX3ftdeYVLxQP+phWWHB8PkST74+jCYBs=",
      "url": "images/events/fridays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-durHWyGA/ZOHAHBxpNnaNiLcRGwQ80emEgIpx00WUYA=",
      "url": "images/events/megaschool-officehours.jpg"
    },
    {
      "hash": "sha256-IBM9p32DWT+bJMFE9VrGxsB4yOs+e2BFxbi2WHGqGec=",
      "url": "images/events/mondays-kingdombuilders-overview.jpeg"
    },
    {
      "hash": "sha256-+wj2nf1yWGIoA1rxQ9TO/ybqkOZKAJfnaut+qjH3b9k=",
      "url": "images/events/mondays-megaschool-bitcoin.jpg"
    },
    {
      "hash": "sha256-tH0Uy+FPtHqJtCHBiPP3gtPW06uERgfjNkUOy0nB87s=",
      "url": "images/events/mondays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-8jEuqbQVZBP96DyiL3zI+wtSyNdUn5u6WsWfXIBcmWs=",
      "url": "images/events/saturdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-+Xv2jWM+E8Sxc4EczNKAuEr9FKjmOpSUbg4LIg0LWh0=",
      "url": "images/events/saturdays-creditteam-readingclub.jpeg"
    },
    {
      "hash": "sha256-X0AhZbwv+14vuNO0AqDUFKRYCMTd2ZLA81kRaghW4QE=",
      "url": "images/events/saturdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-VHOQUj47T8XHNPWNdPyFMAcYO+WEGzQw3MxZ9Q5DM8g=",
      "url": "images/events/thursdays-corporate-training.jpeg"
    },
    {
      "hash": "sha256-I0A4MxG8FZX7weKGstIivDrLR7/fy0mypSeF+eIy5hY=",
      "url": "images/events/thursdays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-141HA0WKoh9MbO/9Rd+T+amz+dNai67KCERdkAioQOI=",
      "url": "images/events/tuesdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-Dvw+y+Aa8ZxIdpZgDkHfJgSCY+B9kSNtLXFH57uW6cs=",
      "url": "images/events/tuesdays-edm-sizzlecall.jpeg"
    },
    {
      "hash": "sha256-4MbH5AJ+zmI5rO5H7WH2E1lev2agCDo4s6f6cR1E2YE=",
      "url": "images/events/tuesdays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-nTMdPi6+geczXpLMA7LpsOm3K98aKbq6jQnUZu6Qbck=",
      "url": "images/events/tuesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-hZtojdaZEibd+x79MR5jRBDr2OmZNdAJHeRsEC/nj0s=",
      "url": "images/events/wednesdays-creditteam-noon_overview.jpeg"
    },
    {
      "hash": "sha256-6/HA01PFP4SDPeGcszKA0L/o2vSQDcXowv4gkqGBtpM=",
      "url": "images/events/wednesdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-GiIvAfyCmwkwOGgNOfNir5/R6r0tLWIlg8GlYD3u450=",
      "url": "images/events/wednesdays-edm-overview.jpeg"
    },
    {
      "hash": "sha256-U6xu7LRjVWO2sh9tsfZ7Wx11vp6GFp6yAleDXo9Baw0=",
      "url": "images/events/wednesdays-edm-training.jpg"
    },
    {
      "hash": "sha256-TJaXAdRACicRBPR49m0mrUY/nTYd5UZ+nH7ictcegqc=",
      "url": "images/events/wednesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-WfWmNx8ugrVJt8Hio8mInauBeubXz3MNU+wBO1HlhNk=",
      "url": "images/faithandfinance.jpg"
    },
    {
      "hash": "sha256-wm6Fc6KewsfvAxFUAH9Gfl54bRLK50JtpGkRRw/5XRU=",
      "url": "images/givbux-logo.png"
    },
    {
      "hash": "sha256-QCS5jSwSmQddgvloSz38p2b6gcW2IeBNZ6C/Sf7JIKE=",
      "url": "images/givbux.jpeg"
    },
    {
      "hash": "sha256-HGpfynKCRnDS/GXuvdXetRI3BuViqf5Pl3kWKo1D0uM=",
      "url": "images/google-store-logo.png"
    },
    {
      "hash": "sha256-0259fqSmtuwgBDyrjOq712+2mCWikluPGqsB3Msfbc8=",
      "url": "images/keys-to-home-ownership-banner.jpg"
    },
    {
      "hash": "sha256-Qznvfa8S28xPiRLum+paxAd/Q/xKgrVsxpe/+VTAApY=",
      "url": "images/mwr-banner.png"
    },
    {
      "hash": "sha256-398mb2+jZWyLUeJTRCc7EZVWnJMfQIGY1J3s6Z37h5E=",
      "url": "images/mwr-givbux-logo.png"
    },
    {
      "hash": "sha256-uWb3M+RKY9JEAAgaEhCUoEW8JQWeEBLW22LdJ4O0v/0=",
      "url": "images/mwr-healthshare.png"
    },
    {
      "hash": "sha256-Uyrk2Rn4TCV5YDgdsoJtyvurtxMHgqD+s6qR0CjpzVw=",
      "url": "images/mwr-logo-transparent-221x221.png"
    },
    {
      "hash": "sha256-NlYP609WoZo06NouFRFzFdQY+fH/5EcpBkjWrP3KpRA=",
      "url": "images/mwr-membership-logo.jpg"
    },
    {
      "hash": "sha256-u2LuEEAV/k6NEIA7jLbCqrEzyV0IoHMEIgF0ImsQoKg=",
      "url": "images/mwr-precious-metals.jpg"
    },
    {
      "hash": "sha256-hXeCeiWwbi+JSpfjfkrrAc7plipQKl97raN+PnBhvyQ=",
      "url": "images/next-level-strategies-logo.png"
    },
    {
      "hash": "sha256-G6O/0wfsoPFqWRsdY7QYuDVu+LEca98xXZTF2QaIwU4=",
      "url": "images/student-loan-debt-relief-tile.png"
    },
    {
      "hash": "sha256-4dLv3/Bgj1U90lWJ4WzyRf/+UpWmyuxeI5IL1wUZfLY=",
      "url": "images/words/72hour-response.jpeg"
    },
    {
      "hash": "sha256-KFV0G6KHAWfA6+8567BYhpvz1r+YccrETCb55o6qIhc=",
      "url": "images/words/72hour-share.jpeg"
    },
    {
      "hash": "sha256-cDeEIUrwWMlQUd1Ob3hQ+GLdlDkroj/DpIsC2WjE3GI=",
      "url": "images/words/72hour-success-story.jpeg"
    },
    {
      "hash": "sha256-7XzyfuRua4N2mzfUnM4JMJsvDu95Mb0P+RBmu3vewJQ=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ck2YK4oJkShd1p5P86axqOSMs6L+Be8AM0Y34BKqDVQ=",
      "url": "manifest.webmanifest"
    }
  ]
};
