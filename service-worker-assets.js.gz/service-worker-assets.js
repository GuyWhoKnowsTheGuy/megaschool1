self.assetsManifest = {
  "version": "8Dc+EhdE",
  "assets": [
    {
      "hash": "sha256-qJAuuKtXjsOCdGWVdhXSxJjtr26OIrMo88bEuQiSAyw=",
      "url": "MegaSchool1.styles.css"
    },
    {
      "hash": "sha256-CzOMFx1QJiQ2qwbg9cmQ2X4RRqnNAtwbMXJ6WE2L6js=",
      "url": "_content/Append.Blazor.WebShare/scripts.js"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-fC5+7WJvRi9RO0JSMRTe5Fw/ybv1XWp6LgTNpuRA4vM=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-O2UJyVCl+4RaA/jZS/WQ4tMRIZbpXtfRhr5eVl0xLm8=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-eTpvwvDNavTSzL9mvsyAolbszT4oDL+nWD2dv0NSeUM=",
      "url": "_framework/Append.Blazor.WebShare.3trn12rddt.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-D+dfp6xcbDQeM8YkMnhT4SB0NpR70u2eqX216CNZKNs=",
      "url": "_framework/Common.Logging.Core.bxmwr8lhlv.wasm"
    },
    {
      "hash": "sha256-4AVhWz22l1X8Pl+vQZMfhD+iMZzHdeyyWpx3yGcXtXY=",
      "url": "_framework/Common.Logging.k361pnvvgn.wasm"
    },
    {
      "hash": "sha256-pmfvO53P9cnT8XimNKfTlLz+rXAyt5+yEczCGhVhHLo=",
      "url": "_framework/Flow.Model.i2wsb7yax6.wasm"
    },
    {
      "hash": "sha256-XlxVQl5g5a9aq6Tt7AUwKqOUYdc51gwNoSUl9C+xfqs=",
      "url": "_framework/Flow.UI.mywabv5i6q.wasm"
    },
    {
      "hash": "sha256-UzXm5ONFC2YfuSahJleOJiIJNURatHcRQIkXq2hoPew=",
      "url": "_framework/FluentValidation.b28mz0qrx7.wasm"
    },
    {
      "hash": "sha256-3Ar/w0r5EQDVQjpl6QGKdhm6ossHCD5z10hApEdjhso=",
      "url": "_framework/Foundation.Model.s2csltsxed.wasm"
    },
    {
      "hash": "sha256-9SfcTBaWKAmHAZfDGiDi/JmtyeuSAQGK88mCr+44Yw4=",
      "url": "_framework/Foundation.UI.jibj35oien.wasm"
    },
    {
      "hash": "sha256-dBm5UHP8hg3pLku0if0ZJcCu16124P6GQPD92njA/wY=",
      "url": "_framework/LaunchDarkly.EventSource.ck3ehzcsxc.wasm"
    },
    {
      "hash": "sha256-4AuaWPo8H2W8lyE34/ECPP4mpaLc+Rb+KmPUK8TyO+4=",
      "url": "_framework/MegaSchool1.4zzweuve2j.wasm"
    },
    {
      "hash": "sha256-0DV8s7HIdV0n0ob7KtUUOz0DPJx4GNCTygBqk8/QRhM=",
      "url": "_framework/MegaSchool1.Model.8mzeq0ris5.wasm"
    },
    {
      "hash": "sha256-sfzcorMGdN7VM/GJQN1BSfPnb7UXtmpClyUgwMxZiS8=",
      "url": "_framework/MegaSchool1.ViewModel.zbi6h85hwi.wasm"
    },
    {
      "hash": "sha256-8SUG//aIW6V9INwvgAFxsuSlXQ/Bw27zVBeWStYsUUE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.92a4md7m2o.wasm"
    },
    {
      "hash": "sha256-1wsUwvTly1OFfeojmSHwRiKzd/sgI3UZZgNMj+XCuCs=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.pcmc8s439f.wasm"
    },
    {
      "hash": "sha256-gGiWTixq4Xk9+DLDRbtsK38O5Q6tCYkmhRCLkRgUZKo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.00804rvyxu.wasm"
    },
    {
      "hash": "sha256-Kn8mCkROxbk1bfy/PLBdlkhOx1hbhNz/aD3ZdpnuPNI=",
      "url": "_framework/Microsoft.AspNetCore.Components.iypz1scfbx.wasm"
    },
    {
      "hash": "sha256-7wgz1ZHwXmXV8y00xn+jT4BGeuCQQbVYGQl+PNvBfnQ=",
      "url": "_framework/Microsoft.AspNetCore.Http.Abstractions.5jy9omvvsv.wasm"
    },
    {
      "hash": "sha256-bzIPAVp+XhD63CRn9cVTB4tJRU+oDEAuwFYoHytMhUk=",
      "url": "_framework/Microsoft.AspNetCore.Http.Features.pqxjsc5k5q.wasm"
    },
    {
      "hash": "sha256-CNGtY2Zlow4ZwwKlyWeyosbzAaSllziAZuYdTuTHIRM=",
      "url": "_framework/Microsoft.Bcl.TimeProvider.0mrxvq2io8.wasm"
    },
    {
      "hash": "sha256-1hBJ6YhDtf5SQpkuEVWoRg22qnKCyrj02FZS+0sguXM=",
      "url": "_framework/Microsoft.CSharp.qvazne0eqv.wasm"
    },
    {
      "hash": "sha256-IbyZLQO5kYUfGJm8A19uSKZz7y90mhIivEfB/wBtPZM=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.pe5rw2s9bj.wasm"
    },
    {
      "hash": "sha256-GoQgc9M/wkr8ecOlhwPADpDnv49RWOaImwiAdtxA3kI=",
      "url": "_framework/Microsoft.Extensions.Caching.Memory.64h9p1av56.wasm"
    },
    {
      "hash": "sha256-S71SOqzWl35Tc9WorGgQ4zho5dJjhly44LmH0gYJjKE=",
      "url": "_framework/Microsoft.Extensions.Configuration.7ltinkh07b.wasm"
    },
    {
      "hash": "sha256-SO3Y7ua54A40B7zyNeEWrkTqo2GpC4p/IXw3RsgMdvM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.4hqhl29hfh.wasm"
    },
    {
      "hash": "sha256-NCBVjDWMCz2gJob7x7q+FX57heM63Kb/y3s+1gofTJA=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.kusjf2d9ra.wasm"
    },
    {
      "hash": "sha256-iY6mGzFqdkViRAURvuiU6xZ4IlIqAwMLJpL0OkLWeVw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.xi2jfvrc17.wasm"
    },
    {
      "hash": "sha256-Sc7Z5jPLun7BN1LZf1XCKmNyFyw8eCnIkzXQdCRtSqI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.7gn4i8bn3w.wasm"
    },
    {
      "hash": "sha256-oH5Cmt9thHFqDUV/V+K/+K/RxqhjvFv5+cjgUf0VZr8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.4zndsm5fgk.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-6f/t/cTiRfrlsTlIvLG8edEngkFbGOUJrKkqlJovbFE=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.fepynxfn30.wasm"
    },
    {
      "hash": "sha256-Qv5mOnMJqk2dj0FV/rpIFz5lXKuiN00ogs/VfR9k0Qo=",
      "url": "_framework/Microsoft.Extensions.Logging.yzb48hclgx.wasm"
    },
    {
      "hash": "sha256-VKnLqKvDxi382H0CvfwFNDStugpKUwXCYH3ODwHDYcQ=",
      "url": "_framework/Microsoft.Extensions.Options.4asqlkondd.wasm"
    },
    {
      "hash": "sha256-tRXvavU5jF9C2zmyMO/WMIKD/rbIVgg8OpQ4IdB9kWw=",
      "url": "_framework/Microsoft.Extensions.Primitives.dqc5eyj2st.wasm"
    },
    {
      "hash": "sha256-wNnHJnTokjQiYia9M4GQne7gYfnmT2mpOnK2JXbJEQY=",
      "url": "_framework/Microsoft.FeatureManagement.w02e8smije.wasm"
    },
    {
      "hash": "sha256-WxafQIbOCQlNJ0E6D148JIN+EJ9ct5o7yFeT21pCuNk=",
      "url": "_framework/Microsoft.JSInterop.3uqi66qay4.wasm"
    },
    {
      "hash": "sha256-GaWH3/h+jMiywp+g7vt6i3wRVl+RkH+TV4HWg12yYXM=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.j5m7jjhb9v.wasm"
    },
    {
      "hash": "sha256-V8ODVC8ZErUZJqpzl0fZAA/CFmAQVQ3sVMR33h5El1c=",
      "url": "_framework/MudBlazor.7wl2owl4td.wasm"
    },
    {
      "hash": "sha256-xEImZbLKcmBj78QeTJyvAiRLxzN6tO/4NERRBTzhua4=",
      "url": "_framework/NSec.Cryptography.40wv7imlqf.wasm"
    },
    {
      "hash": "sha256-+ivIDUFHJl+LmeKj7ueRPfnWM/wp2dMygtiBlp6Cqmw=",
      "url": "_framework/Nett.emyfn4350c.wasm"
    },
    {
      "hash": "sha256-erKuIr8Gjq+X/Ji4X+pGauW71/eyGT7GHVu8k+7ie8I=",
      "url": "_framework/Newtonsoft.Json.y96379yjhz.wasm"
    },
    {
      "hash": "sha256-akqbZuRazMph7GZNcPHLIOp1mgnkjdaWZMM9Up4LPfE=",
      "url": "_framework/OneOf.yq61etxwqn.wasm"
    },
    {
      "hash": "sha256-ayRMl7l1GF4h65kNE0bKJ4lrGPZxmR+OkvPUFrQ11oU=",
      "url": "_framework/QRCoder.jqr4n2c9hc.wasm"
    },
    {
      "hash": "sha256-ZwToh0+onnsuEEi4ISoq7tGM9S9l8NmpDtywTW7VASI=",
      "url": "_framework/Riok.Mapperly.Abstractions.v2oa0z4fia.wasm"
    },
    {
      "hash": "sha256-4eyCDrmeln8TfYIa6F9oAyuyPqJi7Y5/CaXDOfYve6A=",
      "url": "_framework/Serilog.Sinks.Async.5f8lfszthz.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-IU1wbWWmevTzax9faR7cBTh3+/SHme1dNs0/OXItpXc=",
      "url": "_framework/Serilog.Sinks.Console.rtr49hgfiq.wasm"
    },
    {
      "hash": "sha256-AOLPsUlcm6GyVW4GsJ6IBJ6Ztz0VuRKlTrhFfUwqGN0=",
      "url": "_framework/Serilog.gky8dcecvc.wasm"
    },
    {
      "hash": "sha256-2rUvzVKyHzBpzJjjuBlodULIg12Y6wVebYmpfJP1aO0=",
      "url": "_framework/Stellar.un0en5pa8d.wasm"
    },
    {
      "hash": "sha256-3v9jNFEDOILuS/WEBKqvI5mBEaVOHEgAAuWgWJTcKRw=",
      "url": "_framework/StellarDotnetSdk.Xdr.qai6u4zr8l.wasm"
    },
    {
      "hash": "sha256-qVAK4qjZ4QTXTOhoLccNT3x4YciMCsITDV8bMrPhHTM=",
      "url": "_framework/StellarDotnetSdk.vyfyq0ly6r.wasm"
    },
    {
      "hash": "sha256-u89dUs8582ptNKvuwx7ZsAmAJ/PElWQ5OUBn2uDqoUc=",
      "url": "_framework/System.Collections.Concurrent.vrtkgb272b.wasm"
    },
    {
      "hash": "sha256-kTZW7J6rUNtYe/feFv8V1XsyNw9zuGzNGRkQObA4NQk=",
      "url": "_framework/System.Collections.Immutable.1sa0oi2xbo.wasm"
    },
    {
      "hash": "sha256-pt0ZzJgroslJBsxMe57ze1s9KaaCOGb2aKv6An1EKJM=",
      "url": "_framework/System.Collections.NonGeneric.qjewwbiymc.wasm"
    },
    {
      "hash": "sha256-1HuQ7Ss2ESZNI+cie6fSbid0xNpY4aMawOU0dFb6UOE=",
      "url": "_framework/System.Collections.Specialized.c2c3kmzd79.wasm"
    },
    {
      "hash": "sha256-g4WuClomZw5mmnYcjVnKHvH9M7ATgemdot5HlSic63M=",
      "url": "_framework/System.Collections.fxt06i2qwl.wasm"
    },
    {
      "hash": "sha256-KT7v2VqRj2RWiTMXuGK0fg2x06kN91fbpyD5SM8fzj0=",
      "url": "_framework/System.ComponentModel.1uzvvyzg5f.wasm"
    },
    {
      "hash": "sha256-YWJCPvwJkptUTp2GAayeMq8Nn6lPzS5jzy7G157Lz5Q=",
      "url": "_framework/System.ComponentModel.Annotations.9eq3uv0ovs.wasm"
    },
    {
      "hash": "sha256-ZVsveOYc7pBnXP1Ye1Z9FXwzfJc6cdzdLVuDJUSM7Xo=",
      "url": "_framework/System.ComponentModel.Primitives.1peofrwp0i.wasm"
    },
    {
      "hash": "sha256-2FM04LiLVEIlUVSiMMQ774OAclERp6OC3bdD5Fut1hk=",
      "url": "_framework/System.ComponentModel.TypeConverter.w2j1lyofwo.wasm"
    },
    {
      "hash": "sha256-HMrA+RJL4e7Qc9ARrBCCppzbGyJenGK0C77O727HIXg=",
      "url": "_framework/System.Console.cu6hpwgz2q.wasm"
    },
    {
      "hash": "sha256-iOdQQjEG779AlYv2OCYRskIFpu/gX5HLiDGSoRftSbw=",
      "url": "_framework/System.Data.Common.0e1u5giwao.wasm"
    },
    {
      "hash": "sha256-6C36REWUAna/hOQaTun0dKCvkJUDPL9d3/DaMK7d/t4=",
      "url": "_framework/System.Diagnostics.Debug.cz6ripywri.wasm"
    },
    {
      "hash": "sha256-9JwofKeoaA6NjjsYv/lnizHwy2pkehJWBC2hsjplziQ=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.46j8spv34u.wasm"
    },
    {
      "hash": "sha256-4z8X4Ulda1uDO61J9JkVKO8HYwXRZ3g9fgKW5S0D7K4=",
      "url": "_framework/System.Diagnostics.Tools.9l6vd0ihsy.wasm"
    },
    {
      "hash": "sha256-s9Z8oc6pbq1TN2MPoewNbYj069qOBBgsbVuGEHpJ3/w=",
      "url": "_framework/System.Diagnostics.TraceSource.ry567ff6yf.wasm"
    },
    {
      "hash": "sha256-ndWPDP+QySp6rPMFZKt6LAV+1xkCbhveRF1KeqF0FGw=",
      "url": "_framework/System.Drawing.Primitives.hrohi7rrgt.wasm"
    },
    {
      "hash": "sha256-BQVqh10/miWXV7ylhdX3h4ZFbA4z4gInC/Q797FWiVA=",
      "url": "_framework/System.Drawing.ndt5n06kpt.wasm"
    },
    {
      "hash": "sha256-tK6wyeQfEWZKayph8j5Sa75SNt8rMO5ksJfcWCRPnn0=",
      "url": "_framework/System.Globalization.g5z7hwhvdf.wasm"
    },
    {
      "hash": "sha256-2chWve9c8z4grRTX2bJZWn+5VOZK1BBRvvmu1j6bymI=",
      "url": "_framework/System.IO.1eukmne2w4.wasm"
    },
    {
      "hash": "sha256-zXUXiWDIpFVGCI2nnc7zO9zOU928q8DIN6v4KgiZVa8=",
      "url": "_framework/System.IO.Compression.56bppyjfv6.wasm"
    },
    {
      "hash": "sha256-LHmn3NZ0cYl/sD4s/EA26iSAYqDCycxgYdwt6suIKLM=",
      "url": "_framework/System.IO.Pipelines.wfn2m8uvna.wasm"
    },
    {
      "hash": "sha256-AGmlKMquITa9Vm4gO4UuN4zCz2qNxqoZ6WBpGZemyHk=",
      "url": "_framework/System.Linq.82b856vv49.wasm"
    },
    {
      "hash": "sha256-gILjPQ7Fu7DsKczolCQgh531i6acnIH/TO1znq5vam0=",
      "url": "_framework/System.Linq.Expressions.g4ahwglqrm.wasm"
    },
    {
      "hash": "sha256-LaJbGo1jH1/gnL+uP5mF4Va9epdKCoTTSTFoWtBjZNg=",
      "url": "_framework/System.Memory.zo5cea41oq.wasm"
    },
    {
      "hash": "sha256-6RYwhcwDMh8XyeQRyOHAF+d8Cep0lg1PjJw1XsaGVSY=",
      "url": "_framework/System.Net.Http.Json.9klnqs8q0s.wasm"
    },
    {
      "hash": "sha256-onlkFMJBpe7RLMAApJLFKEuY09Mp42LhDkzBsXeKh0I=",
      "url": "_framework/System.Net.Http.qll4ch52gy.wasm"
    },
    {
      "hash": "sha256-t8bSW5OfNLNFKzeaHGNh+gO7d3AYYKmJw+YBk8n1RuI=",
      "url": "_framework/System.Net.Primitives.70v3brdkqr.wasm"
    },
    {
      "hash": "sha256-KXm3NU8uKTYfy18Zz86Cq9lPmF4uUUWXG3hGGM2Al/0=",
      "url": "_framework/System.Net.WebSockets.1iagwkf4gi.wasm"
    },
    {
      "hash": "sha256-xF2P5TN4OGvIXIpgAfyrdRSgNxIj9QRGMme19XpMz3o=",
      "url": "_framework/System.ObjectModel.0rzp53hwqn.wasm"
    },
    {
      "hash": "sha256-sLE6fHbENDdH2T9qostBDkGkHstb8JUQ9D3vnjEgAP8=",
      "url": "_framework/System.Private.CoreLib.47vjtwlm7p.wasm"
    },
    {
      "hash": "sha256-Op08sqPgO8zFZEKArDB5tKkIyhhzvp11FsV+ZxEngY0=",
      "url": "_framework/System.Private.Uri.uuva38ia4u.wasm"
    },
    {
      "hash": "sha256-AlqC9EwlhwHDY0Wl3c40RuCRwSO3J4+hT2BD3Nm7kU4=",
      "url": "_framework/System.Private.Xml.Linq.ij4gb8qeon.wasm"
    },
    {
      "hash": "sha256-deKHdhNK5EmnXxs86GFkPkDRBlnBdEy2wz2qXcGkBHs=",
      "url": "_framework/System.Private.Xml.zerjwzsbrd.wasm"
    },
    {
      "hash": "sha256-lzPuFtH6ibA4sn0GAMJqgFnih0tNOPWqB1hHgU8KSJA=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.3h7f8q3qe5.wasm"
    },
    {
      "hash": "sha256-t0jqH/gVCTs9Iq/RR5/ElF+Ri0MijX4LSkBnr2KUOjA=",
      "url": "_framework/System.Reflection.Emit.Lightweight.rbdhnls5w9.wasm"
    },
    {
      "hash": "sha256-qqbMaO6IPGEEQn+Hc0atA5HITpk0e8dZ2yXkVBlpaJ0=",
      "url": "_framework/System.Reflection.Extensions.uv38d1pm5y.wasm"
    },
    {
      "hash": "sha256-n0dXDCI2fXe2MIzaTJ2Z6/I/3rm38ohYN8/AEy7LUsM=",
      "url": "_framework/System.Reflection.Primitives.dhny9hcbnv.wasm"
    },
    {
      "hash": "sha256-gcpPo7AxW/7N6yrk3SPJN+T0eX1NNK1zlQOmjmATzuI=",
      "url": "_framework/System.Reflection.TypeExtensions.fk2isjx6pv.wasm"
    },
    {
      "hash": "sha256-PjBZQ7n6R8lFyyrdgxr2EJF/SnmqNh1yro9pyn5bx9I=",
      "url": "_framework/System.Reflection.mi2qlnz2ku.wasm"
    },
    {
      "hash": "sha256-07lX3n8OUVVk05nodT0oXfL9u8H+VHIUjTRAlrAhFEM=",
      "url": "_framework/System.Resources.ResourceManager.zg31yozkof.wasm"
    },
    {
      "hash": "sha256-JCMLPKh/n4VruaY7VLRQ+9Ma4Ck4n2UTmPwPV+7VqHY=",
      "url": "_framework/System.Runtime.Extensions.kgpl3vzzn7.wasm"
    },
    {
      "hash": "sha256-rO9bcmHlBJWpKelQM5AUpgTh8SmdUdGbnw5IPPvA9tI=",
      "url": "_framework/System.Runtime.InteropServices.0h7ezc4k8y.wasm"
    },
    {
      "hash": "sha256-cTDlU0sLp3hCmTKUK2AVqrlAjuFjQveVBhCUZiIdUkc=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.lnedh9fxsl.wasm"
    },
    {
      "hash": "sha256-53o/5vs5NcZYzfaPQm5lrAziZFlfAZr2Wv6Z5UGMWDs=",
      "url": "_framework/System.Runtime.Numerics.f2pkni4qlo.wasm"
    },
    {
      "hash": "sha256-C/IM4HFrFsxeFbfm3GfJueW32SRHl5C2ZqZmNFZQGEk=",
      "url": "_framework/System.Runtime.Serialization.Formatters.fbvekiovfw.wasm"
    },
    {
      "hash": "sha256-SZKUhUssR7eQhIxhci6nHwArpF9ATo+xvsTdHbcZE5Y=",
      "url": "_framework/System.Runtime.Serialization.Primitives.v29fiw4uzh.wasm"
    },
    {
      "hash": "sha256-pQ823/o7SFRXPuAnM/UZxqFchYPA9mY4amn/tK445rE=",
      "url": "_framework/System.Runtime.pj6m9z3ocz.wasm"
    },
    {
      "hash": "sha256-ePGWmLbg2Lrfrj9cCyKNxznZPBXYGvOX0AX3KWbsTUc=",
      "url": "_framework/System.Security.Claims.8omn8pz0ed.wasm"
    },
    {
      "hash": "sha256-R5On2NJ4mZMZYZArNWvcGWIUv6pmnb7UB+ANtIFY+hI=",
      "url": "_framework/System.Security.Cryptography.nwvb99n9qp.wasm"
    },
    {
      "hash": "sha256-+LVw6GvgJhd5SlPIbW0mjWSMPV67LcioOzgwp19NTOo=",
      "url": "_framework/System.Text.Encoding.CodePages.k5772dw0wf.wasm"
    },
    {
      "hash": "sha256-j+zCps/oNSk5OV72cfSlTBJkRGj5v7WnunZTKbQU1Bs=",
      "url": "_framework/System.Text.Encoding.Extensions.rlgq68v5ve.wasm"
    },
    {
      "hash": "sha256-7l0fkb5oxFnPkz1mxDDly2Xk0s3T/33eEKreyymnvgc=",
      "url": "_framework/System.Text.Encoding.mzdhd52fuw.wasm"
    },
    {
      "hash": "sha256-ZfPmnXVJGL8ZDS+33YeQd2cQoeTLEjBUUg4sXYYxZoc=",
      "url": "_framework/System.Text.Encodings.Web.lwhf3uxf1y.wasm"
    },
    {
      "hash": "sha256-fTOofMGLYL+C1dqybRChnih1In7neIlx1073PeRFo3o=",
      "url": "_framework/System.Text.Json.nnric1ce0c.wasm"
    },
    {
      "hash": "sha256-5nZ9WUDgvGUcNJtbtWArTI692+fapuGQj5RUU11RvO4=",
      "url": "_framework/System.Text.RegularExpressions.uq67hyink0.wasm"
    },
    {
      "hash": "sha256-IM5iyaU39L51tlevxxlcZ9FHGgOXB/1iieVEFBEr5xs=",
      "url": "_framework/System.Threading.Tasks.cxvys3rbp0.wasm"
    },
    {
      "hash": "sha256-EXQRreBZRNntUAqAPXfCua2HzOpgyuiRJi1vC8p3/zI=",
      "url": "_framework/System.Threading.jn6105gyvd.wasm"
    },
    {
      "hash": "sha256-nPGPCZ1LewAyTtZ07Rf1Qj1YQtsGLjJzlLHSr4lAhok=",
      "url": "_framework/System.Web.HttpUtility.coj4x9n75z.wasm"
    },
    {
      "hash": "sha256-wwxsYRpXsPfLkFVXXX9uditc29XXKjAFv10/9OYAhf8=",
      "url": "_framework/System.Xml.Linq.hvxjxkvtb2.wasm"
    },
    {
      "hash": "sha256-OlQzbDEmHh3pgMr2Msd6EgKZw5qxBHlr8bAPl5QJ5zI=",
      "url": "_framework/System.Xml.ReaderWriter.qzwb826ad3.wasm"
    },
    {
      "hash": "sha256-ACo9bGaQhlmNpr3X8Kdt9TyHI38WPqz2F+LtOj9ZU1k=",
      "url": "_framework/System.Xml.XDocument.wgiu1rfx4e.wasm"
    },
    {
      "hash": "sha256-/Imz/Enqa2AZc4T3k/CqtsM6674KRN9OUtvK4Nokhew=",
      "url": "_framework/System.wznexm8bk2.wasm"
    },
    {
      "hash": "sha256-PxBQUtV7HW4AVxrjPhV5zpEV+LTsFd90t3iDHolxOfE=",
      "url": "_framework/Tommy.z379sas3l7.wasm"
    },
    {
      "hash": "sha256-k7t8Q7oCn1WWxsjYT8RyyHh8VlTi7DDfhFaV57Nhcm8=",
      "url": "_framework/USA.Model.dc36alnn5u.wasm"
    },
    {
      "hash": "sha256-nNPyM7TP7Sp4N054o563oU6FZnHcAw8jJU3H+H0sJ0I=",
      "url": "_framework/ValueOf.ccmezia1vt.wasm"
    },
    {
      "hash": "sha256-1ZHKgvmx0qPL6neLLQ5/MQVXj9TVYsoyo1iIbD5uiDo=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-3MHpnImjcdbndre7BEBFmcZQ61mhKqldc9b5Bpp44Xo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-kCdmdydekqiHdNh6m0GGtARR6TCOlaVCte+hQ41N67M=",
      "url": "_framework/dotnet.native.86d7mdvugu.wasm"
    },
    {
      "hash": "sha256-6+hoKZGZtrGELaiC+42xwS8VgtLU0qOe0fKWbtxZEBY=",
      "url": "_framework/dotnet.native.d2wbc17cku.js"
    },
    {
      "hash": "sha256-x+PnWU47EIr/zL3xxqIUMDJi/dy5904TVGunDqCvjIY=",
      "url": "_framework/dotnet.runtime.593bvuk5yc.js"
    },
    {
      "hash": "sha256-Kn+8j510dQQ7rCE6F347fJpZAM2x+uiNlRwyiSmicSI=",
      "url": "_framework/dotnetstandard-bip32.qwdn989y8v.wasm"
    },
    {
      "hash": "sha256-j6wIkVxwXBJ3QLeksRyb1pJbcfEF1waXK3cbImnAl3Q=",
      "url": "_framework/dotnetstandard-bip39.vke3c9voq8.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-LrLShrlIWTuSXzpSIxVuMFkDrKPSFEWBtSZ7sZosKuM=",
      "url": "_framework/netstandard.ys85qyn4q6.wasm"
    },
    {
      "hash": "sha256-2L//RonA6karLoNCJzLTPZ61KK8of0wr19skw63Hlw8=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-0iwIe+QAchK1Dbl8OAkO4rjwtbGDv5umPvatKQZGaVw=",
      "url": "docs/MWR-First-Round-Draft-Choice-English.pdf"
    },
    {
      "hash": "sha256-boY1bNun2P8DGhdXupoEuINNrFst0azy0Hd/pyUupCs=",
      "url": "docs/WealthWorksheet-Answers-v1.pdf"
    },
    {
      "hash": "sha256-Rxwu4GY7uhtw2E3QkPacuCi5VoVMimW56oarTIyiHgY=",
      "url": "docs/WealthWorksheet-Answers-v2.pdf"
    },
    {
      "hash": "sha256-mvwx1aCn+FuanBm/2Xe7f9kdLT5pB80vaV7csWhZv/U=",
      "url": "docs/WealthWorksheet-Answers-v3.pdf"
    },
    {
      "hash": "sha256-rYxEF4lV8W4KwQamII7LnX5sW8mNRo65Ljj6MQX8+QM=",
      "url": "docs/WealthWorksheet-Blank-v1.pdf"
    },
    {
      "hash": "sha256-Ugg1CVsxoQsM/WY5VWTPrPImwa+qsYq6mPL7IiSWHyY=",
      "url": "docs/WealthWorksheet-Blank-v2.pdf"
    },
    {
      "hash": "sha256-XmaYYGkkA6bJ/t0boZXQE+eH7ODG+2PYinPzK2kzusE=",
      "url": "docs/WealthWorksheet-Blank-v3.pdf"
    },
    {
      "hash": "sha256-cUWbdSoEv55gd6reBjEVorYi9tqC/NV2HV6xW4GfMVI=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-3Bn8a0+Z6aQ0C3iezz+NhW5WoBi3WAedn3HESu9SWmI=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-Sx13Amo/vs8TXYuIiGKhNJ1YOaGBzMG+HKaFbvQ6cKU=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-0EmI2DzdKKXB6UXy5Gq8s5GmQBdX2m1sKLAy24H/ih8=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_ENG.png"
    },
    {
      "hash": "sha256-epuvvqUkzf8j3FdkSX06OLRLotnxR1Pn41e8/nzi8HI=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_SPANISH.png"
    },
    {
      "hash": "sha256-2GaLGuhFCj/nV8xt3jTthp1o6hh60P/aNus5QQ5eRVg=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-ENG.png"
    },
    {
      "hash": "sha256-O31j5nWkea4Njs0tyHl/u90xobm2ie/Mr6ZoTT11uH0=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-SPANISH.png"
    },
    {
      "hash": "sha256-9penkBKfaAtQ6BcxPuu7gJSj5fyBVltlH2EPf4ohsbE=",
      "url": "images/72-hour-money-challenge.png"
    },
    {
      "hash": "sha256-dkWIZ8TeixFQnRqM+eWjOtXcZ4yXjTkyvlLfQlH0V74=",
      "url": "images/72hour-money-challenge-logo.png"
    },
    {
      "hash": "sha256-YPT2wkgMebWcXFKa+RH+bVg2S/ouYliMHTthIwOCx8I=",
      "url": "images/WealthWorksheet-202406.jpeg"
    },
    {
      "hash": "sha256-x/KjPrxSXn9qLoJTZKDdm8FPJNRQ5cge45ZoYPE0Bt4=",
      "url": "images/WealthWorksheet-Blank-v1.png"
    },
    {
      "hash": "sha256-aJc0GeZ+QyjMhs/oI5fp345z9klW7x0E6c1U+JYCCB4=",
      "url": "images/app-logo.png"
    },
    {
      "hash": "sha256-5y96EQXaqvkWqZhMLIKp1ETH3G+cUnYMN/q+D1LOD5U=",
      "url": "images/app-screenshot.jpeg"
    },
    {
      "hash": "sha256-2LHqb5ZGgFxpM5wEObzowveNpXw+a+ilaNBvefadJFA=",
      "url": "images/apple-store-logo.png"
    },
    {
      "hash": "sha256-d+haM7zmj1SK8ShTtlNReuAVVQRjL+GwpIk1Xs5t6T4=",
      "url": "images/bitcoin.png"
    },
    {
      "hash": "sha256-BIjUdqe6Pd1bpC7vw+7hDp0atyGdr9GxUsQJBoJx2EQ=",
      "url": "images/events/72day-blitz.jpg"
    },
    {
      "hash": "sha256-XnXrqTwRAmZX3ftdeYVLxQP+phWWHB8PkST74+jCYBs=",
      "url": "images/events/fridays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-durHWyGA/ZOHAHBxpNnaNiLcRGwQ80emEgIpx00WUYA=",
      "url": "images/events/megaschool-officehours.jpg"
    },
    {
      "hash": "sha256-IBM9p32DWT+bJMFE9VrGxsB4yOs+e2BFxbi2WHGqGec=",
      "url": "images/events/mondays-kingdombuilders-overview.jpeg"
    },
    {
      "hash": "sha256-+wj2nf1yWGIoA1rxQ9TO/ybqkOZKAJfnaut+qjH3b9k=",
      "url": "images/events/mondays-megaschool-bitcoin.jpg"
    },
    {
      "hash": "sha256-tH0Uy+FPtHqJtCHBiPP3gtPW06uERgfjNkUOy0nB87s=",
      "url": "images/events/mondays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-8jEuqbQVZBP96DyiL3zI+wtSyNdUn5u6WsWfXIBcmWs=",
      "url": "images/events/saturdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-+Xv2jWM+E8Sxc4EczNKAuEr9FKjmOpSUbg4LIg0LWh0=",
      "url": "images/events/saturdays-creditteam-readingclub.jpeg"
    },
    {
      "hash": "sha256-X0AhZbwv+14vuNO0AqDUFKRYCMTd2ZLA81kRaghW4QE=",
      "url": "images/events/saturdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-VHOQUj47T8XHNPWNdPyFMAcYO+WEGzQw3MxZ9Q5DM8g=",
      "url": "images/events/thursdays-corporate-training.jpeg"
    },
    {
      "hash": "sha256-I0A4MxG8FZX7weKGstIivDrLR7/fy0mypSeF+eIy5hY=",
      "url": "images/events/thursdays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-141HA0WKoh9MbO/9Rd+T+amz+dNai67KCERdkAioQOI=",
      "url": "images/events/tuesdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-Dvw+y+Aa8ZxIdpZgDkHfJgSCY+B9kSNtLXFH57uW6cs=",
      "url": "images/events/tuesdays-edm-sizzlecall.jpeg"
    },
    {
      "hash": "sha256-4MbH5AJ+zmI5rO5H7WH2E1lev2agCDo4s6f6cR1E2YE=",
      "url": "images/events/tuesdays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-nTMdPi6+geczXpLMA7LpsOm3K98aKbq6jQnUZu6Qbck=",
      "url": "images/events/tuesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-hZtojdaZEibd+x79MR5jRBDr2OmZNdAJHeRsEC/nj0s=",
      "url": "images/events/wednesdays-creditteam-noon_overview.jpeg"
    },
    {
      "hash": "sha256-6/HA01PFP4SDPeGcszKA0L/o2vSQDcXowv4gkqGBtpM=",
      "url": "images/events/wednesdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-GiIvAfyCmwkwOGgNOfNir5/R6r0tLWIlg8GlYD3u450=",
      "url": "images/events/wednesdays-edm-overview.jpeg"
    },
    {
      "hash": "sha256-U6xu7LRjVWO2sh9tsfZ7Wx11vp6GFp6yAleDXo9Baw0=",
      "url": "images/events/wednesdays-edm-training.jpg"
    },
    {
      "hash": "sha256-TJaXAdRACicRBPR49m0mrUY/nTYd5UZ+nH7ictcegqc=",
      "url": "images/events/wednesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-WfWmNx8ugrVJt8Hio8mInauBeubXz3MNU+wBO1HlhNk=",
      "url": "images/faithandfinance.jpg"
    },
    {
      "hash": "sha256-wm6Fc6KewsfvAxFUAH9Gfl54bRLK50JtpGkRRw/5XRU=",
      "url": "images/givbux-logo.png"
    },
    {
      "hash": "sha256-QCS5jSwSmQddgvloSz38p2b6gcW2IeBNZ6C/Sf7JIKE=",
      "url": "images/givbux.jpeg"
    },
    {
      "hash": "sha256-HGpfynKCRnDS/GXuvdXetRI3BuViqf5Pl3kWKo1D0uM=",
      "url": "images/google-store-logo.png"
    },
    {
      "hash": "sha256-0259fqSmtuwgBDyrjOq712+2mCWikluPGqsB3Msfbc8=",
      "url": "images/keys-to-home-ownership-banner.jpg"
    },
    {
      "hash": "sha256-Qznvfa8S28xPiRLum+paxAd/Q/xKgrVsxpe/+VTAApY=",
      "url": "images/mwr-banner.png"
    },
    {
      "hash": "sha256-398mb2+jZWyLUeJTRCc7EZVWnJMfQIGY1J3s6Z37h5E=",
      "url": "images/mwr-givbux-logo.png"
    },
    {
      "hash": "sha256-uWb3M+RKY9JEAAgaEhCUoEW8JQWeEBLW22LdJ4O0v/0=",
      "url": "images/mwr-healthshare.png"
    },
    {
      "hash": "sha256-Uyrk2Rn4TCV5YDgdsoJtyvurtxMHgqD+s6qR0CjpzVw=",
      "url": "images/mwr-logo-transparent-221x221.png"
    },
    {
      "hash": "sha256-NlYP609WoZo06NouFRFzFdQY+fH/5EcpBkjWrP3KpRA=",
      "url": "images/mwr-membership-logo.jpg"
    },
    {
      "hash": "sha256-u2LuEEAV/k6NEIA7jLbCqrEzyV0IoHMEIgF0ImsQoKg=",
      "url": "images/mwr-precious-metals.jpg"
    },
    {
      "hash": "sha256-hXeCeiWwbi+JSpfjfkrrAc7plipQKl97raN+PnBhvyQ=",
      "url": "images/next-level-strategies-logo.png"
    },
    {
      "hash": "sha256-G6O/0wfsoPFqWRsdY7QYuDVu+LEca98xXZTF2QaIwU4=",
      "url": "images/student-loan-debt-relief-tile.png"
    },
    {
      "hash": "sha256-4dLv3/Bgj1U90lWJ4WzyRf/+UpWmyuxeI5IL1wUZfLY=",
      "url": "images/words/72hour-response.jpeg"
    },
    {
      "hash": "sha256-KFV0G6KHAWfA6+8567BYhpvz1r+YccrETCb55o6qIhc=",
      "url": "images/words/72hour-share.jpeg"
    },
    {
      "hash": "sha256-cDeEIUrwWMlQUd1Ob3hQ+GLdlDkroj/DpIsC2WjE3GI=",
      "url": "images/words/72hour-success-story.jpeg"
    },
    {
      "hash": "sha256-mTGsRaDSfHWKufwB/OCEqg8x+8Gl80ha6PKO0vfcfzY=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ck2YK4oJkShd1p5P86axqOSMs6L+Be8AM0Y34BKqDVQ=",
      "url": "manifest.webmanifest"
    }
  ]
};
