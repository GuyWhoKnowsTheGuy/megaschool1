self.assetsManifest = {
  "version": "Cuv3KylV",
  "assets": [
    {
      "hash": "sha256-qJAuuKtXjsOCdGWVdhXSxJjtr26OIrMo88bEuQiSAyw=",
      "url": "MegaSchool1.styles.css"
    },
    {
      "hash": "sha256-CzOMFx1QJiQ2qwbg9cmQ2X4RRqnNAtwbMXJ6WE2L6js=",
      "url": "_content/Append.Blazor.WebShare/scripts.js"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-2gItJ0j/o5RSWg7VYqCOBpSPI1dxTOG+mnEzWt7EvYw=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-lz0Xidl9yw53lEeYs4XMU39zSRQzpCIyWOQSAG0/0GU=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-eTpvwvDNavTSzL9mvsyAolbszT4oDL+nWD2dv0NSeUM=",
      "url": "_framework/Append.Blazor.WebShare.3trn12rddt.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-D+dfp6xcbDQeM8YkMnhT4SB0NpR70u2eqX216CNZKNs=",
      "url": "_framework/Common.Logging.Core.bxmwr8lhlv.wasm"
    },
    {
      "hash": "sha256-4AVhWz22l1X8Pl+vQZMfhD+iMZzHdeyyWpx3yGcXtXY=",
      "url": "_framework/Common.Logging.k361pnvvgn.wasm"
    },
    {
      "hash": "sha256-onKVOOPwOpMf6ZHdGmKq/vYCqbsT1FOyMRGpBg9c18g=",
      "url": "_framework/Flow.Model.28g20tmnwr.wasm"
    },
    {
      "hash": "sha256-WPapi0QQGDPxV5h6hireLf5cVKMSxEpL5HGBKdmcXho=",
      "url": "_framework/Flow.UI.okop9moytu.wasm"
    },
    {
      "hash": "sha256-y2wmu0q0yfh4/O0BN8s/ZnPUFizpBUQu6X5SeIQJjnI=",
      "url": "_framework/FluentValidation.fvee6lf8f0.wasm"
    },
    {
      "hash": "sha256-oOQoEy4mG5XZtBy+itWxRWFmwAzhFy0j4xLw6n9OBhw=",
      "url": "_framework/Foundation.Model.gg18iglu6j.wasm"
    },
    {
      "hash": "sha256-Bf0q3aOHNGQecx5DoyInXTjrNokEcoo1Vokicryo9Fo=",
      "url": "_framework/Foundation.UI.t2m9tuvj8l.wasm"
    },
    {
      "hash": "sha256-dBm5UHP8hg3pLku0if0ZJcCu16124P6GQPD92njA/wY=",
      "url": "_framework/LaunchDarkly.EventSource.ck3ehzcsxc.wasm"
    },
    {
      "hash": "sha256-iQ4OFhIeYqKSkf5ANQ0KcZkQGbPdKVIsNE7HWvslxas=",
      "url": "_framework/MegaSchool1.Model.no4zf8eexi.wasm"
    },
    {
      "hash": "sha256-H6dWi99qjHcOVnK/asxd3/rZH+MYTqJ0lD3w8z8p8+o=",
      "url": "_framework/MegaSchool1.ViewModel.zzttac7g0l.wasm"
    },
    {
      "hash": "sha256-uuwdeZVZUmLLa6z1GkxJnoU9sVZEoO951AExBUDLY5Y=",
      "url": "_framework/MegaSchool1.eyn8wic6iv.wasm"
    },
    {
      "hash": "sha256-RnC/S/N1+AxW/0kaWaSmQoxtNCnzJ5NGlSzA5dTU7oE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.2xyes3k065.wasm"
    },
    {
      "hash": "sha256-3coLXLmun2SV8D55Au/WN9EMBMUXYNIscLx+UTUhLls=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.vl5nh6fdpj.wasm"
    },
    {
      "hash": "sha256-+gxUludaINZ70f4h1lldp0LaNUTfrksUtBBfXXgDR+4=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.awv276wvv1.wasm"
    },
    {
      "hash": "sha256-0KnRJhzF1XvPRLQHknna86BwCn93Z/ZSNVENNFXHL7A=",
      "url": "_framework/Microsoft.AspNetCore.Components.s1fkpdwjgh.wasm"
    },
    {
      "hash": "sha256-u3mEORvukAz7fkytxltbXkCDyFUfZ881XzzN8vcXrj4=",
      "url": "_framework/Microsoft.CSharp.h1x4qrydda.wasm"
    },
    {
      "hash": "sha256-LEE9JMNr6yBttXcH/wZtTMXgC5VBiUEOTf9X8WwYdnM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.kqbb9iwcu9.wasm"
    },
    {
      "hash": "sha256-CIiGMLN5vhkVqQQ9qGVJ8orwgtoTKXi5dW2ybJQsKfQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.snzqtphc7k.wasm"
    },
    {
      "hash": "sha256-7Wv00KMrZAHb5sX5acrBZ6dNoPfDuaNWlT69VNMGt1g=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.n3x20s9cxz.wasm"
    },
    {
      "hash": "sha256-j8JVvkL7/ufE5r7Ct/tFO4AogNhvD/RI4QrE0+N/Sds=",
      "url": "_framework/Microsoft.Extensions.Configuration.h4xjvse7p2.wasm"
    },
    {
      "hash": "sha256-JsW+cRASsXTK6uzvL8WHljk0zRatN1sBuXg67upfms0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.ezeg792dv7.wasm"
    },
    {
      "hash": "sha256-DnnRKy8PZBHtfhziO6DfIwoozcHbfQiGwcXDh5nRSZc=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.qeizni4cln.wasm"
    },
    {
      "hash": "sha256-G8DZtlu1/GCP5RvpUDywE16hvdoPShJlILgyJtH6+uY=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.x1u7gvk23k.wasm"
    },
    {
      "hash": "sha256-hcJFVGS1x8m5ZeBhvyIEBqYSQKIzBLnbw77jq3TNVmA=",
      "url": "_framework/Microsoft.Extensions.Localization.nx0z2f3xfv.wasm"
    },
    {
      "hash": "sha256-s8XRgJIsF8yl9CsuF6smQT8lJ8YaSHBw7OeDiKtaXz8=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.t85bfnqar4.wasm"
    },
    {
      "hash": "sha256-TusUfPjSxh0GzZINX/Xk9afg45BQccmXJOyvulCHlU4=",
      "url": "_framework/Microsoft.Extensions.Logging.e47xhy91y6.wasm"
    },
    {
      "hash": "sha256-muT+1idbPdv4l3tZ03AMNKOMBk1naU8HsjiH1fugp08=",
      "url": "_framework/Microsoft.Extensions.Options.2tpvz1izx7.wasm"
    },
    {
      "hash": "sha256-6cQKFBXogCgICQbWptUlzgW+xOHIWbUMRjFxztqytdA=",
      "url": "_framework/Microsoft.Extensions.Primitives.9kx4ehp8td.wasm"
    },
    {
      "hash": "sha256-NNwR0xu2wKvvEIZnSUwKht+/0RJ9ziHW01M66VViIkI=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.s0bw0921jm.wasm"
    },
    {
      "hash": "sha256-mD+ialw6cL0LLJvNsNBGyebfBcnqBIz4E2f0vhVM1kk=",
      "url": "_framework/Microsoft.JSInterop.owoyhrhqcu.wasm"
    },
    {
      "hash": "sha256-/P7YsBCwHFyd0qh6kk0qCBa6MjGjFWqx4RNItiolYHM=",
      "url": "_framework/MudBlazor.w9ymie2dl6.wasm"
    },
    {
      "hash": "sha256-ywAFDtoXferEICrM3akT+z9meobGUQFPhz2X53jBT90=",
      "url": "_framework/NSec.Cryptography.97ryhkcw5y.wasm"
    },
    {
      "hash": "sha256-+ivIDUFHJl+LmeKj7ueRPfnWM/wp2dMygtiBlp6Cqmw=",
      "url": "_framework/Nett.emyfn4350c.wasm"
    },
    {
      "hash": "sha256-erKuIr8Gjq+X/Ji4X+pGauW71/eyGT7GHVu8k+7ie8I=",
      "url": "_framework/Newtonsoft.Json.y96379yjhz.wasm"
    },
    {
      "hash": "sha256-akqbZuRazMph7GZNcPHLIOp1mgnkjdaWZMM9Up4LPfE=",
      "url": "_framework/OneOf.yq61etxwqn.wasm"
    },
    {
      "hash": "sha256-ayRMl7l1GF4h65kNE0bKJ4lrGPZxmR+OkvPUFrQ11oU=",
      "url": "_framework/QRCoder.jqr4n2c9hc.wasm"
    },
    {
      "hash": "sha256-N4ZU6eJF/5fU256BMqTFiWlil2VWJWAsPknHQO0ckGg=",
      "url": "_framework/Riok.Mapperly.Abstractions.pgbnsxyg2i.wasm"
    },
    {
      "hash": "sha256-4eyCDrmeln8TfYIa6F9oAyuyPqJi7Y5/CaXDOfYve6A=",
      "url": "_framework/Serilog.Sinks.Async.5f8lfszthz.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-IU1wbWWmevTzax9faR7cBTh3+/SHme1dNs0/OXItpXc=",
      "url": "_framework/Serilog.Sinks.Console.rtr49hgfiq.wasm"
    },
    {
      "hash": "sha256-WJnIFTgSW6mPBi+d+MOvpZ0IXg+51E6ThiureQRk1hE=",
      "url": "_framework/Serilog.szasst5jz9.wasm"
    },
    {
      "hash": "sha256-alRiRzw5KDkECQZKto9tcUahjQRoX0a5Ut6hMzhsIdQ=",
      "url": "_framework/Stellar.awyn051oj1.wasm"
    },
    {
      "hash": "sha256-qHNZ8h43rSmurN+TUq1k8SdAxIuvBgz2q4e5/jpi580=",
      "url": "_framework/StellarDotnetSdk.Xdr.c7l0d1l8gk.wasm"
    },
    {
      "hash": "sha256-ZpTLfBQ4mW58BMV8m3lf335ICzri1Bd0dqjaPv46ZQs=",
      "url": "_framework/StellarDotnetSdk.ey9gu88e22.wasm"
    },
    {
      "hash": "sha256-361PBTDnqwlVKBzfyowQuv+RRSTHD63TLv5FIhmRCfc=",
      "url": "_framework/System.Collections.76kbftfmfq.wasm"
    },
    {
      "hash": "sha256-JP3enlK0xxyVC3Tym0bBziXhQ9aafTewLdybqVOdToU=",
      "url": "_framework/System.Collections.Concurrent.w3l8ipxqch.wasm"
    },
    {
      "hash": "sha256-YS9NHy2wik34QzAfXnt09HDLZMTO6tAtaHtvCUAeLl8=",
      "url": "_framework/System.Collections.Immutable.7uan6dupqv.wasm"
    },
    {
      "hash": "sha256-EfqhZOrwMJgj8sXa9ZJNwKXJsJZixUDIf2pBij7vnNY=",
      "url": "_framework/System.Collections.NonGeneric.14sj50sgu3.wasm"
    },
    {
      "hash": "sha256-c+V9nAw6AR6OaeR6eo0WNnHv1a9Dy+KQkjIrMb4l2N4=",
      "url": "_framework/System.Collections.Specialized.xjwfg2fem2.wasm"
    },
    {
      "hash": "sha256-qoTv6i7rRlhg60E1BEWdHwuGwVHD26DQ+R0s/kHt60Y=",
      "url": "_framework/System.ComponentModel.Annotations.2yqdff7tz7.wasm"
    },
    {
      "hash": "sha256-O96mnECLxq93G83+1tsRHHBgFCUFDNds9clCRacx7A8=",
      "url": "_framework/System.ComponentModel.Primitives.n9mabl72kn.wasm"
    },
    {
      "hash": "sha256-U/rvNtSAjjnMnuTZTLLyGo2s9jVDvIpc4Oy0DXYb1dc=",
      "url": "_framework/System.ComponentModel.TypeConverter.l6sohco2lw.wasm"
    },
    {
      "hash": "sha256-WmhToug7mDyPKTOay7sl7rmJ3MQoNfnjPttl8KfIJqo=",
      "url": "_framework/System.ComponentModel.ea38dmp4us.wasm"
    },
    {
      "hash": "sha256-o8MZlaj2fElqNLb598A1BDaOfRXKdxgVfwyPng2tLt0=",
      "url": "_framework/System.Console.v1e6zxh4gn.wasm"
    },
    {
      "hash": "sha256-0J/Y5dSkqOUa/Rl7H3moDwjcVErwP6bkoogScJEtD4I=",
      "url": "_framework/System.Data.Common.oy7a9wjggd.wasm"
    },
    {
      "hash": "sha256-Z4Keed15XX3uCK1uW0R14bDRhYdNvFffMVAcylXTJYU=",
      "url": "_framework/System.Diagnostics.Debug.tn40msacy8.wasm"
    },
    {
      "hash": "sha256-4Kubvoo3ohAmOHnlolO1mJtagAtab0EgI2i6VVLOCKg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.cpdyqa3tsm.wasm"
    },
    {
      "hash": "sha256-nGuL6Vc9QpXZSrh2cfGQrh9NWxbbT2qHwPD49YlL/Mw=",
      "url": "_framework/System.Diagnostics.Tools.gdk1ng4mui.wasm"
    },
    {
      "hash": "sha256-GOgOGLCFemZbpcnW1YAGdpvztGVoDw6PXfw5GIRbiXg=",
      "url": "_framework/System.Diagnostics.TraceSource.ok3gexkdz5.wasm"
    },
    {
      "hash": "sha256-PtBJAFaHIHs6T2YulCQBLTa/sKaNSWCBZBF1XQ9PPPo=",
      "url": "_framework/System.Drawing.Primitives.62bl9ztba9.wasm"
    },
    {
      "hash": "sha256-ducFCgiJEvd0YKqregBanI7SOQY0pHqIYo3WGHyfgj8=",
      "url": "_framework/System.Drawing.qrlpt0785n.wasm"
    },
    {
      "hash": "sha256-UW4kolElMc/FSCAPhpkuadfFzyGvit5txWhlcy8OLc0=",
      "url": "_framework/System.Globalization.7ubbpis6cj.wasm"
    },
    {
      "hash": "sha256-wjAKw30jbRReAF+HvYEtWY3wLQ75wACjKGUK05qC5Oo=",
      "url": "_framework/System.IO.Compression.24v19hdqb7.wasm"
    },
    {
      "hash": "sha256-uEVVMYx7abWgasKfPzSB6wOMoCpVEVv4EcEAOCa4ph0=",
      "url": "_framework/System.IO.Pipelines.0uhw8kopg1.wasm"
    },
    {
      "hash": "sha256-xUlyaSe5ub3VTtdHpUCpcb4fKRH6GXJ9apmOft7AQzM=",
      "url": "_framework/System.IO.rgu00f8whj.wasm"
    },
    {
      "hash": "sha256-xZ0JNfYrW4hNxrJZ1cL3I6Oc1y9Jnx4QNNGQs72Lr8o=",
      "url": "_framework/System.Linq.Expressions.p7j2gwkoyd.wasm"
    },
    {
      "hash": "sha256-j3VDo8E4QxbVdNuT74hcCdmj9pvkOyiJo7CxAZ44rh8=",
      "url": "_framework/System.Linq.p29ywm3zqz.wasm"
    },
    {
      "hash": "sha256-z83Lqf81dTCszutBbL5ZkjOo863d7t/H0wKmYSFb1zA=",
      "url": "_framework/System.Memory.x4s7s3246p.wasm"
    },
    {
      "hash": "sha256-6NlG4rz3HITq3C+TNvSIMk0Zb3sd9MHxf9LTIQ9G37c=",
      "url": "_framework/System.Net.Http.Json.8gxvrc0rat.wasm"
    },
    {
      "hash": "sha256-dd2SXxGxbse1GdrULaMMKaRwF770XvsZMVvoctp/te0=",
      "url": "_framework/System.Net.Http.jmillj78ap.wasm"
    },
    {
      "hash": "sha256-5fJ22s8mcRnRmxSxEo5y1LX6IzYGAZEd6rBpbmlhyQA=",
      "url": "_framework/System.Net.Primitives.3qbvoenl1w.wasm"
    },
    {
      "hash": "sha256-Zc3oNqBjHHU1C8NZR6BB2hJlVQITlu7lwnFgf6JUMHc=",
      "url": "_framework/System.ObjectModel.tepfj3cgmq.wasm"
    },
    {
      "hash": "sha256-0yjUKni4OZS0oc4HYbz1Ows2apIIGWA9F3uLB0HdlTQ=",
      "url": "_framework/System.Private.CoreLib.pxj5bu0z0b.wasm"
    },
    {
      "hash": "sha256-Os9KLyvkPvTLnEEp3Tob5wrKX2mjN/pokrsgyDVBWFY=",
      "url": "_framework/System.Private.Uri.25l7im60ax.wasm"
    },
    {
      "hash": "sha256-djhnRgL+YvMyr/AA/yhAOIMG+hcSrEplGi6CuJCCTrE=",
      "url": "_framework/System.Private.Xml.Linq.af9v3t4p7a.wasm"
    },
    {
      "hash": "sha256-M6P+rg7DndSasHgG9LTohs9UtejYVqQow1e4P5JmHqY=",
      "url": "_framework/System.Private.Xml.pxtlqqdwzd.wasm"
    },
    {
      "hash": "sha256-CGqPfw1ue3Pp5aIqi/4gW6MHlSnRMav0ERUvbo7nW8w=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.4pbnjqip5z.wasm"
    },
    {
      "hash": "sha256-T+s7jVxG6a3REDiXqKnQu/6mFL9s0M9MaCrcUdEswQg=",
      "url": "_framework/System.Reflection.Emit.Lightweight.xwtl6tz4yr.wasm"
    },
    {
      "hash": "sha256-jmqXg1POSwmLrzEmLK6ZRqdeNjwFq2JND7EYcSSTXGA=",
      "url": "_framework/System.Reflection.Extensions.6vhs8xedod.wasm"
    },
    {
      "hash": "sha256-VjBGFdpT4lG+gqHsz8syuUZp2QdQ+yrtytYgUnI/Kaw=",
      "url": "_framework/System.Reflection.Primitives.aw2ci5v3hw.wasm"
    },
    {
      "hash": "sha256-x/foix3YNFjdK96QJV2Ql9GmA4iwEbdPBS8zwmBGSS8=",
      "url": "_framework/System.Reflection.TypeExtensions.xip42z4fu7.wasm"
    },
    {
      "hash": "sha256-dKVhyTJ9xPtjQw51eH/tNZjmXmOpOn7rjffPNrj3T8E=",
      "url": "_framework/System.Reflection.gp6qttj4wj.wasm"
    },
    {
      "hash": "sha256-kylKW1mYzrBGaLG+V+B6KeGXnstbjiTBA/BxgMpVHX8=",
      "url": "_framework/System.Resources.ResourceManager.nbzvtqc7zv.wasm"
    },
    {
      "hash": "sha256-qRmZauvG+mHxFv3LZNGTua1HWq7Ubt2/K8JqOo1gplc=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.fup2zprl4t.wasm"
    },
    {
      "hash": "sha256-fJP22SsgI+FP/FBo6+rZrdUy1eb4Gt9CcSMZThj+V+g=",
      "url": "_framework/System.Runtime.Extensions.8dawn8s5ww.wasm"
    },
    {
      "hash": "sha256-uo4WQ39eiOB+w/weMzCVCfXQey09VlzpTm+e6aR83IA=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.era55l3sbb.wasm"
    },
    {
      "hash": "sha256-rqwdddifP95i4aJVekwKnD/VlrzwsR+anLX0SMZ5sQ8=",
      "url": "_framework/System.Runtime.InteropServices.qp5z9n8bwd.wasm"
    },
    {
      "hash": "sha256-rWwwat7xf17WkD3/AUXM+rf5PyYTRYkC7AkmdKXco+Q=",
      "url": "_framework/System.Runtime.Numerics.3w9l27bsuw.wasm"
    },
    {
      "hash": "sha256-E3FefwNpi9rCX/y4uAmgNAn3qu3QR2/BxdvA34AO8Pc=",
      "url": "_framework/System.Runtime.Serialization.Formatters.lajl69n1oy.wasm"
    },
    {
      "hash": "sha256-y5lcTxMrmhWxCS4nVSp7G7YcTrxEVPyaN5sG8mTAEgI=",
      "url": "_framework/System.Runtime.Serialization.Primitives.tmkb5ll9b1.wasm"
    },
    {
      "hash": "sha256-ZgKftB6fx8b5Q+eWp7Fct2b3zS9JmPEMY/zBVO1w5h0=",
      "url": "_framework/System.Runtime.mxaxwejkd2.wasm"
    },
    {
      "hash": "sha256-TivmAqtw8g9sBZaVo6Bbabqlvt0ZFo1/GJGuvq/AY7k=",
      "url": "_framework/System.Security.Cryptography.Algorithms.ek3lmw9tmd.wasm"
    },
    {
      "hash": "sha256-v4C82vE4vX9C5x8N5LC4DsUvYOszSkIS1xN4I7DQ8Gs=",
      "url": "_framework/System.Security.Cryptography.Primitives.rt5t6q9rt9.wasm"
    },
    {
      "hash": "sha256-linS9GnUGphZpEaqqH36L3hrZszAGTGp4rfCBRNZZ+Q=",
      "url": "_framework/System.Security.Cryptography.ei4z0qow3g.wasm"
    },
    {
      "hash": "sha256-UKE1/jcuPTJI5PagDY4c7P4C0cTMFKGXNmGVcu5bN0g=",
      "url": "_framework/System.Text.Encoding.CodePages.s1p6la8n07.wasm"
    },
    {
      "hash": "sha256-2siIR6/Fy0sbh/D4cIr3o5pp3+PfnLgSC3mBbDpXlf4=",
      "url": "_framework/System.Text.Encoding.Extensions.69ltgiygmc.wasm"
    },
    {
      "hash": "sha256-cmmtz5CvRIGg3rTXniGCPYjvVnghnwUyxNBf0+Yl97w=",
      "url": "_framework/System.Text.Encoding.yvhc14kxup.wasm"
    },
    {
      "hash": "sha256-KD5saNzkpUD3A/RXlqBthi/qKA3Sk2nZuNvyfL9+EWc=",
      "url": "_framework/System.Text.Encodings.Web.wmi2z5c0zd.wasm"
    },
    {
      "hash": "sha256-53S0nZw1pKbL26pe0lc8TckTBp8A6nDgchWWYPuEXCI=",
      "url": "_framework/System.Text.Json.9orc4s8a3e.wasm"
    },
    {
      "hash": "sha256-k5rPvCp8xt7DcuPgU/3rn6pCmd3fwFy58DkjaCwAr6k=",
      "url": "_framework/System.Text.RegularExpressions.918n1fmpv6.wasm"
    },
    {
      "hash": "sha256-gxcIr6PcYLzJnOWG0EE31gihjFw6n6yreVbl+n2g/1s=",
      "url": "_framework/System.Threading.Tasks.5yrot20nmr.wasm"
    },
    {
      "hash": "sha256-W8DJdZdH9rAehEdXgdaduBtxi83kqh6Dk23JsQnRUro=",
      "url": "_framework/System.Threading.r47xif7jtc.wasm"
    },
    {
      "hash": "sha256-oX+MuCf3rSD8cifyzMpjkXWI/LbeFKfdBG53mRe1PzY=",
      "url": "_framework/System.Web.HttpUtility.n2gk6zwnph.wasm"
    },
    {
      "hash": "sha256-UugB5P9eGQHDIgrdxmssbIT8HjAPz0j6jk7e8xF0pOE=",
      "url": "_framework/System.Xml.Linq.mixoc3e4x3.wasm"
    },
    {
      "hash": "sha256-2T+X7jWkU2xFHC7LkkwGNSdddcKH0BZWIhZ3n/2z5AU=",
      "url": "_framework/System.Xml.ReaderWriter.90tg1un4nu.wasm"
    },
    {
      "hash": "sha256-ijpnwEcGWICQYTtFnWbvpN+ZRnv0ni++N4DK8RgE68Q=",
      "url": "_framework/System.Xml.XDocument.6g3slob686.wasm"
    },
    {
      "hash": "sha256-v1DeJU321NUwk3KJ0Lf8lQA3zwRfrxNommmMBs1s3Gk=",
      "url": "_framework/System.f0fr8djds0.wasm"
    },
    {
      "hash": "sha256-PxBQUtV7HW4AVxrjPhV5zpEV+LTsFd90t3iDHolxOfE=",
      "url": "_framework/Tommy.z379sas3l7.wasm"
    },
    {
      "hash": "sha256-xnzqNHbhDyvcmIWKeJKnw1gr/r6FrbtpewovbKg6N2I=",
      "url": "_framework/USA.Model.qcvmbkwa6c.wasm"
    },
    {
      "hash": "sha256-nNPyM7TP7Sp4N054o563oU6FZnHcAw8jJU3H+H0sJ0I=",
      "url": "_framework/ValueOf.ccmezia1vt.wasm"
    },
    {
      "hash": "sha256-hYC3QzI1NTmX6Kiue/j2U5X7rKcxIyF3wNyrFqtf1Cg=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-5TAd2is0AgjjYIAuEN8Bd5ZPoTk8dKE9RRtIQr4H5Lw=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-89jyB8DlCnV2BPMV477jOe1Sm0WXwVf8RuoSPsj4Ym8=",
      "url": "_framework/dotnet.native.3c4wvb350q.wasm"
    },
    {
      "hash": "sha256-LX9rFEWGVxhkOkAVPG0w5RxPwzPBlEUz6dQNjWS7M+M=",
      "url": "_framework/dotnet.native.hvg7u8bimp.js"
    },
    {
      "hash": "sha256-dCmS9Zx4egtLYSUgTI3R6gMS+Yg8MkzxW1CgEMJKAEw=",
      "url": "_framework/dotnet.runtime.cymp1amu5g.js"
    },
    {
      "hash": "sha256-Kn+8j510dQQ7rCE6F347fJpZAM2x+uiNlRwyiSmicSI=",
      "url": "_framework/dotnetstandard-bip32.qwdn989y8v.wasm"
    },
    {
      "hash": "sha256-j6wIkVxwXBJ3QLeksRyb1pJbcfEF1waXK3cbImnAl3Q=",
      "url": "_framework/dotnetstandard-bip39.vke3c9voq8.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-J8DouiqqZynos4Kgp2snKynCU85Y0yWigXZS2/KdPtA=",
      "url": "_framework/netstandard.ll954rrwjb.wasm"
    },
    {
      "hash": "sha256-mw1QTS/jQX7XgInGbyFLOibrgZKT4swO45OG0cKqb5Y=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-0iwIe+QAchK1Dbl8OAkO4rjwtbGDv5umPvatKQZGaVw=",
      "url": "docs/MWR-First-Round-Draft-Choice-English.pdf"
    },
    {
      "hash": "sha256-boY1bNun2P8DGhdXupoEuINNrFst0azy0Hd/pyUupCs=",
      "url": "docs/WealthWorksheet-Answers-v1.pdf"
    },
    {
      "hash": "sha256-Rxwu4GY7uhtw2E3QkPacuCi5VoVMimW56oarTIyiHgY=",
      "url": "docs/WealthWorksheet-Answers-v2.pdf"
    },
    {
      "hash": "sha256-mvwx1aCn+FuanBm/2Xe7f9kdLT5pB80vaV7csWhZv/U=",
      "url": "docs/WealthWorksheet-Answers-v3.pdf"
    },
    {
      "hash": "sha256-rYxEF4lV8W4KwQamII7LnX5sW8mNRo65Ljj6MQX8+QM=",
      "url": "docs/WealthWorksheet-Blank-v1.pdf"
    },
    {
      "hash": "sha256-Ugg1CVsxoQsM/WY5VWTPrPImwa+qsYq6mPL7IiSWHyY=",
      "url": "docs/WealthWorksheet-Blank-v2.pdf"
    },
    {
      "hash": "sha256-XmaYYGkkA6bJ/t0boZXQE+eH7ODG+2PYinPzK2kzusE=",
      "url": "docs/WealthWorksheet-Blank-v3.pdf"
    },
    {
      "hash": "sha256-cUWbdSoEv55gd6reBjEVorYi9tqC/NV2HV6xW4GfMVI=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-3Bn8a0+Z6aQ0C3iezz+NhW5WoBi3WAedn3HESu9SWmI=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-Sx13Amo/vs8TXYuIiGKhNJ1YOaGBzMG+HKaFbvQ6cKU=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-0EmI2DzdKKXB6UXy5Gq8s5GmQBdX2m1sKLAy24H/ih8=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_ENG.png"
    },
    {
      "hash": "sha256-epuvvqUkzf8j3FdkSX06OLRLotnxR1Pn41e8/nzi8HI=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_SPANISH.png"
    },
    {
      "hash": "sha256-2GaLGuhFCj/nV8xt3jTthp1o6hh60P/aNus5QQ5eRVg=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-ENG.png"
    },
    {
      "hash": "sha256-O31j5nWkea4Njs0tyHl/u90xobm2ie/Mr6ZoTT11uH0=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-SPANISH.png"
    },
    {
      "hash": "sha256-9penkBKfaAtQ6BcxPuu7gJSj5fyBVltlH2EPf4ohsbE=",
      "url": "images/72-hour-money-challenge.png"
    },
    {
      "hash": "sha256-dkWIZ8TeixFQnRqM+eWjOtXcZ4yXjTkyvlLfQlH0V74=",
      "url": "images/72hour-money-challenge-logo.png"
    },
    {
      "hash": "sha256-YPT2wkgMebWcXFKa+RH+bVg2S/ouYliMHTthIwOCx8I=",
      "url": "images/WealthWorksheet-202406.jpeg"
    },
    {
      "hash": "sha256-x/KjPrxSXn9qLoJTZKDdm8FPJNRQ5cge45ZoYPE0Bt4=",
      "url": "images/WealthWorksheet-Blank-v1.png"
    },
    {
      "hash": "sha256-aJc0GeZ+QyjMhs/oI5fp345z9klW7x0E6c1U+JYCCB4=",
      "url": "images/app-logo.png"
    },
    {
      "hash": "sha256-5y96EQXaqvkWqZhMLIKp1ETH3G+cUnYMN/q+D1LOD5U=",
      "url": "images/app-screenshot.jpeg"
    },
    {
      "hash": "sha256-2LHqb5ZGgFxpM5wEObzowveNpXw+a+ilaNBvefadJFA=",
      "url": "images/apple-store-logo.png"
    },
    {
      "hash": "sha256-d+haM7zmj1SK8ShTtlNReuAVVQRjL+GwpIk1Xs5t6T4=",
      "url": "images/bitcoin.png"
    },
    {
      "hash": "sha256-BIjUdqe6Pd1bpC7vw+7hDp0atyGdr9GxUsQJBoJx2EQ=",
      "url": "images/events/72day-blitz.jpg"
    },
    {
      "hash": "sha256-XnXrqTwRAmZX3ftdeYVLxQP+phWWHB8PkST74+jCYBs=",
      "url": "images/events/fridays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-durHWyGA/ZOHAHBxpNnaNiLcRGwQ80emEgIpx00WUYA=",
      "url": "images/events/megaschool-officehours.jpg"
    },
    {
      "hash": "sha256-IBM9p32DWT+bJMFE9VrGxsB4yOs+e2BFxbi2WHGqGec=",
      "url": "images/events/mondays-kingdombuilders-overview.jpeg"
    },
    {
      "hash": "sha256-+wj2nf1yWGIoA1rxQ9TO/ybqkOZKAJfnaut+qjH3b9k=",
      "url": "images/events/mondays-megaschool-bitcoin.jpg"
    },
    {
      "hash": "sha256-tH0Uy+FPtHqJtCHBiPP3gtPW06uERgfjNkUOy0nB87s=",
      "url": "images/events/mondays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-8jEuqbQVZBP96DyiL3zI+wtSyNdUn5u6WsWfXIBcmWs=",
      "url": "images/events/saturdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-+Xv2jWM+E8Sxc4EczNKAuEr9FKjmOpSUbg4LIg0LWh0=",
      "url": "images/events/saturdays-creditteam-readingclub.jpeg"
    },
    {
      "hash": "sha256-X0AhZbwv+14vuNO0AqDUFKRYCMTd2ZLA81kRaghW4QE=",
      "url": "images/events/saturdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-VHOQUj47T8XHNPWNdPyFMAcYO+WEGzQw3MxZ9Q5DM8g=",
      "url": "images/events/thursdays-corporate-training.jpeg"
    },
    {
      "hash": "sha256-I0A4MxG8FZX7weKGstIivDrLR7/fy0mypSeF+eIy5hY=",
      "url": "images/events/thursdays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-141HA0WKoh9MbO/9Rd+T+amz+dNai67KCERdkAioQOI=",
      "url": "images/events/tuesdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-Dvw+y+Aa8ZxIdpZgDkHfJgSCY+B9kSNtLXFH57uW6cs=",
      "url": "images/events/tuesdays-edm-sizzlecall.jpeg"
    },
    {
      "hash": "sha256-4MbH5AJ+zmI5rO5H7WH2E1lev2agCDo4s6f6cR1E2YE=",
      "url": "images/events/tuesdays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-nTMdPi6+geczXpLMA7LpsOm3K98aKbq6jQnUZu6Qbck=",
      "url": "images/events/tuesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-hZtojdaZEibd+x79MR5jRBDr2OmZNdAJHeRsEC/nj0s=",
      "url": "images/events/wednesdays-creditteam-noon_overview.jpeg"
    },
    {
      "hash": "sha256-6/HA01PFP4SDPeGcszKA0L/o2vSQDcXowv4gkqGBtpM=",
      "url": "images/events/wednesdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-GiIvAfyCmwkwOGgNOfNir5/R6r0tLWIlg8GlYD3u450=",
      "url": "images/events/wednesdays-edm-overview.jpeg"
    },
    {
      "hash": "sha256-U6xu7LRjVWO2sh9tsfZ7Wx11vp6GFp6yAleDXo9Baw0=",
      "url": "images/events/wednesdays-edm-training.jpg"
    },
    {
      "hash": "sha256-TJaXAdRACicRBPR49m0mrUY/nTYd5UZ+nH7ictcegqc=",
      "url": "images/events/wednesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-WfWmNx8ugrVJt8Hio8mInauBeubXz3MNU+wBO1HlhNk=",
      "url": "images/faithandfinance.jpg"
    },
    {
      "hash": "sha256-wm6Fc6KewsfvAxFUAH9Gfl54bRLK50JtpGkRRw/5XRU=",
      "url": "images/givbux-logo.png"
    },
    {
      "hash": "sha256-QCS5jSwSmQddgvloSz38p2b6gcW2IeBNZ6C/Sf7JIKE=",
      "url": "images/givbux.jpeg"
    },
    {
      "hash": "sha256-HGpfynKCRnDS/GXuvdXetRI3BuViqf5Pl3kWKo1D0uM=",
      "url": "images/google-store-logo.png"
    },
    {
      "hash": "sha256-0259fqSmtuwgBDyrjOq712+2mCWikluPGqsB3Msfbc8=",
      "url": "images/keys-to-home-ownership-banner.jpg"
    },
    {
      "hash": "sha256-Qznvfa8S28xPiRLum+paxAd/Q/xKgrVsxpe/+VTAApY=",
      "url": "images/mwr-banner.png"
    },
    {
      "hash": "sha256-398mb2+jZWyLUeJTRCc7EZVWnJMfQIGY1J3s6Z37h5E=",
      "url": "images/mwr-givbux-logo.png"
    },
    {
      "hash": "sha256-uWb3M+RKY9JEAAgaEhCUoEW8JQWeEBLW22LdJ4O0v/0=",
      "url": "images/mwr-healthshare.png"
    },
    {
      "hash": "sha256-Uyrk2Rn4TCV5YDgdsoJtyvurtxMHgqD+s6qR0CjpzVw=",
      "url": "images/mwr-logo-transparent-221x221.png"
    },
    {
      "hash": "sha256-NlYP609WoZo06NouFRFzFdQY+fH/5EcpBkjWrP3KpRA=",
      "url": "images/mwr-membership-logo.jpg"
    },
    {
      "hash": "sha256-u2LuEEAV/k6NEIA7jLbCqrEzyV0IoHMEIgF0ImsQoKg=",
      "url": "images/mwr-precious-metals.jpg"
    },
    {
      "hash": "sha256-hXeCeiWwbi+JSpfjfkrrAc7plipQKl97raN+PnBhvyQ=",
      "url": "images/next-level-strategies-logo.png"
    },
    {
      "hash": "sha256-G6O/0wfsoPFqWRsdY7QYuDVu+LEca98xXZTF2QaIwU4=",
      "url": "images/student-loan-debt-relief-tile.png"
    },
    {
      "hash": "sha256-4dLv3/Bgj1U90lWJ4WzyRf/+UpWmyuxeI5IL1wUZfLY=",
      "url": "images/words/72hour-response.jpeg"
    },
    {
      "hash": "sha256-KFV0G6KHAWfA6+8567BYhpvz1r+YccrETCb55o6qIhc=",
      "url": "images/words/72hour-share.jpeg"
    },
    {
      "hash": "sha256-cDeEIUrwWMlQUd1Ob3hQ+GLdlDkroj/DpIsC2WjE3GI=",
      "url": "images/words/72hour-success-story.jpeg"
    },
    {
      "hash": "sha256-mTGsRaDSfHWKufwB/OCEqg8x+8Gl80ha6PKO0vfcfzY=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ck2YK4oJkShd1p5P86axqOSMs6L+Be8AM0Y34BKqDVQ=",
      "url": "manifest.webmanifest"
    }
  ]
};
